import numpy as np
import torch
import scipy.io
import matplotlib.pyplot as plt
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
model_name = ['non_GP', 'GP v1', 'GP v2', 'AR stronger', 'AR simple', 'scaled AR(1)']

model_selected = model_name[0]
print(f'selected model is {model_selected}')

N=50
noise = 0

s1 = 1
s2 = 3

plt.figure(figsize=(8, 6))

if noise == 0:
    if model_selected == 'non_GP':
        print(f'model is {model_selected}')

        file_path_1 = os.path.join(current_dir, 'data/data_step3', f'non_GP_test1__noise_{noise}_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        h = file_path_1['h'].flatten()
        predict1 = file_path_1['predict'].flatten()
        predict = predict1
        x_true = file_path_1['true'].flatten()
                                                                  
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'non_GP_test1_noise_{noise}_N={N}.pdf')

    elif model_selected == 'GP v1':
        print(f'model is {model_selected}')

        file_path_2 = os.path.join(current_dir, 'data/data_step3', f'GP_version1_test1_noise_{noise}_N={N}.mat')
        file_path_2 = scipy.io.loadmat(file_path_2)
        h = file_path_2['h'].flatten()
        predict2 = file_path_2['predict'].flatten()
        predict = predict2
        x_true = file_path_2['true'].flatten()
                                                                 
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'GP_v1_test1_noise_{noise}_N={N}.pdf')

    elif model_selected == 'GP v2':
        print(f'model is {model_selected}')

        file_path_3 = os.path.join(current_dir, 'data/data_step3', f'GP_version2_test1_noise_{noise}_N={N}.mat')
        file_path_3 = scipy.io.loadmat(file_path_3)
        h3 = file_path_3['h'].flatten()
        predict3 = file_path_3['predict'].flatten()
        predict = predict3
        h = h3
        x_true = file_path_3['true'].flatten()
                                                                 
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'GP_v2_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'AR stronger':
        print(f'model is {model_selected}')

        file_path_4 = os.path.join(current_dir, 'data/data_step3', f'AR_stronger_test1_noise_{noise}_N={N}.mat')
        file_path_4 = scipy.io.loadmat(file_path_4)
        h = file_path_4['h'].flatten()
        predict4 = file_path_4['predict'].flatten()
        predict = predict4
        x_true = file_path_4['true'].flatten()
                                                                     
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'strong_AR_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'AR simple':
        print(f'model is {model_selected}')

        file_path_5 = os.path.join(current_dir, 'data/data_step3', f'AR1_simple_test1__noise_{noise}_N={N}.mat')
        file_path_5 = scipy.io.loadmat(file_path_5)
        h = file_path_5['h'].flatten()
        predict5 = file_path_5['predict'].flatten()
        predict = predict5

        file_path_1 = os.path.join(current_dir, 'data', f'non_GP_test1__noise_0_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()

                                                                    
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'simple_AR_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'scaled AR(1)':
        print(f'model is {model_selected}')

        file_path_6 = os.path.join(current_dir, 'data/data_step3', f'scaled_AR1_test1__noise_{noise}_N={N}.mat')
        file_path_6 = scipy.io.loadmat(file_path_6)
        h = file_path_6['h'].flatten()
        predict6 = file_path_6['predict'].flatten()
        predict = predict6

        file_path_1 = os.path.join(current_dir, 'data', f'non_GP_test1__noise_0_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()

                                                          
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'scaled_AR_test1_noise_{noise}_N={N}.pdf')



elif noise==1:
    if model_selected == 'non_GP':
        print(f'model is {model_selected}')

        file_path_1 = os.path.join(current_dir, 'data/data_step3', f'non_GP_test1__noise_{noise}_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        h = file_path_1['h'].flatten()
        predict1 = file_path_1['predict'].flatten()
        predict= predict1
        x_true = file_path_1['true'].flatten()
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'non_GP_test1_noise_{noise}_N={N}.pdf')
                                                              

    elif model_selected == 'GP v1':
        print(f'model is {model_selected}')

        file_path_2 = os.path.join(current_dir, 'data/data_step3', f'GP_version1_test1_noise_{noise}_N={N}.mat')
        file_path_2 = scipy.io.loadmat(file_path_2)
        predict2 = file_path_2['predict'].flatten()
        predict = predict2
        h = file_path_2['h'].flatten()
        x_true = file_path_2['true'].flatten()
                                                            
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'GP_v1_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'GP v2':
        print(f'model is {model_selected}')

        file_path_3 = os.path.join(current_dir, 'data/data_step3', f'GP_version2_test1_noise_{noise}_N={N}.mat')
        file_path_3 = scipy.io.loadmat(file_path_3)
        h3 = file_path_3['h'].flatten()
        predict3 = file_path_3['predict'].flatten()
        h = h3
        predict = predict3
        x_true = file_path_3['true'].flatten()
                                                            
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'GP_v2_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'AR stronger':
        print(f'model is {model_selected}')

        file_path_4 = os.path.join(current_dir, 'data/data_step3', f'AR_stronger_test1_noise_{noise}_N={N}.mat')
        file_path_4 = scipy.io.loadmat(file_path_4)
        predict4 = file_path_4['predict'].flatten()
        h = file_path_4['h'].flatten()
        predict = predict4
        x_true = file_path_4['true'].flatten()
                                                                
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'strong_AR_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'AR simple':
        print(f'model is {model_selected}')

        file_path_5 = os.path.join(current_dir, 'data/data_step3', f'AR1_simple_test1__noise_{noise}_N={N}.mat')
        file_path_5 = scipy.io.loadmat(file_path_5)
        h = file_path_5['h'].flatten()
        predict5 = file_path_5['predict'].flatten()
        predict = predict5
        file_path_1 = os.path.join(current_dir, 'data', f'non_GP_test1__noise_1_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()
                                                               
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'simple_AR_test1_noise_{noise}_N={N}.pdf')


    elif model_selected == 'scaled AR(1)':
        print(f'model is {model_selected}')

        file_path_6 = os.path.join(current_dir, 'data/data_step3', f'scaled_AR1_test1__noise_{noise}_N={N}.mat')
        file_path_6 = scipy.io.loadmat(file_path_6)
        predict6 = file_path_6['predict'].flatten()
        h = file_path_6['h'].flatten()
        predict = predict6
        file_path_1 = os.path.join(current_dir, 'data', f'non_GP_test1__noise_1_N={N}.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()
                                                     
        file_path_figure = os.path.join(current_dir, 'figures/figure_step3', f'scaled_AR_test1_noise_{noise}_N={N}.pdf')



           
                                    

                       
plt.rcParams.update({
    "text.usetex": True,                      
    "font.family": "serif",                    
    "font.serif": ["Times"],                         
    "text.latex.preamble": r"\usepackage{times}",                       
})
if model_selected == 'GP v2':
    plt.plot(h[1:], x_true[1:], linewidth=1, label='Reference', color='darkblue', marker='o', markersize=7, markerfacecolor='none')            
    for xi, yi in zip(h[s1::s2], x_true[s1::s2]):
        str_y = f'{yi:.4f}'
        parts = str_y.split('.')
        integer = parts[0]
        dec = parts[1]
        normal_dec = dec[:2]
        small_dec = dec[2:]
        if small_dec:
            text = r'{}.{}{{\small {}}}'.format(integer, normal_dec, small_dec)
        else:
            text = r'{}.{}'.format(integer, normal_dec)
        plt.text(xi, yi, text, fontsize=15, color='darkblue', ha='center', va='bottom', rotation=25)          

    plt.plot(h[1:], predict, linewidth=1, label='Predicted', color='darkred', marker='o', markersize=2)
    for xi, yi in zip(h[s1::s2], predict[s1::s2]):
        str_y = f'{yi:.4f}'
        parts = str_y.split('.')
        integer = parts[0]
        dec = parts[1]
        normal_dec = dec[:2]
        small_dec = dec[2:]
        if small_dec:
            text = r'{}.{}{{\small {}}}'.format(integer, normal_dec, small_dec)
        else:
            text = r'{}.{}'.format(integer, normal_dec)
        plt.text(xi, yi, text, fontsize=15, color='darkred', ha='center', va='top', rotation=25)          

else:
    plt.plot(h, x_true, linewidth=1, label='Reference', color='darkblue', marker='o', markersize=7, markerfacecolor='none')            
    for xi, yi in zip(h[s1::s2], x_true[s1::s2]):
        str_y = f'{yi:.5f}'
        parts = str_y.split('.')
        integer = parts[0]
        dec = parts[1]
        normal_dec = dec[:2]
        small_dec = dec[2:]
        if small_dec:
            text = r'{}.{}{{\small {}}}'.format(integer, normal_dec, small_dec)
        else:
            text = r'{}.{}'.format(integer, normal_dec)
        plt.text(xi, yi, text, fontsize=15, color='darkblue', ha='center', va='bottom', rotation=25)          

    plt.plot(h, predict, linewidth=1.5, label='Predicted', color='darkred', marker='o', markersize=2)
    for xi, yi in zip(h[s1::s2], predict[s1::s2]):
        str_y = f'{yi:.5f}'
        parts = str_y.split('.')
        integer = parts[0]
        dec = parts[1]
        normal_dec = dec[:2]
        small_dec = dec[2:]
        if small_dec:
            text = r'{}.{}{{\small {}}}'.format(integer, normal_dec, small_dec)
        else:
            text = r'{}.{}'.format(integer, normal_dec)
        plt.text(xi, yi, text, fontsize=15, color='darkred', ha='center', va='top', rotation=25)          

                        
                                                                                                

               
                         
                         

               
plt.tick_params(axis='both', labelsize=15)
                         
                                                  

lgd = plt.legend(
    fontsize=25,
    frameon=True,
    edgecolor='black',                  
    framealpha=1
)
lgd.get_frame().set_linestyle((0, (10, 5)))

plt.grid(True, alpha=0.39)
plt.xlabel('h',fontsize = 25)
plt.ylabel(r'$\theta^*$',fontsize = 25)

plt.tight_layout()

plt.savefig(file_path_figure, dpi=300)

plt.show()