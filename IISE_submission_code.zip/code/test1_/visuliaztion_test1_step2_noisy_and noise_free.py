import matplotlib.pyplot as plt
import numpy as np
import  scipy.io

task = 2
index = [0,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16,  18]


N = 50
if N == 50:
    data_noise_free_1 = scipy.io.loadmat('N=50noise_free_test1_theta_set.mat')
if N == 30:
    data_noise_free_1 = scipy.io.loadmat('N=30_test2_noise_free_N_a__a_optimal_set.mat')
if N == 20:
    data_noise_free_1 = scipy.io.loadmat('N=20_test2_noise_free_N_a__a_optimal_set.mat')
if N == 15:
    data_noise_free_1 = scipy.io.loadmat('N=15_test2_noise_free_N_a__a_optimal_set.mat')
if N == 10:
    data_noise_free_1 = scipy.io.loadmat('N=10_test2_noise_free_N_a__a_optimal_set.mat')


h_1 = data_noise_free_1['h_set'].flatten()
h_1 = h_1[index]
a_1 = data_noise_free_1['a_optimal_set'].flatten()
a_1 = a_1[index]

if N == 50:
    data_noisy_1 = scipy.io.loadmat('N=50noisy_test1_theta_set.mat')

if N == 30:
    data_noisy_1 = scipy.io.loadmat('')
if N == 20:
    data_noisy_1 = scipy.io.loadmat('')
if N == 15:
    data_noisy_1 = scipy.io.loadmat('')
if N == 10:
    data_noisy_1 = scipy.io.loadmat('')


h_3 = data_noisy_1['h_set'].flatten()
h_3 = h_3[index]
a_3 = data_noisy_1['a_optimal_set'].flatten()
a_3 = a_3[index]


line1, = plt.plot(h_1, a_1, marker='o', markersize=6, label='noise-free', linewidth=1.5)
line2, = plt.plot(h_3, a_3, marker='o', markersize=6, label='noisy', linewidth=1.5)


data = {
    'h_1': h_1,
    'a_1': a_1,
    'h_3': h_3,
    'a_3': a_3,
}
scipy.io.savemat(f'data/data_step2/test1_N={N}_step2_noisy_and_noise_free.mat', data)



index_plot = [0, 3,6,9,12,15,-1]

for xi, yi in zip(h_1[index_plot], a_1[index_plot]):
    plt.text(xi, yi, f'{yi:.3f}', fontsize=10, color=line1.get_color(), ha='center', va='bottom', rotation=-45)

for xi, yi in zip(h_3[index_plot], a_3[index_plot]):
    plt.text(xi, yi, f'{yi:.3f}', fontsize=10, color=line2.get_color(), ha='center', va='top', rotation=-45)

index_plot = [0, 2, 4, 6, 8,10,12,14,15,-1]
plt.xlabel('h', fontsize=15)
plt.ylabel(fr'$\theta$', fontsize=15)
plt.xticks(h_1[index_plot])
plt.tick_params(axis='both', labelsize=12)

if task == 1:
    a = 1
if task == 2:
    a = 1
plt.legend(fontsize=15)
plt.grid(True, linewidth=0.3)
plt.tight_layout()
plt.savefig(f'figures/figure_step2/test1_N={N}_step2_noisy_and_noise_free.pdf', dpi=300)
plt.show()
