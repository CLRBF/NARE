import numpy as np
import matplotlib.pyplot as plt
import os
import scipy.io
import torch
import argparse
import torch
import random
from data_provider.save_experiment_data_complex import save_experiment_data_complex

n = np.random.randint(1, 1000)            
           
    
      
    
seed = n

           

                 
             
              

print('当前随机种子：', seed)
def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
seed_everything(seed)




                         
                                      
def covariance_Brownian(sigma, t1, t2):
    return sigma**2 * torch.min(t1, t2)

def stationary(sigma, t1, t2):
                                         
    return sigma**2 * torch.exp(-(t1-t2)**2)

                             
def covariance_type2(sigma, l, t1, t2):
    return sigma*torch.sqrt(t1*t2) * torch.exp(-torch.square(t1 - t2) / l)

                            
def compute_next_theta(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[covariance_Brownian(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_Brownian(sigma, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu
                            
def compute_next_theta_2(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[covariance_type2(sigma,l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_type2(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu
                        
def compute_next_theta_3(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[stationary(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def covariance(x1, x2, sigma, length_scale):

    return sigma ** 2 * np.exp(-(x1 - x2) ** 2 / (2 * length_scale ** 2))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='GP SSM Experiment')
    parser.add_argument('--sigma_kriging', type=float,  default=100, help='Noise level: 0 for noise-free, 1 for noisy')
    parser.add_argument('--length', type=float,  default=1, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    parser.add_argument('--version', type=int,  default=1, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    parser.add_argument('--K', type=float,  default=1e-8, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    parser.add_argument('--noise', type=float, default=0, help='Noise level: 0 for noise-free, 1 for noisy')

    args = parser.parse_args()
    noise = args.noise


    current_dir = os.path.dirname(os.path.abspath(__file__))
    N = 50
    if noise==0:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noise_free_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0,:]
        h_true = data_noise_free['h_set'][0,:]
    elif noise==1:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0,:]
        h_true = data_noise_free['h_set'][0,:]

                      
    elif noise == 0.05:
        data_noise_free  = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.05noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0,:]
        h_true = data_noise_free['h_set'][0,:]
    elif noise == 0.1:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.1noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0,:]
        h_true = data_noise_free['h_set'][0,:]


    h_true = list(reversed(h_true))              
    X_true = list(reversed(X_true))
    print('h',len(h_true),h_true)

    x_train = h_true[:-1]
    f_train = X_true[:-1]

    x_all = h_true
    f_all = X_true

    good = 0

    version = args.version

                                         
                                
                

    n = np.random.randint(1, 10)            

    SIGMAS = [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 100, 1000]
    LENGTHS = [1e-3, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.20, 0.25, 0.30, 1, 10, 100, 10000]
    K_VALUES = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8]

    sigma_kriging = random.choice(SIGMAS)
    length_scale = random.choice(LENGTHS)
    K = random.choice(K_VALUES)

                                    
    sigma_kriging = 100
    length_scale = 1
    K = 1e-3


                                    
    sigma = 1
    l =1
    C = 1e-4
    theta_new = []

    h = torch.tensor(h_true)              
    theta_hat = torch.tensor(X_true)                                      

    for check in range(1, len(h)):
        if version == 1:
            next_theta = compute_next_theta(check, theta_hat, h)
        elif version == 2:
            next_theta = compute_next_theta_2(check, theta_hat, h)
        elif version==3:
            next_theta = compute_next_theta_3(check, theta_hat, h)
        theta_new.append(next_theta)

    mu_original = theta_new
    x_train = x_train[1:]
    f_train = f_train[1:]
    f_train = f_train - np.array(mu_original)[:-1]
    x_all = x_all[1:]
    f_all = f_all[1:]
    f_all = f_all - np.array(mu_original)
    F_train = np.vstack([np.ones_like(x_train), x_train]).T                                     
    n_train = len(x_train)

    C = np.zeros((n_train, n_train))
    for i in range(n_train):
        for j in range(n_train):
            C[i, j] = covariance(x_train[i], x_train[j],sigma_kriging,length_scale)

                                           
    C = C + K * np.eye(n_train)
    C_inv = np.linalg.inv(C)                             
    beta_hat = np.linalg.inv(F_train.T @ C_inv @ F_train) @ F_train.T @ C_inv @ f_train

    def predict(x0):
        f0 = np.array([1, x0])
        c0 = np.array([covariance(x0, xi,sigma_kriging,length_scale) for xi in x_train])
        residual = f_train - F_train @ beta_hat
        return f0 @ beta_hat + c0 @ C_inv @ residual

    x_pred = x_all
    y_pred = np.array([predict(x) for x in x_pred])
    prediction_0 = predict(0) +np.array(mu_original)[-1]
    plt.scatter(x_all, f_all+np.array(mu_original), s=10, c='blue',
                label='All original points', alpha=0.7, zorder=10)
    plt.plot(x_all, y_pred+np.array(mu_original), 'r-',
             label='Universal Kriging prediction', alpha=0.8)

    def compute_single(true, predicted):
        relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
        MSE = np.mean((predicted - true) ** 2)
        return relative_l2, MSE

    def compute_relative_l2(true, predicted):
        relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
        MSE = np.mean((predicted - true) ** 2)
        return relative_l2, MSE

                     
                                                       
                                   
                                    
    x_plot_true = f_all + np.array(mu_original)
    predict_h0 = (y_pred + np.array(mu_original))[-1]
    print('predict_h0', predict_h0)

    single_point_error_relative, single_point_error_mse = compute_single((f_all + np.array(mu_original))[-1],
                                                                         (y_pred + np.array(mu_original))[-1])
    print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
    relative_l2, LOOCV_MSE = compute_relative_l2((f_all + np.array(mu_original))[:-1], (y_pred + np.array(mu_original))[:-1])
    print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
    LOOCV_MSE = LOOCV_MSE + single_point_error_mse              

    print('sigma_kriging,length_scale,K', sigma_kriging,length_scale,K)

    data = {'predict': y_pred+np.array(mu_original),
            'predict_h0': predict_h0,
            'seed': seed,
            'h': x_all,
            'true': x_plot_true,
            'sigma_kriging': sigma_kriging,
            'length_scale': length_scale,
            'single_point_error_relative': single_point_error_relative,
            'single_point_error_mse': single_point_error_mse,
            'relative_l2': relative_l2,
            'LOOCV_MSE': LOOCV_MSE,
                                         
            }

    file_path_data = os.path.join(current_dir, '..', 'data/data_step3',
                                  f'non_GP_test1__noise_{noise}_N={N}_{seed}_sigma_kriging{sigma_kriging}_l{l}.mat')
                                            

    folder = os.path.join(current_dir, 'data_csv')
    if noise == 0:
        filename = 'non_gp_noise_free.csv'
    elif noise == 1:
        filename = 'non_gp_noisy.csv'
    elif noise == 0.05:
        filename = 'non_gp_std_0.05_noisy.csv'
    elif noise == 0.1:
        filename = 'non_gp_std_0.1_noisy.csv'

    params_init = [sigma_kriging, length_scale, K   ]
    params_opt = [sigma_kriging, length_scale, K   ]

    save_experiment_data_complex(single_point_error_relative, single_point_error_mse, relative_l2, LOOCV_MSE,
                                 predict_h0,
                                 seed, params_init, params_opt, folder=folder, filename=filename)

            
    true_last =  f_all[-1]+np.array(mu_original)[-1]
    predict_last = y_pred[-1] + np.array(mu_original)[-1]
    diff = true_last - predict_last
    if np.abs(diff) < 0.05:
        good = 1
        print("Prediction is good! Difference is small:", diff
              )
    else:
        good = 0
        print("Prediction is bad! Difference is large:", diff)



    plt.title(f'UK sigma kriging{sigma_kriging} l{length_scale}', fontsize=16)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('f(x)', fontsize=14)
    plt.legend(fontsize=12, loc='upper right')
    plt.grid(alpha=0.3)
    plt.text(0.05, -0.68,
             r"$Z(x_0) = \mathbf{f}(x_0)^T \hat{\beta} + \mathbf{c}_0^T \mathbf{C}^{-1} (\mathbf{Z} - \mathbf{F}\hat{\beta})$",
             fontsize=10, bbox=dict(facecolor='white', alpha=0.9))
    plt.text(0.05, -0.7,
             r"$\hat{\beta} = (\mathbf{F}^T \mathbf{C}^{-1} \mathbf{F})^{-1} \mathbf{F}^T \mathbf{C}^{-1} \mathbf{Z}$",
             fontsize=10, bbox=dict(facecolor='white', alpha=0.9))

    plt.tight_layout()
                                                                                                                                                 

                

    print(f"Predicted value f(0) = {prediction_0:.6f}")
    print(f"ground_truth f(0) = {f_all[-1]:.6}")
