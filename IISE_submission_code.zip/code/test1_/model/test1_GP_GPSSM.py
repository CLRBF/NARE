import numpy as np
import torch
import scipy.io
import matplotlib.pyplot as plt
import os
import random
from data_provider.save_experiment_data import save_experiment_data
from data_provider.save_experiment_data_complex import save_experiment_data_complex
from visualization.visualization_test1 import plot_test1_ours_complex
import argparse

n = np.random.randint(1, 1000)            
           
            
      
        

           
         
        
         

seed = n


print('当前随机种子：', seed)


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything(seed)

                               
def stationary(sigma, l,t1, t2):
    return sigma**2 * torch.exp(-(t1-t2)**2/(2 * l**2))

                                              
def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true)**2)) / np.sqrt(np.sum((true)**2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true)**2)) / np.sqrt(np.sum((true)**2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

             
def compute_next_theta(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
                              
    y = theta_hat[0:check]
    y = torch.tensor(y)
                                                                  
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

                   
def compute_next_theta_v2(check, theta_hat,h):
                       
    train_xt = torch.tensor(theta_hat)
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[1:check+1]
                            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu




if  __name__ == "__main__":
    parser = argparse.ArgumentParser(description='GP SSM Experiment')
    parser.add_argument('--noise', type=float, default=1, help='Noise level: 0 for noise-free, 1 for noisy')
    parser.add_argument('--version', type=int, choices=[1, 2], default=1, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    args = parser.parse_args()

    noise   = args.noise
    version = args.version

    current_dir = os.path.dirname(os.path.abspath(__file__))
    N = 50
    alpha_candidates = [1e-2, 1e-3, 1e-4]
    alpha = random.choice(alpha_candidates)                                    

    sigma = random.uniform(0, 10)
    l = random.uniform(0, 10)

    sigma=1
    l=1
    alpha = 1e-2


    n = np.random.randint(1, 1000)            
    seed = n

    if noise == 0:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noise_free_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0, :]
        h_true = data_noise_free['h_set'][0, :]
    elif noise == 1:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0, :]
        h_true = data_noise_free['h_set'][0, :]

                       
    elif noise == 0.05:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.05noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0, :]
        h_true = data_noise_free['h_set'][0, :]
    elif noise == 0.1:
        data_noise_free = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.1noisy_test1_theta_set.mat'))
        X_true = data_noise_free['a_optimal_set'][0, :]
        h_true = data_noise_free['h_set'][0, :]

    h_true = list(reversed(h_true))               
    X_true = list(reversed(X_true))
    print('h', len(h_true), h_true)

    h = torch.tensor(h_true)               
    theta_hat = torch.tensor(X_true)                                       
    theta_new = []

    if version == 1:
        for check in range(1, len(h)):
            next_theta = compute_next_theta(check, theta_hat, h)
            theta_new.append(next_theta)

    else:
        theta_hat = theta_hat[:-1]
        for check in range(1, len(h) - 1):
            next_theta = compute_next_theta_v2(check, theta_hat, h)
            theta_new.append(next_theta)

    print('theta_new', np.array(theta_new), len(np.array(theta_new)))



    if version == 1:
        plt.plot(h_true[1:], theta_new, linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
        for xi, yi in zip(h_true[1:], theta_new):
            plt.text(xi, yi, f'{yi:.3f}', fontsize=8, color='red', ha='center', va='top', rotation=-45)          

        plt.plot(h_true[1:], X_true[1:], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
        for xi, yi in zip(h_true[1:], X_true[1:]):
            plt.text(xi, yi, f'{yi:.3f}', fontsize=8, color='blue', ha='center', va='bottom', rotation=45)          

        print('true', np.array(X_true[1:]))
        print('predicted', np.array(theta_new))

                         
        single_point_error_relative, single_point_error_mse = compute_single(np.array(theta_new[-1]), np.array(X_true[1:][-1]))
        print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
        relative_l2,LOOCV_MSE  = compute_relative_l2(np.array(theta_new[:-1]), np.array(X_true[1:][:-1]))
        print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
        LOOCV_MSE = LOOCV_MSE + single_point_error_mse              
        predict_h0 = theta_new[-1]
        print('predict_h0', predict_h0)

                             
        params_init = [alpha, sigma, l]
        print('params_init', params_init)
        params_opt = [alpha, sigma, l]
        print('params_opt', params_opt)

        data = {'predict': theta_new,
                'predict_h0': predict_h0,
                'seed': seed,
                'h': h_true[1:],
                'true': X_true[1:],
                'sigma': sigma,
                'l': l,
                'alpha': alpha,
                'single_point_error_relative': single_point_error_relative,
                'single_point_error_mse': single_point_error_mse,
                'relative_l2': relative_l2,
                'LOOCV_MSE': LOOCV_MSE,
                'params_init': params_init,
                }


        file_path_data = os.path.join(current_dir, '..', 'data/data_step3',
                                      f'GP_version1_test1_noise_{noise}_N={N}_sigma_{sigma}_l_{l}_C{params_init[0]}.mat')


        folder = os.path.join(current_dir, 'data_csv')

        if noise == 0:
            filename = 'GP_noise_free.csv'
        elif noise == 1:
            filename = 'GP_noisy.csv'
        elif noise == 0.05:
            filename = 'GP_noisy_std_0.05_noisy.csv'
        elif noise == 0.1:
            filename = 'GP_noisy_std_0.1_noisy.csv'

        save_experiment_data_complex(single_point_error_relative, single_point_error_mse,relative_l2,LOOCV_MSE,predict_h0,seed, params_init,params_opt,folder=folder,filename=filename)
        scipy.io.savemat(file_path_data, data)
        plt.xticks(h_true[1:], [f'{h:.2f}' for h in h_true[1:]], fontsize=7)
        plt.legend()
        plt.xlabel('h')
        plt.ylabel(r'$\theta^*(h)$')
                                                                                                           
                    

    else:
        plt.plot(h_true[2:], theta_new, linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
        for xi, yi in zip(h_true[2:], theta_new):
            plt.text(xi, yi, f'{yi:.3f}', fontsize=8, color='red', ha='center', va='top', rotation=-45)          

        plt.plot(h_true[2:], X_true[2:], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
        for xi, yi in zip(h_true[2:], X_true[2:]):
            plt.text(xi, yi, f'{yi:.3f}', fontsize=8, color='blue', ha='center', va='bottom', rotation=45)          

        plt.xticks(h_true[2:], [f'{h:.2f}' for h in h_true[2:]], fontsize=7)

                                                                                                                   
                                       

                         
        single_point_error_relative, single_point_error_mse = compute_single(np.array(theta_new[-1]), np.array(X_true[2:][-1]))
        print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
        relative_l2,LOOCV_MSE = compute_relative_l2(np.array(theta_new[:-1]), np.array(X_true[2:][:-1]))
        print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
        LOOCV_MSE = LOOCV_MSE + single_point_error_mse              

        predict_h0 = theta_new[-1]
        print('predict_h0', predict_h0)

                             
        params_init = [alpha, sigma, l]
        print('params_init', params_init)
        params_opt = [alpha, sigma, l]
        print('params_opt', params_opt)

        data = {'predict': theta_new,
                'predict_h0': predict_h0,
                'seed': seed,
                'h': h_true[1:],
                'true': X_true[1:],
                'sigma': sigma,
                'l': l,
                'alpha': alpha,
                'single_point_error_relative': single_point_error_relative,
                'single_point_error_mse': single_point_error_mse,
                'relative_l2': relative_l2,
                'LOOCV_MSE': LOOCV_MSE,
                'params_init': params_init,
                }

        file_path_data = os.path.join(current_dir, '..', 'data/data_step3',
                                      f'GP_version2_test1_noise_{noise}_N={N}_sigma_{sigma}_l_{l}_C{params_init[0]}.mat')
        scipy.io.savemat(file_path_data, data)
        folder = os.path.join(current_dir, 'data_csv')

        if noise == 0:
            filename = 'GP_SSM_noise_free.csv'
        elif noise == 1:
            filename = 'GP_SSM_noisy.csv'
        elif noise == 0.05:
            filename = 'GP_SSM_std_0.05_noisy.csv'
        elif noise == 0.1:
            filename = 'GP_SSM_std_0.1_noisy.csv'

        params_init = [alpha, sigma, l]
        params_opt = [alpha, sigma, l]

                                                                                                                          
                                                                                                                                                                                                        
        save_experiment_data_complex(single_point_error_relative, single_point_error_mse,relative_l2,LOOCV_MSE,predict_h0,seed, params_init,params_opt,folder=folder,filename=filename)

        print('true', np.array(X_true[2:]))
        print('predicted', np.array(theta_new))

        plt.legend()
        plt.xlabel('h')
        plt.ylabel(r'$\theta^*(h)$')
                                                                                                           
                    








