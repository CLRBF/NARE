import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.optimize import least_squares
import random
import os
import csv
from pathlib import Path
from datetime import datetime
from data_provider.save_experiment_data_complex import save_experiment_data_complex
import torch


n = np.random.randint(1, 1000)            
           
       
      
n=641
seed = n

                 
              
             

noise = 0


print('当前随机种子：', seed)
def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
seed_everything(seed)

current_dir = os.path.dirname(os.path.abspath(__file__))
N = 50
if noise==0:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noise_free_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]
elif noise==1:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]

                  
elif noise == 0.05:
    data_noise_free  = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.05noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]
elif noise == 0.1:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.1noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]


X_true_original = X_true
X_true_original= list(reversed(X_true_original))
h_true_original = h_true
h_true_original = list(reversed(h_true_original))

h_true = h_true[1:]
X_true = X_true[1:]

h_true = list(reversed(h_true))                 
X_true = list(reversed(X_true))

delta_t = 0.05            
t_scaled = h_true
x_scaled = X_true
k = np.diff(t_scaled) / delta_t
k = np.abs(k)

x_i = x_scaled[:-1]
y_i = x_scaled[1:]

def residuals(params, x_i, y_i, k):
    phi, c = params
    if abs(phi - 1) < 1e-8:                  
        pred = x_i + c * k
    else:
        pred = phi**k * x_i + c * (1 - phi**k) / (1 - phi)
    return y_i - pred

params_init = np.round(np.random.uniform(low=0, high=5, size=2), 1)
print('*******', params_init, '*********')

bounds = ([-100, -100], [100, 100])

                         
method='trf'
             
                 

result = least_squares(residuals, params_init, args=(x_i, y_i, k), method = method)
phi_est, c_est = result.x
print(f"Estimated phi and c: {phi_est:.6f},{c_est:.6f}")

def predict_ar1(phi, c, x0, k_list):
    predictions = [x0]
    x_current = x0
    for k in k_list:
        if abs(phi - 1) < 1e-8:
            x_next = x_current + c * k
        else:
            x_next = phi**k * x_current + c * (1 - phi**k) / (1 - phi)
        predictions.append(x_next)
        x_current = x_next
    return np.array(predictions)

         
x0 = x_scaled[0]
              
                        
k = np.append(k, 1)
predicted_x = predict_ar1(phi_est, c_est, x0, k)              
print("Predicted values at t:")

                 
t_NEW = np.append(t_scaled[1:],np.array([0]))

for t_val, pred in zip(t_scaled, predicted_x):
    print(f"t = {t_val:.2f}, predicted x = {pred:.6f}")

                                             
plt.plot(t_NEW, X_true_original[1:], linewidth= 1,label='True', color='blue', marker='o',markersize=2)            

                               
plt.plot(t_NEW, predicted_x[1:], linestyle = 'dashed',label='Predicted', color='red',marker='o',markersize=2)

           
plt.scatter(t_NEW[-1], np.array(X_true_original[1:])[-1], label='h=0, true', color='black',marker='^',s= 50)
plt.scatter(t_NEW[-1], np.array(predicted_x[1:])[-1], label='h=0, predicted', color='black',marker='*',s= 50)

          
index = [1,3,5,7,9,11,13,15,17,19]

t_NEW_index = t_NEW[index]
predict_x_index = np.array(predicted_x[1:])
predict_x_index = predict_x_index[index]
X_true_original_index = np.array(X_true_original[1:])
X_true_index = X_true_original_index[index]

for xi, yi in zip(t_NEW_index,predict_x_index):
    plt.text(xi, yi, f'{yi:.3f}',fontsize=10, color='red', ha='center', va='top',rotation = -45)          

for xi, yi in zip(t_NEW_index, X_true_index):
    plt.text(xi, yi, f'{yi:.3f}', fontsize=10,color='blue', ha='center', va='bottom',rotation=45)          

print('predicted_x[1:]',predicted_x[1:])
print('x_scaled[1:]',X_true_original[1:])
print('diff',np.array(predicted_x[1:])-np.array(X_true_original[1:]))

                                              
def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true)**2)) / np.sqrt(np.sum((true)**2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true)**2)) / np.sqrt(np.sum((true)**2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2,MSE

                
single_point_error_relative, single_point_error_mse = compute_single(np.array(X_true_original[1:][-1]),np.array(predicted_x[1:][-1]))
print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
relative_l2,LOOCV_MSE = compute_relative_l2(np.array(X_true_original[1:][:-1]), np.array(predicted_x[1:][:-1]))
print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
LOOCV_MSE = LOOCV_MSE + single_point_error_mse              

predict_h0 = predicted_x[1:][-1]
print('predict_h0', predict_h0)

x_plot_true = X_true_original[1:]

data = {'predict': predicted_x[1:],
        'predict_h0': predict_h0,
        'seed': seed,
        'h': t_NEW,
        'true': x_plot_true,
        'phi': phi_est,
        'c': c_est,
        'single_point_error_relative': single_point_error_relative,
        'single_point_error_mse': single_point_error_mse,
        'relative_l2': relative_l2,
        'LOOCV_MSE': LOOCV_MSE,
        'params_init': params_init,
        }


params_opt = [phi_est, c_est]
folder = os.path.join(current_dir, 'data_csv')
if noise == 0:
    filename = 'AR(1)_noise_free.csv'
elif noise == 1:
    filename = 'AR(1)_noisy.csv'
elif noise == 0.05:
    filename = 'AR(1)_std_0.05_noisy.csv'
elif noise == 0.1:
    filename = 'AR(1)_std_0.1_noisy.csv'


                                                                
file_path_data = os.path.join(current_dir, '..', 'data/data_step3', f'scaled_AR1_test1__noise_{noise}_N={N}_seed_{seed}.mat')
scipy.io.savemat(file_path_data, data)
save_experiment_data_complex(single_point_error_relative, single_point_error_mse, relative_l2, LOOCV_MSE, predict_h0,
                             seed, params_init, params_opt, folder=folder, filename=filename)


plt.legend()
plt.xticks(t_NEW, [f'{h:.2f}' for h in h_true_original[1:]],fontsize=7)
plt.xlabel('h')
plt.ylabel(r'$\theta^*(h)$')
plt.title('AR(1) with OLS test1')
                                                                                        
plt.show()
