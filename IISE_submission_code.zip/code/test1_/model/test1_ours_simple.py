import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.optimize import least_squares
import random
import os
import csv
from pathlib import Path
from datetime import datetime
from data_provider.save_experiment_data import save_experiment_data
import torch
from data_provider.save_experiment_data_complex import save_experiment_data_complex
from visualization.visualization_test1 import plot_test1_ours_complex


n = np.random.randint(1, 1000)            

noise = 1


                 
noise = 0.1
              


      
if noise==1:
    n = 436                 
else:
                
    n = 538                       




seed = n


print('当前随机种子：', seed)

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything(seed)

current_dir = os.path.dirname(os.path.abspath(__file__))
N = 50
if noise==0:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noise_free_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]
elif noise==1:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, 'N=50noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]

                  
elif noise == 0.05:
    data_noise_free  = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.05noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]
elif noise == 0.1:
    data_noise_free = scipy.io.loadmat(os.path.join(current_dir, '2026_N=50_std_0.1noisy_test1_theta_set.mat'))
    X_true = data_noise_free['a_optimal_set'][0,:]
    h_true = data_noise_free['h_set'][0,:]


X_true_original = X_true
X_true_original= list(reversed(X_true_original))
h_true_original = h_true
h_true_original = list(reversed(h_true_original))

index_non_AR = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

h_true = h_true[1:][index_non_AR]
X_true = X_true[1:][index_non_AR]

h_true = list(reversed(h_true))                 
X_true = list(reversed(X_true))

X_true_index = np.append(X_true,X_true_original[-1])
h_true_index = np.append(h_true,h_true_original[-1])

t_scaled = h_true
x_scaled = X_true

x_i = x_scaled[:-1]
y_i = x_scaled[1:]

                   
def residuals_2(params, x_i, y_i,h1,h2):
    alpha, beta = params
    pred = x_i + alpha * (h1**beta-h2**beta)
                 
    return y_i - pred
       
                                    

                         
def predict_ar2(alpha, beta, x0,h1,h2,x_i,y_i):
        
    x_i.append(y_i[-1])
    pred = x_i + alpha * (h1**beta-h2**beta)
    return np.array(pred)


if __name__ == "__main__":


    params_init = np.round(np.random.uniform(low=0, high=5, size=2), 1)
    print('*******', params_init, '*********')

    bounds = ([-100, -100], [100, 100])

    method='trf'
                 
                     

    h1 = h_true[1:]
    h2 = h_true[:-1]

    result = least_squares(residuals_2, params_init, args=(x_i, y_i, h1,h2), method = method)
    phi_est, c_est = result.x
    alpha,beta =  result.x
    print(f"Estimated phi and c: {phi_est:.6f},{c_est:.6f}")

    x0 = x_scaled[0]
    h2 = np.append(h2, h1[-1])
    h1 = np.append(h1, 0)
    predicted_x = predict_ar2(alpha, beta, x0, h1,h2,x_i,y_i)              

                                             
                                             
    predicted_x = np.insert(predicted_x, 0, x0)
    print("Predicted values at t:")
    relative_error = np.sqrt(np.sum((predicted_x[0:-1]-X_true_index[0:-1])**2)/np.sum((X_true_index[0:-1])**2))
    print('relative_error',relative_error)


    if np.abs(predicted_x[1:][-1]-X_true_index[1:][-1]) < 0.001:
        print('**************************good result**************************')
    else:
        print('bad result',X_true_index[1:][-1],predicted_x[1:][-1], np.abs(predicted_x[1:][-1]-X_true_index[1:][-1]))


    t_NEW = np.append(t_scaled[1:],np.array([0]))
    for t_val, pred in zip(t_NEW, predicted_x[1:]):
        print(f"t = {t_val:.2f}, predicted x = {pred:.6f}")

                        
                                                   
    def compute_single(true, predicted):
        relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
        MSE = np.mean((predicted - true) ** 2)
        return relative_l2, MSE

    def compute_relative_l2(true, predicted):
        relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
        MSE = np.mean((predicted - true) ** 2)
        return relative_l2,MSE

    single_point_error_relative, single_point_error_mse  = compute_single(np.array(X_true_original[1:][-1]), np.array(predicted_x[1:][-1]))
    print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
    relative_l2,LOOCV_MSE  = compute_relative_l2(np.array(X_true_original[1:][:-1]), np.array(predicted_x[1:][:-1]))
    print('relative_l2,loocv_MSE', relative_l2,LOOCV_MSE)
    LOOCV_MSE = LOOCV_MSE + single_point_error_mse            

    predict_h0 = predicted_x[1:][-1]
    print('predict_h0', predict_h0)
    gamma1 = 0
    gamma2 = 0
    x_plot_true = X_true_index[1:]
    predicted = predicted_x[1:]
    data = {'predict': predicted_x[1:],
            'predict_h0': predict_h0,
            'seed': seed,
            'h': t_NEW,
            'true': x_plot_true,
            'alpha': alpha,
            'beta': beta,
            'gamma1': gamma1,
            'gamma2': gamma2,
            'single_point_error_relative': single_point_error_relative,
            'single_point_error_mse': single_point_error_mse,
            'relative_l2': relative_l2,
            'LOOCV_MSE': LOOCV_MSE,
            'params_init': params_init,
            }

    params_opt = [alpha, beta]
    file_path_data = os.path.join(current_dir, '..', 'data_0715', f'AR1_simple_test1__noise_{noise}_N={N}_seed={seed}.mat')
    scipy.io.savemat(file_path_data, data)


    folder = os.path.join(current_dir, 'data_csv')
    if noise == 0:
        filename = 'ours_simple_noise_free.csv'
    elif noise == 1:
        filename = 'ours_simple_noisy.csv'
    elif noise == 0.05:
        filename = 'ours_simple_std_0.05_noisy.csv'
    elif noise == 0.1:
        filename = 'ours_simple_std_0.1_noisy.csv'

    if np.abs(predicted_x[1:][-1]-X_true_index[1:][-1]) < 0.003:
        file_path_data = os.path.join(current_dir, '..', 'data/data_step3', f'AR1_simple_test1__noise_{noise}_N={N}_seed={seed}.mat')
        scipy.io.savemat(file_path_data, data)
        save_experiment_data_complex(single_point_error_relative, single_point_error_mse,relative_l2,LOOCV_MSE,predict_h0,seed, params_init,params_opt,folder=folder,filename=filename)


    print('predicted_x[1:]',predicted_x[1:])
    print('x_scaled[1:]',X_true_original[1:])


    x_plot_true = np.append(x_scaled[1:], X_true_original[-1])
    plot_test1_ours_complex(t_NEW, predicted_x, x_plot_true)

    plt.show()


