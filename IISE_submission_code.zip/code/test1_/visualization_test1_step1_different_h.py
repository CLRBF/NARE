import numpy as np
import matplotlib.pyplot as plt
import random
import torch
import argparse
import scipy.io

def kernel(xi, xj, alpha):
    return beta*np.exp(-0.5*l*np.sum((xi - xj)**2))

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything(42)

def y_s(x, theta,h):
    return np.exp(a*x)*np.sin(x) - 0.1*np.sqrt((h*theta)**2+1)*(np.sin(theta*x)+np.cos(theta*x))

def L2_norm_difference(x, theta,h):
    diff = y_s(x, theta,h) - z
    return np.sqrt(np.sum(diff**2)/np.sum(z**2))

def obtain_beta_theta(theta_values, x_z, h):
    best_theta = None
    smallest_L2_norm = float('inf')

    for theta in theta_values:
        current_L2_norm = L2_norm_difference(x_z, theta, h)
        if current_L2_norm < smallest_L2_norm:
            smallest_L2_norm = current_L2_norm
            best_theta = theta
    return best_theta, smallest_L2_norm


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Hyperparameters')
    parser.add_argument('--h', default=0, type=int, help='mesh size')
    parser.add_argument('--region_l', default=-1, type=float, help='number of temporal points')
    parser.add_argument('--region_r', default=1, type=float, help='number of temporal points')
    parser.add_argument('--numbergrid', default=100000, type=int, help='number of temporal points')
    pars = parser.parse_args()

    beta = 1
    l = 1
    N = 50
    a = 0.1
    std = 0
    std2 = 0

    f_true = lambda x: np.exp(a * x) * np.sin(x)
    noise = np.random.normal(0, std, N)  

    i = np.arange(1, N + 1)
    x_true = 0.5 * np.pi * i / N

    y_true = f_true(x_true)
    y_true += noise

    x_z = np.linspace(0, 0.5 * np.pi, N)

    Phi = np.array([[kernel(xi, xj, 10.0) for xj in x_true] for xi in x_z]) + std2 ** 2 * np.eye(
        N)
    Y = y_true
    u = np.linalg.solve(Phi, Y)
    z = Phi @ u
    y_true_x_z = f_true(x_z)

    h_set = [0,0.2,0.4,0.6,0.8]
    theta = 2
    y_1 = y_s(x_z, theta, h_set[0])
    y_2 = y_s(x_z, theta, h_set[1])
    y_3 = y_s(x_z, theta, h_set[2])
    y_4 = y_s(x_z, theta, h_set[3])
    y_5 = y_s(x_z, theta, h_set[4])
    y_true = f_true(x_z)

    error1 = np.sqrt(np.sum(np.square(y_1 - y_true)) / np.sum(y_true ** 2))
    error2 = np.sqrt(np.sum(np.square(y_2 - y_true)) / np.sum(y_true ** 2))
    error3 = np.sqrt(np.sum(np.square(y_3 - y_true)) / np.sum(y_true ** 2))
    error4 = np.sqrt(np.sum(np.square(y_4 - y_true)) / np.sum(y_true ** 2))
    error5 = np.sqrt(np.sum(np.square(y_5 - y_true)) / np.sum(y_true ** 2))

    print(f'error1: {error1}, error2: {error2}, error3: {error3}, error4: {error4}, error5: {error5}')

    data = {
        'x_z': x_z,
        'y_true_x_z': y_true_x_z,
        'y_1': y_1,
        'y_2': y_2,
        'y_3': y_3,
        'y_4': y_4,
        'y_5': y_5,
    }

    scipy.io.savemat(f'data/data_step2/test1_different_h_N={N}.mat', data)

    plt.plot(x_z, y_true_x_z, label=fr'$\xi(x)$',color ='blue', linewidth=1)
    plt.plot(x_z, y_1, label=fr'$y^s(h={h_set[0]})$', color='red', linewidth=1)
    plt.plot(x_z, y_2, label=fr'$y^s(h={h_set[1]})$', color='green', linewidth=1)
    plt.plot(x_z, y_3, label=fr'$y^s(h={h_set[2]})$', color='orange', linewidth=1)
    plt.plot(x_z, y_4, label=fr'$y^s(h={h_set[3]})$', color='purple', linewidth=1)
    plt.plot(x_z, y_5, label=fr'$y^s(h={h_set[4]})$', color='brown', linewidth=1)
    plt.xlabel('x',fontsize = 15)
    plt.ylabel(r'$\xi(x)$',fontsize = 15)
    plt.legend(fontsize=15)
    plt.tick_params(axis='both', labelsize=12)
    plt.tight_layout()
    plt.savefig(f'figures/figure_step2/test1_different_h_N={N}.pdf', dpi=300)

    plt.show()

