from fenics import *
import numpy as np
import matplotlib.pyplot as plt
import dolfin as df
import scipy.io
from mpl_toolkits.axes_grid1 import make_axes_locatable

seed = 42

def getSolutions(a, h,u_a, x_dense,y_dense):
    h = h
    mesh = UnitSquareMesh(int(1 / h), int(1 / h))
    V = FunctionSpace(mesh, 'P', 1)
    def boundary(x, on_boundary):
        return on_boundary
    bc = DirichletBC(V, Constant(0), boundary)
                          
                                           
    f_expr = Expression(
        '(pow(a, 2) - 2*pow(pi, 2))*exp(a*x[0])*sin(pi*x[0])*sin(pi*x[1]) + 2*a*pi*exp(a*x[0])*cos(pi*x[0])*sin(pi*x[1])',
        degree=2, a=a)
                                
    u = TrialFunction(V)
    v = TestFunction(V)
    a_form = dot(grad(u), grad(v)) * df.dx
    L = -f_expr * v * df.dx
    u_h = Function(V)
                     
    solve(a_form == L, u_h, bc)

    xq_dense = x_dense.flatten()
    yq_dense = y_dense.flatten()

    vectorized_u_h = np.vectorize(u_h)
    u_interp_dense = vectorized_u_h(xq_dense, yq_dense)
    u_interp_2d = u_interp_dense.reshape(x_dense.shape)

    u_a = u_a
                               
    diff = u_interp_2d - u_a
    relative_l2 = np.sqrt(np.sum(diff ** 2) / np.sum(u_a ** 2))
    return u_interp_2d, u_a, relative_l2, x_dense, y_dense


               
if __name__ == "__main__":
    a = 1
    a_true = 1

    N_a = 1000
    N_h = 19
    h_set = np.linspace(0.01, 0.1, N_h)
    a_set = np.linspace(0.98, 3, N_a)
    a_optimal_set = []
    error_set = []

                                                     
                                                                     
                                                                       
    data = scipy.io.loadmat('backups/data_step1_step2/test2_true_xi_data_N=40.mat')

    XY_z = data['XY_z']
    xi_reshape = data['xi_reshape']
    x_dense_new = XY_z[:,:,0]
    y_dense_new = XY_z[:,:,1]


    def objective(a, h, u_a, x_dense, y_dense):
        u_interp_2d, _, error, _, _ = getSolutions(a, h, u_a, x_dense, y_dense)
        return error


    h1 = 0.01
    u_interp_2d_h1, _, _, _, _ = getSolutions(a, h1, xi_reshape, x_dense_new, y_dense_new)

    h2 = 0.05
    u_interp_2d_h2, _, _, _, _ = getSolutions(a, h2, xi_reshape, x_dense_new, y_dense_new)

    h3  = 0.1
    u_interp_2d_h3, _, _, _, _ = getSolutions(a, h3, xi_reshape, x_dense_new, y_dense_new)

    h4 = 0.2
    u_interp_2d_h4, _, _, _, _ = getSolutions(a, h4, xi_reshape, x_dense_new, y_dense_new)

                            

                                    
    fig2, ax2 = plt.subplots(figsize=(10, 8))
    c2 = ax2.pcolormesh(
        x_dense_new, y_dense_new, xi_reshape,
        shading='gouraud', cmap='jet',
        antialiased=True
    )
    ax2.set_title('Reference', fontsize=35)
    ax2.tick_params(axis='both', labelsize=30)
    ax2.set_aspect('equal')
    ax2.set_xlabel('x', fontsize=35)
    ax2.set_ylabel('y', fontsize=35)
    ax2.tick_params(axis='x', pad=10)
    ax2.tick_params(axis='y', pad=10)
    divider2 = make_axes_locatable(ax2)
    cax2 = divider2.append_axes("right", size="5%", pad=0.2)
    cbar2 = fig2.colorbar(c2, cax=cax2)
    cbar2.ax.tick_params(labelsize=30)
    plt.tight_layout()
    file_path2 = 'figure_new/figure_step1/analytical_solution.pdf'
    plt.savefig(file_path2, dpi=300)
    print(f"成功保存图像至: {file_path2}")
    plt.close(fig2)

                          
    fig3, ax3 = plt.subplots(figsize=(10, 8))
    c3 = ax3.pcolormesh(
        x_dense_new, y_dense_new, u_interp_2d_h4,
        shading='gouraud', cmap='jet',
                                                                   
        antialiased=True
    )
    ax3.set_title(f'h={h4}', fontsize=35)
    ax3.tick_params(axis='both', labelsize=30)
    ax3.set_aspect('equal')
    ax3.set_xlabel('x', fontsize=35)
    ax3.set_ylabel('y', fontsize=35)
    ax3.tick_params(axis='x', pad=10)
    ax3.tick_params(axis='y', pad=10)
    divider3 = make_axes_locatable(ax3)
    cax3 = divider3.append_axes("right", size="5%", pad=0.2)
    cbar3 = fig3.colorbar(c3, cax=cax3)
    cbar3.ax.tick_params(labelsize=30)
    plt.tight_layout()
    file_path3 = f'figure_new/figure_step1/solution_h_{h4}.pdf'
    plt.savefig(file_path3, dpi=300)
    print(f"成功保存图像至: {file_path3}")
    plt.close(fig3)

                          
    fig4, ax4 = plt.subplots(figsize=(10, 8))
    c4 = ax4.pcolormesh(
        x_dense_new, y_dense_new, u_interp_2d_h2,
        shading='gouraud', cmap='jet',
                                                                                           
        antialiased=True
    )
    ax4.set_title(f'h={h2}', fontsize=35)
    ax4.tick_params(axis='both', labelsize=30)
    ax4.set_aspect('equal')
    ax4.set_xlabel('x', fontsize=35)
    ax4.set_ylabel('y', fontsize=35)
    ax4.tick_params(axis='x', pad=10)
    ax4.tick_params(axis='y', pad=10)
    divider4 = make_axes_locatable(ax4)
    cax4 = divider4.append_axes("right", size="5%", pad=0.2)
    cbar4 = fig4.colorbar(c4, cax=cax4)
    cbar4.ax.tick_params(labelsize=30)
    plt.tight_layout()
    file_path4 = f'figure_new/figure_step1/solution_h_{h2}.pdf'
    plt.savefig(file_path4, dpi=300)
    print(f"成功保存图像至: {file_path4}")
    plt.close(fig4)

                          
    fig5, ax5 = plt.subplots(figsize=(10, 8))
    c5 = ax5.pcolormesh(
        x_dense_new, y_dense_new, u_interp_2d_h1,
        shading='gouraud', cmap='jet',
                                                                   
        antialiased=True
    )
    ax5.set_title(f'h={h1}', fontsize=35)
    ax5.tick_params(axis='both', labelsize=30)
    ax5.set_aspect('equal')
    ax5.set_xlabel('x', fontsize=35)
    ax5.set_ylabel('y', fontsize=35)
    ax5.tick_params(axis='x', pad=10)
    ax5.tick_params(axis='y', pad=10)
    divider5 = make_axes_locatable(ax5)
    cax5 = divider5.append_axes("right", size="5%", pad=0.2)
    cbar5 = fig5.colorbar(c5, cax=cax5)
    cbar5.ax.tick_params(labelsize=30)
    plt.tight_layout()
    file_path5 = f'figure_new/figure_step1/solution_h_{h1}.pdf'
    plt.savefig(file_path5, dpi=300)
    print(f"成功保存图像至: {file_path5}")
    plt.close(fig5)



                                               
                                                                                    
                                                                
                             
     
                                      
                                      
                                                       
                                                       
     
                                         
                                                              
                                         
                                        
     
                        
     
                                                           
                                      
                                        
                     
     
                                              
     
                                      
                                               
                                 
                        
                                               
                               
       
                                                       
                                                
                             
                                      
                                      
                                       
                                       
                                         
                                                              
                                         
                                        
                        
                                                                    
                                      
                                     
                     
     
                            
                                               
                                 
                        
                                                   
                                
                                                                  
       
                                           
                                                
                             
                                      
                                      
                                       
                                       
                                         
                                                              
                                         
                                        
                        
                                                                 
                                      
                                     
                     
     
                            
                                               
                                 
                        
                                                   
                                
                                                                                       
       
                                           
                                                
                             
                                      
                                      
                                       
                                       
                                         
                                                              
                                         
                                        
                        
                                                                 
                                      
                                     
                     
     
                            
                                               
                                 
                        
                                                   
                                
                                                                  
       
                                           
                                                
                             
                                      
                                      
                                       
                                       
                                         
                                                              
                                         
                                        
                        
                                                                 
                                      
                                     
                     

                        
                                                             
                

