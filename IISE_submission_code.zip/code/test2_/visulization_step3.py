import numpy as np
import torch
import scipy.io
import matplotlib.pyplot as plt
import os

current_dir = os.path.dirname(os.path.abspath(__file__))

noise = 1

model_name = ['non_GP', 'GP v1', 'GP v2', 'AR stronger', 'AR simple', 'scaled AR(1)']

model_selected = model_name[0]
N=30

s1 = 1
s2 = 3
                  


plt.figure(figsize=(8, 6))

if noise == 0:
    if model_selected == 'non_GP':
        print(f'model is {model_selected}')

        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_0_N=30.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        h = file_path_1['h'].flatten()
        predict1 = file_path_1['predict'].flatten()
        predict = predict1
        x_true = file_path_1['true'].flatten()
        plt.title('Non-stationary GP (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'non_GP_test2_noise_{noise}_N={N}.png')

    elif model_selected == 'GP v1':
        print(f'model is {model_selected}')

        file_path_2 = os.path.join(current_dir, 'backups/data', 'GP_version1_test2_noise_0_N=30.mat')
        file_path_2 = scipy.io.loadmat(file_path_2)
        h = file_path_2['h'].flatten()
        predict2 = file_path_2['predict'].flatten()
        predict = predict2
        x_true = file_path_2['true'].flatten()
        plt.title('stationary GP v1 (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'GP_v1_test2_noise_{noise}_N={N}.png')

    elif model_selected == 'GP v2':
        print(f'model is {model_selected}')

        file_path_3 = os.path.join(current_dir, 'backups/data', 'GP_version2_test2_noise_0_N=30.mat')
        file_path_3 = scipy.io.loadmat(file_path_3)
        h3 = file_path_3['h'].flatten()
        predict3 = file_path_3['predict'].flatten()
        predict = predict3
        h = h3
        x_true = file_path_3['true'].flatten()
        plt.title('stationary GP v2 (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'GP_v2_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'AR stronger':
        print(f'model is {model_selected}')

        file_path_4 = os.path.join(current_dir, 'backups/data', 'AR_stronger_test2_noise_0_N=30.mat')
        file_path_4 = scipy.io.loadmat(file_path_4)
        h = file_path_4['h'].flatten()
        predict4 = file_path_4['predict'].flatten()
        predict = predict4
        x_true = file_path_4['true'].flatten()
        plt.title('Complex Nonlinear AR (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'strong_AR_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'AR simple':
        print(f'model is {model_selected}')

        file_path_5 = os.path.join(current_dir, 'backups/data', 'AR_simple_test2_noise_0_N=30.mat')
        file_path_5 = scipy.io.loadmat(file_path_5)
        h = file_path_5['h'].flatten()
        predict5 = file_path_5['predict'].flatten()
        predict = predict5

        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_0_N=30.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()

        plt.title('Simple Nonlinear AR (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'simple_AR_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'scaled AR(1)':
        print(f'model is {model_selected}')

        file_path_6 = os.path.join(current_dir, 'backups/data', 'scaled AR(1)_test2_noise_0_N=30.mat')
        file_path_6 = scipy.io.loadmat(file_path_6)
        h = file_path_6['h'].flatten()
        predict6 = file_path_6['predict'].flatten()
        predict = predict6

        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_0_N=30.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()

        plt.title('Scaled AR (Noise-free)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'scaled_AR_test2_noise_{noise}_N={N}.png')



elif noise==1:
    if model_selected == 'non_GP':
        print(f'model is {model_selected}')

        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_1_N=30_std0.5.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        h = file_path_1['h'].flatten()
        predict1 = file_path_1['predict'].flatten()
        predict= predict1
        x_true = file_path_1['true'].flatten()
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'non_GP_test2_noise_{noise}_N={N}.png')
        plt.title('Non-stationary GP (Noisy)',fontsize = 20)

    elif model_selected == 'GP v1':
        print(f'model is {model_selected}')

        file_path_2 = os.path.join(current_dir, 'backups/data', 'GP_version1_test2_noise_1_N=30_std0.5.mat')
        file_path_2 = scipy.io.loadmat(file_path_2)
        predict2 = file_path_2['predict'].flatten()
        predict = predict2
        h = file_path_2['h'].flatten()
        x_true = file_path_2['true'].flatten()
        plt.title('stationary GP v1 (Noisy)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'GP_v1_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'GP v2':
        print(f'model is {model_selected}')

        file_path_3 = os.path.join(current_dir, 'backups/data', 'GP_version2_test2_noise_1_N=30_std0.5.mat')
        file_path_3 = scipy.io.loadmat(file_path_3)
        h3 = file_path_3['h'].flatten()
        predict3 = file_path_3['predict'].flatten()
        h = h3
        predict = predict3
        x_true = file_path_3['true'].flatten()
        plt.title('stationary GP v2 (Noisy)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'GP_v2_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'AR stronger':
        print(f'model is {model_selected}')

        file_path_4 = os.path.join(current_dir, 'backups/data', 'AR_stronger_test2_noise_1_N=30_std0.5.mat')
        file_path_4 = scipy.io.loadmat(file_path_4)
        predict4 = file_path_4['predict'].flatten()
        h = file_path_4['h'].flatten()
        predict = predict4
        x_true = file_path_4['true'].flatten()
        plt.title('Complex Nonlinear AR (Noisy)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'strong_AR_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'AR simple':
        print(f'model is {model_selected}')

        file_path_5 = os.path.join(current_dir, 'backups/data', 'AR_simple_test2_noise_1_N=30_std0.5.mat')
        file_path_5 = scipy.io.loadmat(file_path_5)
        h = file_path_5['h'].flatten()
        predict5 = file_path_5['predict'].flatten()
        predict = predict5
        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_1_N=30.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()
        plt.title('Simple Nonlinear AR (Noisy)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'simple_AR_test2_noise_{noise}_N={N}.png')


    elif model_selected == 'scaled AR(1)':
        print(f'model is {model_selected}')

        file_path_6 = os.path.join(current_dir, 'backups/data', 'scaled AR(1)_test2_noise_1_N=30_std0.5.mat')
        file_path_6 = scipy.io.loadmat(file_path_6)
        predict6 = file_path_6['predict'].flatten()
        h = file_path_6['h'].flatten()
        predict = predict6
        file_path_1 = os.path.join(current_dir, 'backups/data', 'non_GP_test2_noise_1_N=30.mat')
        file_path_1 = scipy.io.loadmat(file_path_1)
        x_true = file_path_1['true'].flatten()
        plt.title('Scaled AR (Noisy)',fontsize =20)
        file_path_figure = os.path.join(current_dir, 'backups/figures', f'scaled_AR_test2_noise_{noise}_N={N}.png')


if model_selected == 'GP v2':

    plt.plot(h, x_true, linewidth= 1,label='True', color='blue', marker='o',markersize=2)            
    for xi, yi in zip(h[s1-1::s2], x_true[s1-1::s2]):
        plt.text(xi, yi, f'{yi:.2f}', fontsize=10,color='blue', ha='center', va='bottom',rotation=45)          

    plt.plot(h, predict, linestyle = 'dashed', label='Predicted', color='red',marker='o',markersize=2)
    for xi, yi in zip(h[s1-1::s2], predict[s1-1::s2]):
        plt.text(xi, yi, f'{yi:.5f}',fontsize=15, color='red', ha='center', va='top',rotation = -45)          

else:
    plt.plot(h, x_true, linewidth= 1,label='True', color='blue', marker='o',markersize=2)            
    for xi, yi in zip(h[s1::s2], x_true[s1::s2]):
        plt.text(xi, yi, f'{yi:.2f}', fontsize=10,color='blue', ha='center', va='bottom',rotation=45)          

    plt.plot(h, predict, linestyle = 'dashed', label='Predicted', color='red',marker='o',markersize=2)
    for xi, yi in zip(h[s1::s2], predict[s1::s2]):
        plt.text(xi, yi, f'{yi:.5f}',fontsize=15, color='red', ha='center', va='top',rotation = -45)          


plt.xticks(h, [f'{h:.3f}' for h in h],fontsize=8)                        

plt.legend(fontsize=15)
plt.grid()
plt.xlabel('h',fontsize = 15)
plt.ylabel(r'$\theta^*(h)$',fontsize = 15)

plt.tight_layout()

plt.savefig(file_path_figure)

plt.show()