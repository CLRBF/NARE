import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.optimize import least_squares
from scipy.optimize import minimize,Bounds
import argparse
import random
import pandas as pd
import os
import glob
from pathlib import Path
import random
import torch

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

                    
n = np.random.randint(1, 1000)            
            
            
       
      
       
       
seed = n
print('当前随机种子：', seed)
seed_everything(seed)



                               
def stationary(sigma, l,t1, t2):
    return sigma**2 * torch.exp(-(t1-t2)**2/(2 * l**2))

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE



             
def compute_next_theta(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
                              
    y = theta_hat[0:check]
    y = torch.tensor(y)
                                                                  
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

                   
def compute_next_theta_v2(check, theta_hat,h):
                       
    train_xt = torch.tensor(theta_hat)
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[1:check+1]
                            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu





def process_data(data_dict, index,noise_free_true):

                   
    h_1 = data_dict['h_set'].flatten()[index]
    a_1 = data_dict['a_optimal_set'].flatten()[index]

    h_true = np.array(h_1)
    X_true = np.array(a_1)

    X_true = np.flip(X_true)
    h_true = np.flip(h_true)

    X_true = np.append(X_true, noise_free_true)
    X_true = np.flip(X_true)
    h_true = np.append(h_true, 0)
    h_true = np.flip(h_true)

    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))

    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))

                      
    index_non_AR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

    h_true = h_true[1:][index_non_AR]
    X_true = X_true[1:][index_non_AR]


    h_true = list(reversed(h_true))                  
    X_true = list(reversed(X_true))

                     
    X_true_index = np.append(X_true, X_true_original[-1])
    h_true_index = np.append(h_true, h_true_original[-1])

    t_scaled = h_true
    x_scaled = X_true


    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]

    h1 = h_true[1:]
    h2 = h_true[:-1]

    return x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, list(
        X_true_original), list(h_true_original)


def train_and_predict(t_scaled, x_scaled):
    h = torch.tensor(t_scaled)               
    theta_hat = torch.tensor(x_scaled)                                       
    if noise == 0:
        h = torch.cat((h, torch.tensor([0])))               
        theta_hat = torch.cat((theta_hat, torch.tensor([noise_free_true])))
    theta_new = []

                                                                             
                                  
    if version == 1:
        if noise == 1:
            h = torch.cat((h, torch.tensor([0])))                            
        for check in range(1, len(h)):
            next_theta = compute_next_theta(check, theta_hat, h)
            theta_new.append(next_theta)             
    else:
                                                           
                                    
        if noise == 1:
            h = torch.cat((h, torch.tensor([0])))                            
        for check in range(1, len(h)-1):         
            next_theta = compute_next_theta_v2(check, theta_hat, h)
            theta_new.append(next_theta)             

                                                                       

    return theta_new

def plot_results_GP(t_NEW, predicted_x,  X_true_original, noise=0):
    index_plot = [0,3,5,7,-1]
    plt.plot(t_NEW, predicted_x, linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    predicted_x = np.array(predicted_x)
    for xi, yi in zip(t_NEW[index_plot], predicted_x[index_plot]):
        plt.text(xi, yi, f'{yi:.5f}', fontsize=10, color='red', ha='center', va='top', rotation=-45)          
    plt.plot(t_NEW,  X_true_original[1:], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    for xi, yi in zip(t_NEW[index_plot],  np.array(X_true_original[1:])[index_plot]):
        plt.text(xi, yi, f'{yi:.5f}', fontsize=10, color='blue', ha='center', va='bottom', rotation=45)          
    if noise ==0:
        plt.title('Nonlinear AR(1) Noise-free')
    else:
        plt.title('Nonlinear AR(1) Noisy')

    plt.legend()
    plt.xlabel('h')
    plt.ylabel(r'$\theta^*(h)$')
    plt.tight_layout()
    plt.show()



def plot_results_GP_SSM(t_NEW, predicted_x,  X_true_original_new, noise=0):
    index_plot = [0,3,5,7,-1]
    plt.plot(t_NEW, predicted_x, linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    predicted_x = np.array(predicted_x)

    for xi, yi in zip(t_NEW[index_plot], predicted_x[index_plot]):
        plt.text(xi, yi, f'{yi:.5f}', fontsize=10, color='red', ha='center', va='top', rotation=-45)          
    plt.plot(t_NEW,  X_true_original_new, linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    for xi, yi in zip(t_NEW[index_plot],  np.array(X_true_original_new)[index_plot]):
        plt.text(xi, yi, f'{yi:.5f}', fontsize=10, color='blue', ha='center', va='bottom', rotation=45)          
    if noise ==0:
        plt.title('Nonlinear AR(1) Noise-free')
    else:
        plt.title('Nonlinear AR(1) Noisy')

    plt.legend()
    plt.xlabel('h')
    plt.ylabel(r'$\theta^*(h)$')
    plt.tight_layout()
                

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='GP SSM Experiment')
    parser.add_argument('--noise', type=int, choices=[0, 1], default=0, help='Noise level: 0 for noise-free, 1 for noisy')
    parser.add_argument('--version', type=int, choices=[1, 2], default=2, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    args = parser.parse_args()

    noise   = args.noise
    version = args.version
    N = 30
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18]
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print(current_dir)


    alpha_candidates = [1e-2, 1e-3, 1e-4]
    alpha = random.choice(alpha_candidates)                                    
    sigma = random.uniform(0, 10)
    l = random.uniform(0, 10)

                  
    sigma=1
    l=1


    def process_and_evaluate(data_noise_free, noise_free_true, index):
        x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, X_true_original, h_true_original = process_data(
            data_noise_free, index, noise_free_true)

        theta_new = train_and_predict(t_scaled, x_scaled)
        predicted_x = theta_new

        params_init = np.array([sigma, alpha, l])

        print('alpha,sigma,  l', alpha, sigma,  l)


        t_NEW = np.append(t_scaled[1:], np.array([0]))[1:]                     
        print('predicted_x_0', predicted_x[-1])
        X_true_original_new = np.array(X_true_original)[2:]                                
        single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1],
                                                                             np.array(predicted_x[-1]))
        print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
        relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
        print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
        LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse              
        print('LOOCV_MSE', LOOCV_MSE_all)
                                                          
        data = {
            't_NEW': t_NEW,
            'predicted_x': predicted_x,
            'predicted_x_0': predicted_x[-1],
            'X_true_original': np.array(X_true_original),
            'sigma': sigma,
            'seed': seed,
            'alpha': alpha,
            'params_init': params_init,
            'l': l,
            'single_point_error_relative': single_point_error_relative,
            'single_point_error_mse': single_point_error_mse,
            'relative_l2': relative_l2,
            'LOOCV_MSE': LOOCV_MSE,
            'LOOCV_MSE_all': LOOCV_MSE_all,
        }
                   
        data_name = f'data/GP_SSM/GP_SSM_data_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
        scipy.io.savemat(data_name, data)

        if version == 1:
                                                                               
            plot_results_GP(t_NEW, predicted_x, X_true_original_new, noise=noise)

        else:
            plot_results_GP_SSM(t_NEW, predicted_x, X_true_original_new, noise=noise)
                     
        figure_name = f'figures/GP_SSM/GP_SSM_figure_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
        plt.savefig(figure_name)
        plt.close()                                   
        return LOOCV_MSE_all

    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_paths = [
        os.path.join(current_dir, '../../variable1/data_new/data_step2',
                     'N=30_test2_noise_free_N_a__a_optimal_set.mat'),
               
        os.path.join(current_dir, '../../variable2/data_step1_step2', 'N=30_test2_noise_free_N_a_2_a_optimal_set.mat'),
               
        os.path.join(current_dir, '../../variable4/data_step1_step2', 'N=30_test2_noise_free_N_a_-1_a_optimal_set.mat'),
                
        os.path.join(current_dir, '../../variable5/data_step1_step2', 'N=30_test2_noise_free_N_a_-2_a_optimal_set.mat'),
                
        os.path.join(current_dir, '../../variable6/data_step1_step2', 'N=30_test2_noise_free_N_a_0_a_optimal_set.mat'),
               
    ]
    noise_free_true_set = [1, 2, -1, -2, 0]                                   
    loocv_mse_all_values = []
    for data_path, noise_free_true in zip(data_paths, noise_free_true_set):
        data_noise_free = scipy.io.loadmat(data_path)
        loocv_mse_all = process_and_evaluate(data_noise_free, noise_free_true, index)
        print('LOOCV_MSE_all for current dataset:', loocv_mse_all)
        loocv_mse_all_values.append(loocv_mse_all)
    average_loocv_mse_all = np.mean(loocv_mse_all_values)
    print(f'Average LOOCV_MSE_all across 5 datasets: {average_loocv_mse_all}')





































