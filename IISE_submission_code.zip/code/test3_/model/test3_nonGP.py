import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.optimize import least_squares
from scipy.optimize import minimize,Bounds
import argparse
import random
import pandas as pd
import os
import glob
from pathlib import Path
import torch

import warnings

warnings.filterwarnings('ignore')

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

                    
n = np.random.randint(1, 1000)            
        
       
seed = n
print('当前随机种子：', seed)
seed_everything(seed)

noise = 0

                            
def stationary(sigma,l, t1, t2):
    diff = t1-t2
    return sigma**2 * torch.exp(-torch.sum((diff)**2)/(2 * l**2))

def covariance_Brownian(sigma, t1, t2):
    return sigma**2 * torch.min(t1, t2)

                             
def covariance_type2(sigma, l, t1, t2):
    return sigma*torch.sqrt(t1*t2) * torch.exp(-torch.square(t1 - t2) / l)


                            
def compute_next_theta(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[covariance_Brownian(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_Brownian(sigma, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

                            
def compute_next_theta_2(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[covariance_type2(sigma,l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_type2(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

                        
def compute_next_theta_3(check, theta_hat,h):
                            
    train_xt = torch.tensor(h)       
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check]            
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

                                               
def covariance(x1, x2, sigma, length_scale):

    return sigma ** 2 * np.exp(-(x1 - x2) ** 2 / (2 * length_scale ** 2))


def process_data(data_dict):

    data_noise_free_1 = data_dict
    h_1 = data_noise_free_1['h'].flatten()
    h_1 = h_1

    temp_var1 = data_noise_free_1['x1'].flatten()
    temp_var1 = temp_var1
    temp_var2 = data_noise_free_1['x2'].flatten()
    temp_var2 = temp_var2

    temp_combined = np.vstack((temp_var1, temp_var2)).T
    a_1 = temp_combined
    h_true = np.array(h_1)
    X_true = np.array(a_1)

    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)

    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)

    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))

    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))

    h_true = h_true[1:]                       
    X_true = X_true[1:]


    h_true = list(reversed(h_true))                  
    X_true = list(reversed(X_true))

    t_scaled = h_true
    x_scaled = X_true


    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]

    h1 = h_true[1:]
    h2 = h_true[:-1]
    return t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original

                  
def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def train_and_predict(t_scaled, x_scaled,h_true_original,X_true_original):

    h = torch.tensor(t_scaled)                    
    theta_hat = torch.tensor(x_scaled)                                            
                  
    h = torch.cat((h, torch.tensor([h_true_original[-1]])))
    theta_hat = torch.cat((theta_hat, torch.tensor([X_true_original[-1]])))

                                  
                                     
                                                                   

    h_all = torch.cat((h, torch.tensor([0])))
                             
    x0 = torch.floor(torch.tensor([X_true_original[-1]]) * 1000) / 1000
    theta_hat_all = torch.cat((theta_hat, x0))

    h_all = np.array(h_all)
    theta_hat_all = np.array(theta_hat_all)


    h = np.array(h)
    theta_hat = np.array(theta_hat)

                           
    theta_new = []
    for check in range(1, len(h)):
                 
        next_theta = compute_next_theta(check, theta_hat, h)
                  
                                                                

        theta_new.append(next_theta)

                
    x_train = h
    f_train = theta_hat

    x_all = h_all
    f_all = theta_hat_all
    mu_original = theta_new
                                       
    x_train = h[:-1]                              
    f_train = theta_hat[:-1]

    x_train = x_train[1:]                         
    f_train = f_train[1:]
    f_train = f_train - torch.stack(mu_original).numpy()[:-1]                                                                                                         
    x_all = x_all[1:]
    f_all = f_all[1:]
                                         
                            
    f_all = f_all[:-1] - torch.stack(mu_original).numpy()                                   
            
    F_train = np.vstack([np.ones_like(x_train), x_train]).T                                     
    n_train = len(x_train)

    C = np.zeros((n_train, n_train))
    for i in range(n_train):
        for j in range(n_train):
            C[i, j] = covariance(x_train[i], x_train[j], sigma_kriging, length_scale)


                                            
    C = C + K * np.eye(n_train)
    C_inv = np.linalg.inv(C)                             
    beta_hat = np.linalg.inv(F_train.T @ C_inv @ F_train) @ F_train.T @ C_inv @ f_train

    def predict(x0):
                                 
        f0 = np.array([1, x0])
        c0 = np.array([covariance(x0, xi, sigma_kriging, length_scale) for xi in x_train])
        residual = f_train - F_train @ beta_hat
        return f0 @ beta_hat + c0 @ C_inv @ residual

                           
    x_pred = x_all[:-1]
    y_pred = np.array([predict(x) for x in x_pred])

    predicted_x = y_pred + torch.stack(mu_original).numpy()
    true_x = f_all + torch.stack(mu_original).numpy()

                                                   
    prediction_0 = predict(0) + 0

    predicted_x = np.concatenate((predicted_x, np.array([prediction_0])))

    return predicted_x

def plot_results(t_NEW, predicted_x,  X_true_original, noise=0):
    plt.plot(t_NEW, predicted_x[:,0], linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    plt.plot(t_NEW, predicted_x[:,1], linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    X_true_original = np.array(X_true_original)
    plt.plot(t_NEW,  X_true_original[1:,0], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    plt.plot(t_NEW,  X_true_original[1:,1], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    if noise ==0:
        plt.title('Nonlinear AR(1) Noise-free')
    else:
        plt.title('Nonlinear AR(1) Noisy')
    plt.legend()
    plt.xlabel('h')
    plt.ylabel(r'$\theta^*(h)$')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='GP SSM Experiment')
    parser.add_argument('--noise', type=int, choices=[0, 1], default=1, help='Noise level: 0 for noise-free, 1 for noisy')
    parser.add_argument('--version', type=int, choices=[1, 2], default=1, help='Version of the GP model: 1 for standard GP, 2 for SSM-like GP')
    args = parser.parse_args()

    noise   = args.noise
    version = args.version

    SIGMAS = [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 100, 1000]
    LENGTHS = [1e-3,0.023,0.025,0.026, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.20, 0.25, 0.30, 1, 10, 100, 10000]
    K_VALUES = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8]

                         
                           
                       

                    
                     
                           
                       

                       
    alpha = random.choice(K_VALUES)                                    
    K = random.choice(K_VALUES)
    sigma_kriging = random.choice(SIGMAS)
    length_scale = random.choice(LENGTHS)

    sigma = random.uniform(0, 10)
    l = random.uniform(0, 10)

                                    

                     
    alpha = 1e-4
    sigma=1
    l=1

    print('sigma_kriging, length_scale, K', sigma_kriging, length_scale, K)
    print('alpha, sigma, l', alpha, sigma, l)




    def process_and_evaluate(data_noise_free, noise_free_true):
        t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original = process_data(data_noise_free)


        theta_new = train_and_predict(t_scaled, x_scaled, h_true_original, X_true_original)

                                



        predicted_x= theta_new[:-1]
        pred_h0 = theta_new[-1]
        print('pred_h0', pred_h0)
        t_NEW = np.append(t_scaled[1:], np.array([0.01]))

        print('predicted_x_h001', predicted_x[-2])
        X_true_original_new = np.array(X_true_original)[1:]           
        single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1],
                                                                             np.array(predicted_x[-1]))
        print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
        relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
        print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
        LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse              
        print('LOOCV_MSE', LOOCV_MSE_all)
        params_init = np.array([sigma_kriging, length_scale, K,alpha, sigma, l])
        data = {
            't_NEW': t_NEW,
            'predicted_x': predicted_x,
            'predicted_x_h001': predicted_x[-1],                                         
            'pred_h0': pred_h0,                                        
            'X_true_original': np.array(X_true_original),
                                               
            'seed': seed,
            'params_init': params_init,
            'single_point_error_relative': single_point_error_relative,
            'single_point_error_mse': single_point_error_mse,
            'relative_l2': relative_l2,
            'LOOCV_MSE': LOOCV_MSE,
            'LOOCV_MSE_all': LOOCV_MSE_all,
        }
        plot_results(t_NEW, predicted_x, X_true_original, noise=noise)
        data_name = f'data/nonGP/nonGP_data_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
        scipy.io.savemat(data_name, data)
        figure_name = f'figures/nonGP/nonGP_figure_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
        plt.savefig(figure_name)

        return LOOCV_MSE_all



    current_dir = os.path.dirname(os.path.abspath(__file__))

    if noise == 0:
        data_paths = [
            os.path.join(current_dir, '../../variable1/data_step1_step2',
                         'variable1_noise_free.mat'),
                           
            os.path.join(current_dir, '../../variable2/data_step1_step2',
                         'variable2_noise_free.mat'),
                           
            os.path.join(current_dir, '../../variable3/data_step1_step2',
                         'variable3_noise_free.mat'),
                           
            os.path.join(current_dir, '../../variable4/data_step1_step2',
                         'variable4_noise_free.mat'),
                           
            os.path.join(current_dir, '../../variable5/data_step1_step2',
                         'variable5_noise_free.mat'),
                           
        ]
        noise_free_true_set = [0.523, 0.601, 0.536, 0.334, 0.342]                                   
        loocv_mse_all_values = []
        for data_path, noise_free_true in zip(data_paths, noise_free_true_set):
            data_noise_free = scipy.io.loadmat(data_path)
            loocv_mse_all = process_and_evaluate(data_noise_free, noise_free_true)
            print('LOOCV_MSE_all for current dataset:', loocv_mse_all)
            loocv_mse_all_values.append(loocv_mse_all)
        average_loocv_mse_all = np.mean(loocv_mse_all_values)
        print(f'Average LOOCV_MSE_all across 5 datasets: {average_loocv_mse_all}')

    elif noise == 1:
        data_paths = [
            os.path.join(current_dir, '../../variable1/data_step1_step2',
                         'variable1_noisy.mat'),
                           
            os.path.join(current_dir, '../../variable2/data_step1_step2',
                         'variable2_noisy.mat'),
                           
            os.path.join(current_dir, '../../variable3/data_step1_step2',
                         'variable3_noisy.mat'),
                           
            os.path.join(current_dir, '../../variable4/data_step1_step2',
                         'variable4_noisy.mat'),
                           
            os.path.join(current_dir, '../../variable5/data_step1_step2',
                         'variable5_noisy.mat'),
                           
        ]
        noise_free_true_set = [0.543, 0.675, 0.562, 0.348, 0.363]                                   
        loocv_mse_all_values = []
        for data_path, noise_free_true in zip(data_paths, noise_free_true_set):
            data_noise_free = scipy.io.loadmat(data_path)
                     
            loocv_mse_all = process_and_evaluate(data_noise_free, noise_free_true)
            print('LOOCV_MSE_all for current dataset:', loocv_mse_all)
            loocv_mse_all_values.append(loocv_mse_all)
        average_loocv_mse_all = np.mean(loocv_mse_all_values)
        print(f'Average LOOCV_MSE_all across 5 datasets: {average_loocv_mse_all}')






