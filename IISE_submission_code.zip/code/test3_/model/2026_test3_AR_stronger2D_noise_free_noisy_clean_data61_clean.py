

             

                  

                    
                                 
                 
                                          
                                             
                 
               
                     
           
             
                          
              

                            
                       
                          
                             
                                   
                                      
                                          
                                               
                                            

                      
                                            
          
                        
                       

           

                              
                                        
                                                                               
                                         
                                           
                                           

                                                         
                         
                            
                            

                                
                              

                                
                              

                              
                                                       

                              
                                                       

                          
                         


                                      
                                     

                       
                       

                         
                        

                     
                      
                                                                                   

                                      
                                                                                           
                                            
                             

                                           
                                                                                           
                                            
                             

                                             
                              

                                      
                             
                             
                           
                           

                                              
                                                                 
                                 
                                                
                                                   
        
                                                        
                                                                                     
                                                                                                            
        
                                    
                             
                                   
                       

                                                          
                                                              
                                                                 
                                 
                                                
                                                   
        
                                 
                                 
        
                        
                                                   
                                         
                                           
            
                          
                                                                       
                                                                                          
            
                                            
                                     
                                        
                             
            
                                      

           
           
                                                                                                                          
                                                                        

                                   
                                                                                                        
    
                             
                    
                        
                                                  
                       
                       
       

                                                               
                                                                                                                       

                               
                   
                                              
    
                                          
                                                      
                                               
    
                                      
    
                                                                      

                                 
                                    
    
                                                               

                                                                   
                                                             
                                       
    
                                                                                                                         
                                                                                                                         
    
                                                   
                                                                                                                  
                                                                                                                  
    
                      
                                                   
             
                                              
                    
                       
                                    
                          
                  

                                                                 
                                          
                                     
    
              
                                         
                                                                                            
                    
                                                      
                                 
                                               

                  
                                                                                  
                                                                                  
    
                   
                                            
    
                                                
                                       
                                                                                         
                                                                                         
           
                       
                                                  
                                                                                                      
                                                                                                      

                    
                                                 
           
                                            
                  
                     
                                  
                        
                
                            
                                                                 
                                                                                                                
        
                                                                                                    
        
                                                             
                                                           

        
                          
                                                    
        
                                                                            
        
                                                                               
                                      
                                       
           
                                                                                                         
        
                                                   
                                                                             
                                                                                                   
                                                                
        
                                                                    
                                           

                  
                             
                                         
                                                   
                                  
                                                           
                                               
                           
                                         
                                                                         
                                                               
                                         
                                     
                                             
           
                                                                        
        
                            
                                                                                                                                   
                                             
                                                                                                                                          
                                    
        
                              

                                                              

                    
                        
                                                                           
                                                       
                             
                                                                             
                                                         
                               
                                                                             
                                                         
                               
                                                                             
                                                         
                               
                                                                             
                                                         
                             
           
                                                                                                        
                                                                          
                                   
                                                                                 
                                                           
                                                                                    
                                                                        
                                                        
                                                               
                                                                                    

                      
                        
                                                                           
                                                  
                             
                                                                             
                                                    
                               
                                                                             
                                                    
                               
                                                                             
                                                    
                               
                                                                             
                                                    
                             
           
                                                                                                        
                                                                          
                                   
                                                                                 
                                                           
                                                                                    
                                                                        
                                                        
                                                               
                                                                                    



                                                                                                                                                                                                                                             

import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.optimize import least_squares
from scipy.optimize import minimize,Bounds
import argparse
import random
import pandas as pd
import os
import glob
from pathlib import Path
import torch

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

                    
n = np.random.randint(1, 1000)            
seed = n
print('当前随机种子：', seed)
seed_everything(seed)

noise = 0

def process_data(data_dict):

             

    data_noise_free_1 = data_dict
    h_1 = data_noise_free_1['h'].flatten()
    h_1 = h_1

    temp_var1 = data_noise_free_1['x1'].flatten()
    temp_var1 = temp_var1
    temp_var2 = data_noise_free_1['x2'].flatten()
    temp_var2 = temp_var2


                                                                     
                   
                                  
    number =61
    h_1 = np.linspace(0.01,0.025,number)
    variables = [key for key in data_dict.keys() if not key.startswith('__')]
    main_data = data_dict[variables[0]]
    temp_var1 = main_data[:,0].flatten()
    temp_var2 = main_data[:,1].flatten()


                    
    np.random.seed(42)                 
    total_points = len(h_1)
    num_selected = number
    random_indices = np.sort(np.random.choice(total_points, size=num_selected, replace=False))
    
                       
    h_1 = h_1[random_indices]
    temp_var1 = temp_var1[random_indices]
    temp_var2 = temp_var2[random_indices]



    temp_combined = np.vstack((temp_var1, temp_var2)).T
    a_1 = temp_combined
    h_true = np.array(h_1)
    X_true = np.array(a_1)

    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)

    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)

    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))

    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))

    h_true = h_true[1:]                       
    X_true = X_true[1:]


    h_true = list(reversed(h_true))                  
    X_true = list(reversed(X_true))

    t_scaled = h_true
    x_scaled = X_true


    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]

    h1 = h_true[1:]
    h2 = h_true[:-1]
    return t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original

                  
def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum((true) ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return relative_l2, MSE

def train_and_predict(x_i, y_i,h1, h2,n):

    seed_everything(seed=n)                 
    def objective(params, x_i, y_i, h1, h2):
        alpha1, alpha2, beta, gamma11, gamma12, gamma2 = params
        gamma2 = np.abs(gamma2)
        alpha_new = np.array([alpha1, alpha2])
        gamma1_new = np.array([gamma11, gamma12])
        h1 = np.array(h1)
        h2 = np.array(h2)
                        
        pred = np.array(x_i) + (alpha_new[:, np.newaxis] * (h1 ** beta - h2 ** beta) + gamma1_new[:, np.newaxis] * (
                    h1 ** (beta + gamma2) - h2 ** (beta + gamma2))).T
        result = y_i - pred
        result = result.flatten()
        return result

    def predict_objective(alpha1, alpha2, beta, gamma11, gamma12, gamma2,  h1, h2, x_i, y_i):
        gamma2 = np.abs(gamma2)
        alpha_new = np.array([alpha1, alpha2])
        gamma1_new = np.array([gamma11, gamma12])
                                      
        x_i.append(y_i[-1])               
        print('x_i', x_i)
        pred = np.array(x_i) + (alpha_new[:, np.newaxis] * (h1 ** beta - h2 ** beta) + gamma1_new[:, np.newaxis] * (
                    h1 ** (beta + gamma2) - h2 ** (beta + gamma2))).T
        return pred

    a = 0
    b = 5
    initial_guess = [np.random.uniform(a, b), np.random.uniform(a, b), np.random.uniform(a, b), np.random.uniform(a, b),
               np.random.uniform(a, b), np.random.uniform(a, b)]

    print('初始参数 222222222222:', initial_guess)
    bounds = ([-1e8, -1e8,0, -1e8,-1e8, -1e8], [1e8,1e8, 1e8, 1e8,1e8, 1e8])
    result = least_squares(
        objective,
        initial_guess,
        args=(x_i, y_i, h1, h2),
        method='trf',
                          
                      
        bounds=bounds                          
    )

    alpha1,alpha2, beta, gamma11,gamma12, gamma2 = result.x
    print(f"Estimated alpha and beta: {alpha1:.6f},{alpha2:.6f},{beta:.6f},{gamma11:.6f},{gamma12:.6f},{gamma2:.6f}")

            
    h2 = np.append(h2, h1[-1])
    h1 = np.append(h1, 0.01)
    predicted_series = predict_objective(alpha1,alpha2, beta, gamma11,gamma12, gamma2, h1, h2,x_i,y_i)

                    
    h1_0 = 0
    h2_0 = h1[-1]
    x_i_new = y_i[-1]           
    gamma2 = np.abs(gamma2)
    alpha_new = np.array([alpha1, alpha2])
    gamma1_new = np.array([gamma11, gamma12])
    pred_h0 = np.array(x_i_new) + (alpha_new[:, np.newaxis] * (h1_0 ** beta - h2_0 ** beta) + gamma1_new[:, np.newaxis] * (
            h1_0 ** (beta + gamma2) - h2_0 ** (beta + gamma2))).T
    return result.x, predicted_series,initial_guess,pred_h0

def plot_results(t_NEW, predicted_x,  X_true_original, noise=0):
    plt.plot(t_NEW, predicted_x[:,0], linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    plt.plot(t_NEW, predicted_x[:,1], linestyle='dashed', label='Predicted', color='red', marker='o', markersize=2)
    X_true_original = np.array(X_true_original)
    plt.plot(t_NEW,  X_true_original[1:,0], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    plt.plot(t_NEW,  X_true_original[1:,1], linewidth=1, label='True', color='blue', marker='o', markersize=2)            
    if noise ==0:
        plt.title('Nonlinear AR(1) Noise-free')
    else:
        plt.title('Nonlinear AR(1) Noisy')
    plt.legend()
    plt.xlabel('h')
    plt.ylabel(r'$\theta^*(h)$')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":

    def process_and_evaluate(data_noise_free, noise_free_true):
        t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original = process_data(data_noise_free)
        optimal_params, predicted_x, params_init,pred_h0 = train_and_predict(x_i, y_i, h1, h2,n)
        t_NEW = np.append(t_scaled[1:], np.array([0.01]))

        print('predicted_x_h001', predicted_x[-1])
        X_true_original_new = np.array(X_true_original)[1:]           
        single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1],
                                                                             np.array(predicted_x[-1]))
        print('single_point_error: relative, mse', single_point_error_relative, single_point_error_mse)
        relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
        print('relative_l2,loocv_MSE', relative_l2, LOOCV_MSE)
        LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse              
        print('LOOCV_MSE', LOOCV_MSE_all)

        data = {
            't_NEW': t_NEW,
            'predicted_x': predicted_x,
            'predicted_x_h001': predicted_x[-1],                                        
            'pred_h0':pred_h0,                                       
            'X_true_original': np.array(X_true_original),
            'optimal_params': optimal_params,
            'seed': seed,
            'params_init': params_init,
            'single_point_error_relative': single_point_error_relative,
            'single_point_error_mse': single_point_error_mse,
            'relative_l2': relative_l2,
            'LOOCV_MSE': LOOCV_MSE,
            'LOOCV_MSE_all': LOOCV_MSE_all,
        }
        plot_results(t_NEW, predicted_x, X_true_original, noise=noise)
        data_name = f'data/Ours_complex/Ours_complex_data_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
                                           
        figure_name = f'figures/Ours_complex/Ours_complex_figure_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
                                  
        return LOOCV_MSE_all

    current_dir = os.path.dirname(os.path.abspath(__file__))

    if noise == 0:
        data_paths = [
            os.path.join(current_dir, '../../variable1/data_step1_step2',
                         'step2_varible0025_61.mat'),
                           
                                                                           
                                                       
                             
                                                                           
                                                       
                             
                                                                           
                                                       
                             
                                                                           
                                                       
                             
        ]
                                                                                                      
        noise_free_true_set = [0.523]                                   

        loocv_mse_all_values = []
        for data_path, noise_free_true in zip(data_paths, noise_free_true_set):
            data_noise_free = scipy.io.loadmat(data_path)
            loocv_mse_all = process_and_evaluate(data_noise_free, noise_free_true)
            print('LOOCV_MSE_all for current dataset:', loocv_mse_all)
            loocv_mse_all_values.append(loocv_mse_all)
        average_loocv_mse_all = np.mean(loocv_mse_all_values)
        print(f'Average LOOCV_MSE_all across 5 datasets: {average_loocv_mse_all}')

    elif noise == 1:
        data_paths = [
            os.path.join(current_dir, '../../variable1/data_step1_step2',
                         'variable1_noisy.mat'),
                           
                                                                           
                                                  
                             
                                                                           
                                                  
                             
                                                                           
                                                  
                             
                                                                           
                                                  
                             
        ]
                                                                                                      
        noise_free_true_set = [0.543]                                   
        loocv_mse_all_values = []
        for data_path, noise_free_true in zip(data_paths, noise_free_true_set):
            data_noise_free = scipy.io.loadmat(data_path)
                     
            loocv_mse_all = process_and_evaluate(data_noise_free, noise_free_true)
            print('LOOCV_MSE_all for current dataset:', loocv_mse_all)
            loocv_mse_all_values.append(loocv_mse_all)
        average_loocv_mse_all = np.mean(loocv_mse_all_values)
        print(f'Average LOOCV_MSE_all across 5 datasets: {average_loocv_mse_all}')






