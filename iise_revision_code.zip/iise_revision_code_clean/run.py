"""Run the experiments; each invocation writes a new output directory."""
from pathlib import Path
import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--test', choices=['all', 'test1', 'test2', 'test3'], default='all')
    parser.add_argument('--quick', action='store_true', help='Use a small set of cases for a quick check.')
    parser.add_argument('--check-inputs', action='store_true', help='Check the supplied data files and exit without running experiments.')
    parser.add_argument('--output', type=Path, help='New output directory; must not already exist.')
    parser.add_argument('--seed', type=int, default=20260827)
    parser.add_argument('--original-python', help='Python 3.8 interpreter for the original fits and FEniCS field plots.')
    parser.add_argument('--revision-only', action='store_true', help='Run only the additional comparisons in the revision.')
    parser.add_argument('--candidate-settings', choices=['archive', 'manuscript'], default='archive',
                        help='Use original full-precision candidate settings or the printed Test 1 settings.')
    args = parser.parse_args()
    from scripts.check_inputs import check_inputs
    try:
        input_count = check_inputs()
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if args.check_inputs:
        print(f'Input check passed: {input_count} files under {BASE / "data"}.')
        return
    if sys.version_info < (3, 11):
        parser.error('Use Python 3.12 for the main experiments.')
    original_python = args.original_python or os.environ.get('IISE_ORIGINAL_PYTHON') or shutil.which('python3.8')
    if not args.revision_only and not original_python:
        parser.error('The complete run includes original experiments. Pass --original-python /path/to/python3.8; see README.md.')
    if original_python:
        original_python = shutil.which(original_python) or str(Path(original_python).expanduser().resolve())
        if not Path(original_python).is_file():
            parser.error('Original Python interpreter does not exist: ' + original_python)
    output = (args.output or BASE / 'outputs' / datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')).resolve()
    if output.exists():
        parser.error(f'Output already exists: {output}. Choose a new directory.')
    output.mkdir(parents=True)
    logs = output / 'logs'
    logs.mkdir()
    env = os.environ.copy()
    env.update(IISE_OUTPUT_DIR=str(output), PYTHONDONTWRITEBYTECODE='1', MPLBACKEND='Agg',
               MPLCONFIGDIR=str(output / '.cache/matplotlib'), XDG_CACHE_HOME=str(output / '.cache'),
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    common = ['--fail-fast', '--seed', str(args.seed)] + (['--quick'] if args.quick else [])
    stages = [('direct_baselines', ['-m', 'experiments.run_revision_baselines', '--tests', args.test, *common])]
    if args.test in {'all', 'test1'}:
        stages.append(('gp_mle', ['-m', 'experiments.run_gp_mle_sensitivity', *common]))
    if args.test in {'all', 'test2'}:
        stages.append(('two_stage', ['-m', 'experiments.run_two_stage_mf', '--tests', 'test2', *common]))
    if args.test in {'all', 'test2'}:
        stages.append(('design', ['-m', 'experiments.run_design_sensitivity', *common]))
    if args.test in {'all', 'test3'}:
        stages.extend([('turbine_aggregate', ['-m', 'experiments.run_main', '--tests', 'test3', *common]),
                       ('windows', ['-m', 'experiments.run_reviewer2_window_comparison', *common])])
        if not args.quick:
            stages.append(('figure11', ['scripts/plot_figure11.py']))
    if not args.quick:
        stages.append(('design_illustration', ['scripts/plot_design_illustration.py']))
        stages.append(('data_figures', ['scripts/plot_data_overview.py', '--tests', args.test]))
        if args.test in {'all', 'test3'}:
            stages.append(('turbine_fields', ['scripts/plot_turbine_fields.py']))
    commands = [(name, [sys.executable, '-B', *cmd]) for name, cmd in stages]
    if not args.revision_only:
        imports = 'import numpy, scipy, torch'
        if not args.quick and args.test in {'all', 'test2'}:
            imports = ('import os, sys; from pathlib import Path; p=Path(sys.prefix); '
                       'os.environ["PATH"]=str(p/"bin")+os.pathsep+os.environ.get("PATH", ""); '
                       'os.environ["PKG_CONFIG_PATH"]=str(p/"lib/pkgconfig")+os.pathsep+os.environ.get("PKG_CONFIG_PATH", ""); '
                       'import numpy, scipy, torch, dolfin')
        commands.insert(0, ('original_environment', [original_python, '-B', '-c', imports]))
    if not args.revision_only and args.test in {'all', 'test1'}:
        commands.append(('original_test1', [original_python, '-B', 'scripts/refit_original_test1.py',
                         '--candidate-settings', args.candidate_settings] + (['--selected-only'] if args.quick else [])))
        if not args.quick:
            commands.append(('original_test1_plots', [sys.executable, '-B', 'scripts/plot_original_test1.py']))
    if not args.revision_only and args.test in {'all', 'test2', 'test3'}:
        legacy_test = 'all' if args.test == 'all' else args.test
        commands.append(('original_test23', [original_python, '-B', 'scripts/refit_original_test23.py',
                         '--tests', legacy_test] + (['--quick'] if args.quick else [])))
        if not args.quick:
            commands.append(('original_test23_plots', [sys.executable, '-B', 'scripts/plot_original_test23.py', '--tests', legacy_test]))
        if not args.quick and args.test in {'all', 'test2'}:
            commands.append(('poisson_fields', [original_python, '-B', 'scripts/plot_poisson_fields.py']))
    commands.append(('manuscript_tables', [sys.executable, '-B', 'scripts/summarize_manuscript.py',
                     '--tests', args.test] + (['--quick'] if args.quick else []) +
                     (['--revision-only'] if args.revision_only else [])))
    status = []
    print(f'Output: {output}', flush=True)
    print(f'Inputs: {input_count} files checked in {BASE / "data"}', flush=True)
    (output / 'run_configuration.json').write_text(json.dumps({
        'arguments': {key: str(value) if isinstance(value, Path) else value
                      for key, value in vars(args).items()},
        'main_python': sys.executable, 'python_version': sys.version,
        'original_python': original_python, 'input_directory': str(BASE / 'data'),
        'input_manifest_sha256': __import__('hashlib').sha256((BASE / 'input_manifest.json').read_bytes()).hexdigest(),
    }, indent=2))
    for name, command in commands:
        print(f'Running {name} ...', flush=True)
        task_env = env.copy()
        if name in {'original_environment', 'original_test1', 'original_test23', 'poisson_fields'}:
            task_env.pop('PYTHONPATH', None)
            task_env['MKL_THREADING_LAYER'] = 'SEQUENTIAL'
        start = time.perf_counter()
        with (logs / (name + '.log')).open('w') as log:
            process = subprocess.run(command, cwd=BASE, env=task_env, stdout=log, stderr=subprocess.STDOUT)
        status.append({'stage': name, 'seconds': time.perf_counter() - start, 'returncode': process.returncode})
        (output / 'run_status.json').write_text(json.dumps(status, indent=2))
        if process.returncode:
            print(f'{name} failed. See {logs / (name + ".log")}', file=sys.stderr)
            sys.exit(process.returncode)
    print(f'Completed. Results: {output / "results"}', flush=True)


if __name__ == '__main__':
    main()
