from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass
class TrajectoryDataset:
    """A mesh-indexed calibration-parameter trajectory with a separately stored endpoint.

    The endpoint is not included among the finite fitting levels.  Whether its
    loss is used to rank candidate hyperparameters is controlled by the experiment
    protocol.  The manuscript's legacy Test 1/2/3 protocol intentionally uses an
    endpoint-weighted validation score.
    """

    name: str
    h_train: np.ndarray
    y_train: np.ndarray
    target_h: float
    y_target: np.ndarray
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.h_train = np.asarray(self.h_train, dtype=float).reshape(-1)
        y = np.asarray(self.y_train, dtype=float)
        if y.ndim == 1:
            y = y[:, None]
        self.y_train = y
        self.y_target = np.asarray(self.y_target, dtype=float).reshape(-1)
        if self.h_train.size != self.y_train.shape[0]:
            raise ValueError("h_train and y_train have incompatible lengths")
        if self.y_train.shape[1] != self.y_target.size:
            raise ValueError("y_train and y_target have incompatible dimensions")
        if self.h_train.size < 2:
            raise ValueError("at least two training fidelity levels are required")
        if np.any(~np.isfinite(self.h_train)) or np.any(~np.isfinite(self.y_train)):
            raise ValueError("training data contain non-finite values")
        if np.any(np.isclose(self.h_train, self.target_h, rtol=0.0, atol=1e-12)):
            raise ValueError(
                "target_h must be stored separately from the finite trajectory levels"
            )
        order = np.argsort(self.h_train)
        self.h_train = self.h_train[order]
        self.y_train = self.y_train[order]

    @property
    def output_dim(self) -> int:
        return int(self.y_train.shape[1])

    @property
    def n_levels(self) -> int:
        return int(self.h_train.size)


@dataclass
class FitResult:
    method: str
    target_prediction: np.ndarray
    path_prediction: np.ndarray
    hyperparameters: dict[str, Any] = field(default_factory=dict)
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.target_prediction = np.asarray(self.target_prediction, dtype=float).reshape(-1)
        path = np.asarray(self.path_prediction, dtype=float)
        if path.ndim == 1:
            path = path[:, None]
        self.path_prediction = path
