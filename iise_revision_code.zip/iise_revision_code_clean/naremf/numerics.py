from __future__ import annotations

import math
from typing import Iterable

import numpy as np
from numpy.linalg import LinAlgError
from scipy.linalg import cho_factor, cho_solve


def stable_cholesky(matrix: np.ndarray, initial_jitter: float = 1e-10, max_tries: int = 9):
    matrix = np.asarray(matrix, dtype=float)
    jitter = initial_jitter
    identity = np.eye(matrix.shape[0])
    last_error: Exception | None = None
    for _ in range(max_tries):
        try:
            factor = cho_factor(matrix + jitter * identity, lower=True, check_finite=False)
            return factor, jitter
        except (LinAlgError, ValueError) as exc:
            last_error = exc
            jitter *= 10.0
    raise LinAlgError(f"Cholesky factorization failed after jitter escalation: {last_error}")


def solve_spd(matrix: np.ndarray, rhs: np.ndarray, initial_jitter: float = 1e-10):
    factor, jitter = stable_cholesky(matrix, initial_jitter=initial_jitter)
    return cho_solve(factor, rhs, check_finite=False), jitter


def logdet_spd(matrix: np.ndarray, initial_jitter: float = 1e-10) -> tuple[float, float]:
    factor, jitter = stable_cholesky(matrix, initial_jitter=initial_jitter)
    c, _ = factor
    return float(2.0 * np.sum(np.log(np.diag(c)))), jitter


def deterministic_starts(bounds: list[tuple[float, float]], n_random: int = 4, seed: int = 20260827) -> list[np.ndarray]:
    """Create deterministic centre/corner/random starts for bounded optimization."""
    rng = np.random.default_rng(seed)
    lower = np.array([b[0] for b in bounds], dtype=float)
    upper = np.array([b[1] for b in bounds], dtype=float)
    starts = [(lower + upper) / 2.0]
    starts.append(lower + 0.25 * (upper - lower))
    starts.append(lower + 0.75 * (upper - lower))
    for _ in range(n_random):
        starts.append(rng.uniform(lower, upper))
    return starts


def normalize_inputs(x: np.ndarray) -> tuple[np.ndarray, float, float]:
    x = np.asarray(x, dtype=float)
    xmin = float(np.min(x))
    span = float(np.max(x) - xmin)
    if span <= 0:
        span = 1.0
    return (x - xmin) / span, xmin, span


def as_2d(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    return y[:, None] if y.ndim == 1 else y


def jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value
