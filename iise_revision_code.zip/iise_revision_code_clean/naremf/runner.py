from __future__ import annotations

import json
import os
import time
import traceback
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .metrics import path_error, point_error
from .numerics import jsonable
from .types import FitResult, TrajectoryDataset

ROOT = Path(os.environ.get("IISE_OUTPUT_DIR", Path(__file__).resolve().parents[1] / "outputs")).resolve()


def ensure_output_dirs(output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir = ROOT / "figures" / output_dir.name
    table_dir = ROOT / "tables" / output_dir.name
    figure_dir.mkdir(parents=True, exist_ok=True)
    table_dir.mkdir(parents=True, exist_ok=True)
    return figure_dir, table_dir


def _safe_scalar(value):
    value = jsonable(value)
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return value


def run_models(
    dataset: TrajectoryDataset,
    models: Iterable,
    scenario: dict | None = None,
    fail_fast: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, FitResult]]:
    scenario = dict(scenario or {})
    summary_rows: list[dict] = []
    prediction_rows: list[dict] = []
    successful: dict[str, FitResult] = {}

    for model in models:
        start = time.perf_counter()
        try:
            result: FitResult = model.fit_predict(dataset)
            elapsed = time.perf_counter() - start
            if result.path_prediction.shape != dataset.y_train.shape:
                raise ValueError(
                    f"path prediction shape {result.path_prediction.shape} does not match {dataset.y_train.shape}"
                )
            if result.target_prediction.shape != dataset.y_target.shape:
                raise ValueError(
                    f"target prediction shape {result.target_prediction.shape} does not match {dataset.y_target.shape}"
                )
            p_error = point_error(dataset.y_target, result.target_prediction)
            tr_error = path_error(dataset.y_train, result.path_prediction)
            successful[result.method] = result
            row = {
                **scenario,
                "dataset": dataset.name,
                "method": result.method,
                "status": "ok",
                "n_levels": dataset.n_levels,
                "target_h": dataset.target_h,
                "point_error": p_error,
                "path_error": tr_error,
                "runtime_seconds": elapsed,
                "target_reference": json.dumps(jsonable(dataset.y_target)),
                "target_prediction": json.dumps(jsonable(result.target_prediction)),
                "error_message": "",
            }
            for key, value in result.hyperparameters.items():
                row[f"hp_{key}"] = _safe_scalar(value)
            for key, value in result.diagnostics.items():
                row[f"diag_{key}"] = _safe_scalar(value)
            summary_rows.append(row)

            for i, h in enumerate(dataset.h_train):
                for component in range(dataset.output_dim):
                    prediction_rows.append(
                        {
                            **scenario,
                            "dataset": dataset.name,
                            "method": result.method,
                            "kind": "training_path",
                            "h": h,
                            "component": component + 1,
                            "reference": dataset.y_train[i, component],
                            "prediction": result.path_prediction[i, component],
                        }
                    )
            for component in range(dataset.output_dim):
                prediction_rows.append(
                    {
                        **scenario,
                        "dataset": dataset.name,
                        "method": result.method,
                        "kind": "held_out_target",
                        "h": dataset.target_h,
                        "component": component + 1,
                        "reference": dataset.y_target[component],
                        "prediction": result.target_prediction[component],
                    }
                )
        except Exception as exc:
            elapsed = time.perf_counter() - start
            summary_rows.append(
                {
                    **scenario,
                    "dataset": dataset.name,
                    "method": getattr(model, "name", type(model).__name__),
                    "status": "failed",
                    "n_levels": dataset.n_levels,
                    "target_h": dataset.target_h,
                    "point_error": np.nan,
                    "path_error": np.nan,
                    "runtime_seconds": elapsed,
                    "target_reference": json.dumps(jsonable(dataset.y_target)),
                    "target_prediction": "",
                    "error_message": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(limit=5),
                }
            )
            if fail_fast:
                raise

    return pd.DataFrame(summary_rows), pd.DataFrame(prediction_rows), successful


def save_run(
    output_dir: Path,
    summary: pd.DataFrame,
    predictions: pd.DataFrame,
    metadata: dict | None = None,
    prefix: str = "results",
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output_dir / f"{prefix}.csv", index=False)
    predictions.to_csv(output_dir / f"{prefix}_predictions.csv", index=False)
    if metadata is not None:
        (output_dir / f"{prefix}_metadata.json").write_text(
            json.dumps(jsonable(metadata), ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )


def plot_trajectory_comparison(
    dataset: TrajectoryDataset,
    results: dict[str, FitResult],
    output_path: Path,
    title: str | None = None,
    max_cols: int = 3,
) -> None:
    if not results:
        return
    methods = list(results)
    n = len(methods)
    cols = min(max_cols, n)
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(5.0 * cols, 3.7 * rows), squeeze=False)
    x_train = dataset.h_train
    for ax, method in zip(axes.ravel(), methods):
        result = results[method]
        for component in range(dataset.output_dim):
            label_ref = "Reference" if component == 0 else f"Reference {component + 1}"
            label_pred = "Predicted" if component == 0 else f"Predicted {component + 1}"
            ax.plot(x_train, dataset.y_train[:, component], "o-", label=label_ref, markersize=3)
            ax.plot(x_train, result.path_prediction[:, component], "--", label=label_pred)
            ax.plot(dataset.target_h, dataset.y_target[component], marker="*", markersize=10, linestyle="None")
            ax.plot(dataset.target_h, result.target_prediction[component], marker="x", markersize=8, linestyle="None")
        ax.set_title(method)
        ax.set_xlabel("h")
        ax.set_ylabel(r"Calibration parameter")
        ax.grid(True, alpha=0.25)
        ax.legend(fontsize=7)
    for ax in axes.ravel()[n:]:
        ax.axis("off")
    if title:
        fig.suptitle(title, y=1.01)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def default_models(seed: int = 20260827, include_complex: bool = True):
    from .models import (
        GPStateSpace,
        GaussRichardson,
        GeneralizedRichardson,
        NAREComplex,
        NARESimple,
        RationalKriging,
        ScaledAR,
        StationaryGP,
        UniversalGP,
    )

    models = [NARESimple()]
    if include_complex:
        models.append(NAREComplex(seed=seed))
    models.extend(
        [
            GeneralizedRichardson(),
            GaussRichardson(seed=seed),
            StationaryGP(criterion="loocv", seed=seed),
            GPStateSpace(criterion="mle", seed=seed),
            UniversalGP(criterion="loocv", seed=seed),
            ScaledAR(),
            RationalKriging(seed=seed),
        ]
    )
    return models
