from __future__ import annotations

"""Utilities that reproduce and audit the manuscript's original scoring logic.

The legacy protocol is *not* a uniform held-out-h protocol.  For Test 2 and
Test 3, a fixed candidate hyperparameter configuration is evaluated separately
on five calibration settings.  Each setting contributes

    path_MSE + endpoint_MSE,

and the candidate is ranked by the mean of those five setting-wise scores.
This is exactly what the original scripts implement.  It is not a nested
outer 4-settings-to-1-setting transfer experiment, because no setting is
excluded while the candidate is selected.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .metrics import path_error, point_error, rmse
from .types import TrajectoryDataset

ROOT = Path(__file__).resolve().parents[1]

TEST2_SETTINGS = (1.0, 2.0, -1.0, -2.0, 0.0)
TEST2_SELECTED_H_NOISE_FREE = np.array(
    [0.01, 0.015, 0.02, 0.025, 0.03, 0.035, 0.04, 0.045,
     0.05, 0.055, 0.06, 0.065, 0.07, 0.075, 0.08, 0.09, 0.10],
    dtype=float,
)
TEST2_SELECTED_H_NOISY = TEST2_SELECTED_H_NOISE_FREE[1:]


@dataclass(frozen=True)
class LegacyScore:
    path_mse: float
    endpoint_mse: float
    aggregate_score: float
    point_relative_l2: float
    path_relative_l2: float
    endpoint_absolute_error: float


def legacy_setting_score(
    path_reference: np.ndarray,
    path_prediction: np.ndarray,
    endpoint_reference: np.ndarray,
    endpoint_prediction: np.ndarray,
) -> LegacyScore:
    """Compute the exact score decomposition used by the original scripts."""
    path_reference = np.asarray(path_reference, dtype=float)
    path_prediction = np.asarray(path_prediction, dtype=float)
    endpoint_reference = np.asarray(endpoint_reference, dtype=float)
    endpoint_prediction = np.asarray(endpoint_prediction, dtype=float)
    path_mse = float(np.mean((path_prediction - path_reference) ** 2))
    endpoint_mse = float(np.mean((endpoint_prediction - endpoint_reference) ** 2))
    return LegacyScore(
        path_mse=path_mse,
        endpoint_mse=endpoint_mse,
        aggregate_score=path_mse + endpoint_mse,
        point_relative_l2=point_error(endpoint_reference, endpoint_prediction),
        path_relative_l2=path_error(path_reference, path_prediction),
        endpoint_absolute_error=float(np.linalg.norm((endpoint_prediction-endpoint_reference).ravel())),
    )


def average_candidate_score(setting_scores: Iterable[float]) -> float:
    values = np.asarray(list(setting_scores), dtype=float)
    if values.size == 0 or np.any(~np.isfinite(values)):
        raise ValueError("setting_scores must be a non-empty finite sequence")
    return float(np.mean(values))


def subset_to_original_test2_levels(dataset: TrajectoryDataset) -> TrajectoryDataset:
    """Return the exact finite mesh levels selected by the original Test 2 scripts."""
    requested = TEST2_SELECTED_H_NOISE_FREE if np.isclose(dataset.target_h, 0.0) else TEST2_SELECTED_H_NOISY
    indices: list[int] = []
    for h in requested:
        match = np.flatnonzero(np.isclose(dataset.h_train, h, rtol=0.0, atol=1e-12))
        if match.size != 1:
            raise ValueError(f"original Test 2 level h={h:g} is unavailable in {dataset.name}")
        indices.append(int(match[0]))
    return TrajectoryDataset(
        name=dataset.name + "_legacy_levels",
        h_train=dataset.h_train[indices],
        y_train=dataset.y_train[indices],
        target_h=dataset.target_h,
        y_target=dataset.y_target,
        metadata={
            **dataset.metadata,
            "mesh_selection": "exact original index list [0,...,14,16,18] before reversing",
            "legacy_endpoint_in_candidate_score": True,
        },
    )


def protocol_classification() -> dict:
    return {
        "test2_strict_outer_4_to_1_transfer": False,
        "test2_actual_mechanism": (
            "For each fixed candidate hyperparameter configuration, compute one endpoint-weighted "
            "trajectory score on each of a={1,2,-1,-2,0}, then average the five scores."
        ),
        "algebraic_identity": "mean([score_a1,...,score_a5]) is the five-setting average for that fixed candidate",
        "what_is_not_done": (
            "The original scripts do not exclude one a, select the candidate using the remaining four, "
            "and then evaluate the selected candidate on the excluded a."
        ),
        "primary_protocol_in_v2": "legacy cross-setting endpoint-weighted candidate score",
        "uniform_held_out_h_protocol_removed": True,
    }
