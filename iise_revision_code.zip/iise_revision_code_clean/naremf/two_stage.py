from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Callable

import numpy as np
from scipy.linalg import cho_solve
from scipy.optimize import minimize
from scipy.sparse import coo_matrix, csc_matrix
from scipy.sparse.linalg import splu

from .numerics import deterministic_starts, stable_cholesky


def _se(h1: np.ndarray, h2: np.ndarray, lengthscale: float) -> np.ndarray:
    h1 = np.asarray(h1, dtype=float).reshape(-1)
    h2 = np.asarray(h2, dtype=float).reshape(-1)
    d2 = (h1[:, None] - h2[None, :]) ** 2
    return np.exp(-0.5 * d2 / max(lengthscale**2, 1e-16))


@dataclass
class SharedOutputGP:
    """A GP over fidelity h with covariance shared across all simulator outputs.

    The hyperparameters are fitted on a representative subset of output columns.
    Conditional on those hyperparameters, each simulator-output coordinate receives
    its own generalized-least-squares constant mean.  This is a compact, fully
    deterministic implementation of the AE-requested strategy: first emulate the
    high-fidelity response, then calibrate that emulated response.
    """

    h_train: np.ndarray
    h_min: float
    h_span: float
    lengthscale: float
    nugget: float
    cholesky: tuple
    objective: float
    optimizer_success: bool

    @classmethod
    def fit(
        cls,
        h_train: np.ndarray,
        output_sample: np.ndarray,
        seed: int = 20260827,
    ) -> "SharedOutputGP":
        h = np.asarray(h_train, dtype=float).reshape(-1)
        y = np.asarray(output_sample, dtype=float)
        if y.ndim == 1:
            y = y[:, None]
        if y.shape[0] != h.size:
            raise ValueError("output_sample must have one row per fidelity level")
        h_min = float(np.min(h))
        h_span = max(float(np.max(h) - h_min), 1e-12)
        x = (h - h_min) / h_span
        y_mean = np.mean(y, axis=0)
        y_scale = np.std(y, axis=0)
        keep = y_scale > 1e-10
        if not np.any(keep):
            raise ValueError("all sampled simulator-output columns are constant across fidelity")
        yz = (y[:, keep] - y_mean[keep]) / y_scale[keep]
        # Limit the fitting sample to keep the objective inexpensive and balanced.
        if yz.shape[1] > 1200:
            index = np.linspace(0, yz.shape[1] - 1, 1200, dtype=int)
            yz = yz[:, index]

        bounds = [(np.log(0.02), np.log(20.0)), (np.log(1e-10), np.log(0.3))]
        one = np.ones(h.size)

        def state(lengthscale: float, nugget: float):
            K = _se(x, x, lengthscale) + nugget * np.eye(h.size)
            chol, jitter = stable_cholesky(K, initial_jitter=1e-12)
            kinv_one = cho_solve(chol, one, check_finite=False)
            kinv_y = cho_solve(chol, yz, check_finite=False)
            denom = max(float(one @ kinv_one), 1e-15)
            mu = (one @ kinv_y) / denom
            residual = yz - one[:, None] * mu[None, :]
            alpha = cho_solve(chol, residual, check_finite=False)
            sigma2 = np.maximum(np.sum(residual * alpha, axis=0) / h.size, 1e-14)
            logdet = float(2.0 * np.sum(np.log(np.diag(chol[0]))))
            objective = float(np.sum(h.size * np.log(sigma2)) + yz.shape[1] * logdet)
            return K, chol, jitter, objective

        def objective(z: np.ndarray) -> float:
            try:
                return state(float(np.exp(z[0])), float(np.exp(z[1])))[-1]
            except Exception:
                return 1e100

        best = None
        for start in deterministic_starts(bounds, n_random=3, seed=seed):
            candidate = minimize(
                objective,
                start,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 160, "ftol": 1e-9},
            )
            if best is None or candidate.fun < best.fun:
                best = candidate
        assert best is not None
        lengthscale, nugget = map(float, np.exp(best.x))
        _, chol, _, obj = state(lengthscale, nugget)
        return cls(
            h_train=h,
            h_min=h_min,
            h_span=h_span,
            lengthscale=lengthscale,
            nugget=nugget,
            cholesky=chol,
            objective=obj,
            optimizer_success=bool(best.success),
        )

    def predict(self, training_outputs: np.ndarray, h_target: float) -> np.ndarray:
        """Predict all output columns at h_target from an n_h by n_output matrix."""
        y = np.asarray(training_outputs, dtype=float)
        if y.ndim == 1:
            y = y[:, None]
        if y.shape[0] != self.h_train.size:
            raise ValueError("training_outputs must have one row per fidelity level")
        x = (self.h_train - self.h_min) / self.h_span
        xt = (float(h_target) - self.h_min) / self.h_span
        one = np.ones(self.h_train.size)
        kinv_one = cho_solve(self.cholesky, one, check_finite=False)
        kinv_y = cho_solve(self.cholesky, y, check_finite=False)
        denom = max(float(one @ kinv_one), 1e-15)
        mu = (one @ kinv_y) / denom
        residual = y - one[:, None] * mu[None, :]
        alpha = cho_solve(self.cholesky, residual, check_finite=False)
        k = _se(x, np.array([xt]), self.lengthscale).reshape(-1)
        return mu + k @ alpha


def test1_simulator(h: np.ndarray | float, theta: np.ndarray | float, x: np.ndarray) -> np.ndarray:
    h = np.asarray(h, dtype=float).reshape(-1, 1, 1)
    theta = np.asarray(theta, dtype=float).reshape(1, -1, 1)
    x = np.asarray(x, dtype=float).reshape(1, 1, -1)
    xi = np.exp(0.1 * x) * np.sin(x)
    return xi - 0.1 * np.sqrt((h * theta) ** 2 + 1.0) * (
        np.sin(theta * x) + np.cos(theta * x)
    )


def calibrate_grid(parameter_grid: np.ndarray, predictions: np.ndarray, physical: np.ndarray) -> tuple[float, float]:
    """Grid calibration with a local quadratic refinement of the objective."""
    grid = np.asarray(parameter_grid, dtype=float).reshape(-1)
    pred = np.asarray(predictions, dtype=float)
    physical = np.asarray(physical, dtype=float).reshape(-1)
    if pred.shape != (grid.size, physical.size):
        raise ValueError(f"predictions have shape {pred.shape}; expected {(grid.size, physical.size)}")
    objective = np.mean((pred - physical[None, :]) ** 2, axis=1)
    i = int(np.argmin(objective))
    estimate = float(grid[i])
    minimum = float(objective[i])
    if 0 < i < grid.size - 1:
        x = grid[i - 1 : i + 2]
        y = objective[i - 1 : i + 2]
        coeff = np.polyfit(x, y, 2)
        if coeff[0] > 0:
            vertex = float(-coeff[1] / (2.0 * coeff[0]))
            if x[0] <= vertex <= x[-1]:
                estimate = vertex
                minimum = float(np.polyval(coeff, vertex))
    return estimate, minimum


class StructuredPoissonFEM:
    """Portable P1 finite-element solver on a uniformly triangulated unit square.

    This replaces the legacy FEniCS path dependency while retaining the same PDE,
    zero Dirichlet boundary condition, linear elements, and `int(1/h)` mesh rule.
    A sparse factorization is cached for each mesh, and multiple candidate values of
    the calibration parameter are solved simultaneously.
    """

    def __init__(self, h: float):
        self.requested_h = float(h)
        self.n = max(int(1.0 / self.requested_h), 2)
        self.effective_h = 1.0 / self.n
        self._build()

    def _build(self) -> None:
        n = self.n
        coords = np.array([(i / n, j / n) for j in range(n + 1) for i in range(n + 1)], dtype=float)
        triangles = []
        for j in range(n):
            for i in range(n):
                bl = j * (n + 1) + i
                br = bl + 1
                tl = bl + (n + 1)
                tr = tl + 1
                triangles.append((bl, br, tr))
                triangles.append((bl, tr, tl))
        triangles = np.asarray(triangles, dtype=int)
        boundary = (
            np.isclose(coords[:, 0], 0.0)
            | np.isclose(coords[:, 0], 1.0)
            | np.isclose(coords[:, 1], 0.0)
            | np.isclose(coords[:, 1], 1.0)
        )
        interior_nodes = np.flatnonzero(~boundary)
        global_to_interior = np.full(coords.shape[0], -1, dtype=int)
        global_to_interior[interior_nodes] = np.arange(interior_nodes.size)

        rows: list[int] = []
        cols: list[int] = []
        vals: list[float] = []
        centroids = np.empty((triangles.shape[0], 2), dtype=float)
        areas = np.empty(triangles.shape[0], dtype=float)
        local_interior = global_to_interior[triangles]

        for t, vertices in enumerate(triangles):
            xy = coords[vertices]
            mat = np.array(
                [[1.0, xy[0, 0], xy[0, 1]], [1.0, xy[1, 0], xy[1, 1]], [1.0, xy[2, 0], xy[2, 1]]],
                dtype=float,
            )
            det = float(np.linalg.det(mat))
            area = abs(det) / 2.0
            areas[t] = area
            centroids[t] = np.mean(xy, axis=0)
            # Gradients are columns 1: of the inverse interpolation matrix.
            inv = np.linalg.inv(mat)
            gradients = inv[1:, :].T
            ke = area * (gradients @ gradients.T)
            for a in range(3):
                ia = local_interior[t, a]
                if ia < 0:
                    continue
                for b in range(3):
                    ib = local_interior[t, b]
                    if ib < 0:
                        continue
                    rows.append(int(ia))
                    cols.append(int(ib))
                    vals.append(float(ke[a, b]))

        stiffness = coo_matrix((vals, (rows, cols)), shape=(interior_nodes.size, interior_nodes.size)).tocsc()
        self.coords = coords
        self.triangles = triangles
        self.centroids = centroids
        self.areas = areas
        self.local_interior = local_interior
        self.interior_nodes = interior_nodes
        self.factor = splu(stiffness)

    @staticmethod
    def rhs_expression(a_values: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        a = np.asarray(a_values, dtype=float).reshape(1, -1)
        x = np.asarray(x, dtype=float).reshape(-1, 1)
        y = np.asarray(y, dtype=float).reshape(-1, 1)
        return (
            (a**2 - 2.0 * np.pi**2) * np.exp(a * x) * np.sin(np.pi * x) * np.sin(np.pi * y)
            + 2.0 * a * np.pi * np.exp(a * x) * np.cos(np.pi * x) * np.sin(np.pi * y)
        )

    def solve_many(self, a_values: np.ndarray, points: np.ndarray) -> np.ndarray:
        a_values = np.asarray(a_values, dtype=float).reshape(-1)
        # Weak form in the legacy code: int grad(u).grad(v) = int -f v.
        f = -self.rhs_expression(a_values, self.centroids[:, 0], self.centroids[:, 1])
        rhs = np.zeros((self.interior_nodes.size, a_values.size), dtype=float)
        contribution = self.areas[:, None] * f / 3.0
        for local in range(3):
            idx = self.local_interior[:, local]
            mask = idx >= 0
            np.add.at(rhs, idx[mask], contribution[mask])
        solution_interior = self.factor.solve(rhs)
        full = np.zeros((self.coords.shape[0], a_values.size), dtype=float)
        full[self.interior_nodes] = solution_interior
        return self.interpolate_many(full, points).T  # n_a by n_points

    def interpolate_many(self, nodal_values: np.ndarray, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=float).reshape(-1, 2)
        n = self.n
        x = np.clip(points[:, 0], 0.0, 1.0)
        y = np.clip(points[:, 1], 0.0, 1.0)
        i = np.minimum((x * n).astype(int), n - 1)
        j = np.minimum((y * n).astype(int), n - 1)
        sx = x * n - i
        sy = y * n - j
        bl = j * (n + 1) + i
        br = bl + 1
        tl = bl + (n + 1)
        tr = tl + 1
        out = np.empty((points.shape[0], nodal_values.shape[1]), dtype=float)
        lower = sy <= sx
        if np.any(lower):
            q = np.flatnonzero(lower)
            out[q] = (
                (1.0 - sx[q])[:, None] * nodal_values[bl[q]]
                + (sx[q] - sy[q])[:, None] * nodal_values[br[q]]
                + sy[q][:, None] * nodal_values[tr[q]]
            )
        if np.any(~lower):
            q = np.flatnonzero(~lower)
            out[q] = (
                (1.0 - sy[q])[:, None] * nodal_values[bl[q]]
                + sx[q][:, None] * nodal_values[tr[q]]
                + (sy[q] - sx[q])[:, None] * nodal_values[tl[q]]
            )
        boundary = np.isclose(x, 0.0) | np.isclose(x, 1.0) | np.isclose(y, 0.0) | np.isclose(y, 1.0)
        out[boundary] = 0.0
        return out


def poisson_exact(a_values: np.ndarray, points: np.ndarray) -> np.ndarray:
    a = np.asarray(a_values, dtype=float).reshape(-1, 1)
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    x = points[:, 0][None, :]
    y = points[:, 1][None, :]
    return np.exp(a * x) * np.sin(np.pi * x) * np.sin(np.pi * y)


def generate_poisson_outputs(
    h_values: np.ndarray,
    a_values: np.ndarray,
    points: np.ndarray,
    progress: Callable[[str], None] | None = None,
) -> np.ndarray:
    h_values = np.asarray(h_values, dtype=float).reshape(-1)
    a_values = np.asarray(a_values, dtype=float).reshape(-1)
    outputs = np.empty((h_values.size, a_values.size, np.asarray(points).reshape(-1, 2).shape[0]), dtype=float)
    for i, h in enumerate(h_values):
        if progress:
            progress(f"solving structured P1 FEM at requested h={h:g} ({i + 1}/{h_values.size})")
        outputs[i] = StructuredPoissonFEM(float(h)).solve_many(a_values, points)
    return outputs
