import numpy as np
import torch

def covariance_Brownian(sigma, t1, t2):
    return sigma**2 * torch.min(t1, t2)

def compute_next_theta(check, theta_hat,h):
    # train_xt是t，也就是h，用于算cov
    train_xt = torch.tensor(h) #check
    KXX_new = np.array([[covariance_Brownian(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_Brownian(sigma, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[0:check] #todo check
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def covariance(x1, x2, sigma, length_scale):
    """Gaussian covariance function"""
    return sigma ** 2 * np.exp(-(x1 - x2) ** 2 / (2 * length_scale ** 2))
