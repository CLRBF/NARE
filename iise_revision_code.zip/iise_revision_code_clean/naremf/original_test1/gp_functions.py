import numpy as np
import torch

def stationary(sigma, l,t1, t2):
    return sigma**2 * torch.exp(-(t1-t2)**2/(2 * l**2))

def compute_next_theta(check, theta_hat,h):
    # train_xt是t，也就是h，用于算cov
    train_xt = torch.tensor(h) #check
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    # y = theta_hat[1:check+1]
    y = theta_hat[0:check]
    y = torch.tensor(y)
    # mu = torch.dot(torch.dot(k00, torch.linalg.inv(KXX_new)), y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def compute_next_theta_v2(check, theta_hat,h):
    #train_xt 是\theta^*
    train_xt = torch.tensor(theta_hat)
    KXX_new = np.array([[stationary(sigma, l,xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma,l,xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    "真实的f，就是theta_hat"
    y = theta_hat[1:check+1]
    # y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu
