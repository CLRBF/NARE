from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from .types import FitResult, TrajectoryDataset


class TrajectoryModel(ABC):
    name: str

    @abstractmethod
    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        raise NotImplementedError

    @staticmethod
    def _coarse_to_fine(dataset: TrajectoryDataset) -> tuple[np.ndarray, np.ndarray]:
        order = np.argsort(dataset.h_train)[::-1]
        return dataset.h_train[order], dataset.y_train[order]
