from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .types import TrajectoryDataset

ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT / "data"
TRAJECTORY_ROOT = DATA_ROOT / "trajectories"
OBSERVATION_ROOT = DATA_ROOT / "observations"


def _closest(values: Iterable[float], requested: float) -> float:
    arr = np.asarray(list(values), dtype=float)
    if arr.size == 0:
        raise ValueError("no values are available")
    idx = int(np.argmin(np.abs(arr - requested)))
    chosen = float(arr[idx])
    if not np.isclose(chosen, requested, rtol=0.0, atol=1e-10):
        raise ValueError(f"requested value {requested!r} is unavailable; choices are {arr.tolist()}")
    return chosen


def load_test1(noise_std: float = 0.0) -> TrajectoryDataset:
    frame = pd.read_csv(TRAJECTORY_ROOT / "test1.csv")
    noise = _closest(frame["noise_std"].unique(), noise_std)
    subset = frame[np.isclose(frame["noise_std"], noise)].copy().sort_values("h")
    target_rows = subset[subset["is_target"].astype(bool)]
    train_rows = subset[~subset["is_target"].astype(bool)]
    if len(target_rows) != 1:
        raise ValueError("Test 1 must contain exactly one held-out target")
    target = target_rows.iloc[0]
    return TrajectoryDataset(
        name=f"test1_noise_{noise:g}",
        h_train=train_rows["h"].to_numpy(float),
        y_train=train_rows[["theta"]].to_numpy(float),
        target_h=float(target["h"]),
        y_target=np.array([float(target["theta"])]),
        metadata={
            "experiment": "Test 1: imperfect computer model",
            "noise_std": noise,
            "target_definition": "analytic simulator evaluated at h=0; stored separately and used by the original endpoint-weighted validation score",
            "source_file": "data/trajectories/test1.csv",
        },
    )


def load_test2(a_true: float = 1.0, noise_std: float = 0.0) -> TrajectoryDataset:
    frame = pd.read_csv(TRAJECTORY_ROOT / "test2.csv")
    a_value = _closest(frame["a_true"].unique(), a_true)
    noise = _closest(frame["noise_std"].unique(), noise_std)
    subset = frame[
        np.isclose(frame["a_true"], a_value) & np.isclose(frame["noise_std"], noise)
    ].copy().sort_values("h")

    if np.isclose(noise, 0.0):
        # The paper's noise-free continuum target is analytically known.
        target_h = 0.0
        y_target = np.array([a_value], dtype=float)
        train_rows = subset.copy()
        target_definition = "analytical continuum value a*(0)=a_true; endpoint is included in the original candidate-score criterion"
    else:
        target_rows = subset[subset["is_target"].astype(bool)]
        train_rows = subset[~subset["is_target"].astype(bool)]
        if len(target_rows) != 1:
            raise ValueError("Noisy Test 2 must contain exactly one held-out fine-mesh target")
        target = target_rows.iloc[0]
        target_h = float(target["h"])
        y_target = np.array([float(target["a_calibrated"])] )
        target_definition = "finest h=0.01 calibrated value; endpoint is included in the original candidate-score criterion"

    # Preserve the exact Test 2 mesh-selection logic from the original scripts:
    # original ascending indices [0,1,...,14,16,18], with h=0.01 removed in noisy cases.
    legacy_h = np.array([0.01,0.015,0.02,0.025,0.03,0.035,0.04,0.045,0.05,0.055,0.06,0.065,0.07,0.075,0.08,0.09,0.10])
    if not np.isclose(noise, 0.0):
        legacy_h = legacy_h[1:]
    train_rows = train_rows[train_rows["h"].apply(lambda v: bool(np.any(np.isclose(v, legacy_h, rtol=0.0, atol=1e-12))))].copy()
    if len(train_rows) != len(legacy_h):
        raise ValueError(f"Test 2 legacy mesh selection expected {len(legacy_h)} levels, found {len(train_rows)}")

    return TrajectoryDataset(
        name=f"test2_a_{a_value:g}_noise_{noise:g}",
        h_train=train_rows["h"].to_numpy(float),
        y_train=train_rows[["a_calibrated"]].to_numpy(float),
        target_h=target_h,
        y_target=y_target,
        metadata={
            "experiment": "Test 2: Poisson equation",
            "a_true": a_value,
            "noise_std": noise,
            "target_definition": target_definition,
            "source_file": "data/trajectories/test2.csv",
            "mesh_selection": "legacy indices [0,...,14,16,18]",
            "endpoint_used_in_legacy_candidate_score": True,
        },
    )


def load_test3_selected(variable: int = 1, scenario: str = "noise_free") -> TrajectoryDataset:
    frame = pd.read_csv(TRAJECTORY_ROOT / "test3_selected.csv")
    subset = frame[(frame["variable"] == int(variable)) & (frame["scenario"] == scenario)].copy()
    if subset.empty:
        raise ValueError(f"Test 3 selected trajectory is unavailable for variable={variable}, scenario={scenario!r}")
    subset = subset.sort_values("h")
    target_rows = subset[subset["is_target"].astype(bool)]
    train_rows = subset[~subset["is_target"].astype(bool)]
    if len(target_rows) != 1:
        raise ValueError("Test 3 selected data must contain exactly one target")
    target = target_rows.iloc[0]
    return TrajectoryDataset(
        name=f"test3_selected_variable_{variable}_{scenario}",
        h_train=train_rows["h"].to_numpy(float),
        y_train=train_rows[["theta1", "theta2"]].to_numpy(float),
        target_h=float(target["h"]),
        y_target=target[["theta1", "theta2"]].to_numpy(float),
        metadata={
            "experiment": "Test 3: turbine-blade thermal-stress trajectory",
            "variable": int(variable),
            "scenario": scenario,
            "variant": "archived_selected_subsequence",
            "selection_note": (
                "This is the subsequence stored in the legacy archive. It is sparse rather than contiguous; "
                "the clean code reports this provenance explicitly."
            ),
            "source_file": "data/trajectories/test3_selected.csv",
        },
    )


def load_test3_full(scenario: str = "noise_free") -> TrajectoryDataset:
    frame = pd.read_csv(TRAJECTORY_ROOT / "test3_full.csv")
    subset = frame[(frame["variable"] == 1) & (frame["scenario"] == scenario)].copy().sort_values("h")
    if subset.empty:
        raise ValueError(f"full Test 3 trajectory is unavailable for scenario={scenario!r}")
    target_rows = subset[subset["is_target"].astype(bool)]
    train_rows = subset[~subset["is_target"].astype(bool)]
    if len(target_rows) != 1:
        raise ValueError("full Test 3 data must contain exactly one target")
    target = target_rows.iloc[0]
    return TrajectoryDataset(
        name=f"test3_full_variable_1_{scenario}",
        h_train=train_rows["h"].to_numpy(float),
        y_train=train_rows[["theta1", "theta2"]].to_numpy(float),
        target_h=float(target["h"]),
        y_target=target[["theta1", "theta2"]].to_numpy(float),
        metadata={
            "experiment": "Test 3: turbine-blade thermal-stress trajectory",
            "variable": 1,
            "scenario": scenario,
            "variant": "full_consecutive_trajectory",
            "source_file": "data/trajectories/test3_full.csv",
        },
    )


def subset_dataset(dataset: TrajectoryDataset, indices: np.ndarray | list[int], name: str, **metadata) -> TrajectoryDataset:
    idx = np.asarray(indices, dtype=int)
    if idx.size < 2:
        raise ValueError("a subset must contain at least two training levels")
    meta = dict(dataset.metadata)
    meta.update(metadata)
    return TrajectoryDataset(
        name=name,
        h_train=dataset.h_train[idx],
        y_train=dataset.y_train[idx],
        target_h=dataset.target_h,
        y_target=dataset.y_target,
        metadata=meta,
    )


def _longest_monotone_indices(y: np.ndarray, direction: int, tol: float = 0.0) -> np.ndarray:
    """Longest joint monotone subsequence anchored at the finest training level.

    Rows are assumed ordered from finest to coarsest.  `direction=1` requires
    componentwise nondecreasing values; `direction=-1` requires nonincreasing.
    The first row is always retained.  The dynamic program is deterministic and
    ties are resolved in favor of the lexicographically earlier sequence.
    """
    y = np.asarray(y, dtype=float)
    n = y.shape[0]
    best_paths: list[tuple[int, ...] | None] = [None] * n
    best_paths[0] = (0,)
    for j in range(1, n):
        candidates: list[tuple[int, ...]] = []
        for i in range(j):
            path = best_paths[i]
            if path is None:
                continue
            delta = direction * (y[j] - y[i])
            if np.all(delta >= -tol):
                candidates.append(path + (j,))
        if candidates:
            candidates.sort(key=lambda p: (-len(p), p))
            best_paths[j] = candidates[0]
    feasible = [p for p in best_paths if p is not None]
    feasible.sort(key=lambda p: (-len(p), p))
    return np.asarray(feasible[0], dtype=int)


def longest_joint_monotone_subsequence(dataset: TrajectoryDataset, tol: float = 0.0) -> tuple[np.ndarray, int]:
    """Return the longest finest-anchored joint monotone subsequence.

    The target is not inspected.  Both possible directions are evaluated from
    the finest training level; ties prefer the direction indicated by the
    earliest nonzero increment and then increasing.
    """
    order = np.argsort(dataset.h_train)  # finest to coarsest
    y = dataset.y_train[order]
    inc = _longest_monotone_indices(y, 1, tol=tol)
    dec = _longest_monotone_indices(y, -1, tol=tol)
    if len(inc) > len(dec):
        chosen, direction = inc, 1
    elif len(dec) > len(inc):
        chosen, direction = dec, -1
    else:
        first_direction = 1
        for j in range(1, y.shape[0]):
            diff = y[j] - y[0]
            if np.any(np.abs(diff) > tol):
                first_direction = 1 if float(np.sum(diff)) >= 0 else -1
                break
        chosen, direction = (inc, 1) if first_direction == 1 else (dec, -1)
    return order[chosen], direction


def finest_anchored_contiguous_window(dataset: TrajectoryDataset, tol: float = 0.0) -> tuple[np.ndarray, int]:
    """Longest contiguous window from the finest training level preserving a joint direction."""
    order = np.argsort(dataset.h_train)
    y = dataset.y_train[order]
    if y.shape[0] == 1:
        return order, 1
    direction = 0
    stop = y.shape[0]
    previous = y[0]
    for j in range(1, y.shape[0]):
        delta = y[j] - previous
        if direction == 0 and np.any(np.abs(delta) > tol):
            signs = np.sign(delta[np.abs(delta) > tol])
            if not (np.all(signs >= 0) or np.all(signs <= 0)):
                stop = j
                break
            direction = 1 if np.all(signs >= 0) else -1
        if direction != 0 and np.any(direction * delta < -tol):
            stop = j
            break
        previous = y[j]
    if direction == 0:
        direction = 1
    return order[:stop], direction


def _archived_selected_indices(full: TrajectoryDataset, archived: TrajectoryDataset, atol: float = 1e-10) -> np.ndarray:
    indices = []
    for h in archived.h_train:
        matches = np.flatnonzero(np.isclose(full.h_train, h, rtol=0.0, atol=atol))
        if matches.size != 1:
            raise ValueError(f"cannot align archived h={h} to the full trajectory")
        indices.append(int(matches[0]))
    return np.asarray(indices, dtype=int)


def make_test3_sensitivity_variants(
    scenario: str = "noise_free",
    selection_source: str = "archived",
    tolerance: float = 0.0,
) -> dict[str, TrajectoryDataset]:
    """Create the full/selected/shorter/expanded data versions promised in the response.

    `selection_source='archived'` reproduces the actual sparse subsequence in the
    submitted code.  `selection_source='algorithmic'` uses a deterministic longest
    finest-anchored joint monotone subsequence.  In either case the target is excluded
    before selection, and every method receives exactly the same levels within a variant.

    The archived selected mesh values do not all lie on the 0.00025-spaced full-data
    grid (for example h=0.0166).  Therefore the clean implementation preserves those
    values directly instead of pretending that the archived data are a subset of the
    consecutive trajectory.
    """
    full = load_test3_full(scenario)
    if selection_source == "archived":
        archived = load_test3_selected(1, scenario)
        selected = TrajectoryDataset(
            name=f"test3_selected_archived_{scenario}",
            h_train=archived.h_train,
            y_train=archived.y_train,
            target_h=archived.target_h,
            y_target=archived.y_target,
            metadata={
                **archived.metadata,
                "variant": "selected",
                "selection_source": "archived",
                "selection_rule": "legacy archived sparse monotone subsequence (explicitly reproduced)",
            },
        )
    elif selection_source == "algorithmic":
        selected_idx, direction = longest_joint_monotone_subsequence(full, tol=tolerance)
        selected = subset_dataset(
            full,
            selected_idx,
            name=f"test3_selected_algorithmic_{scenario}",
            variant="selected",
            selection_source="algorithmic",
            selection_rule=(
                "deterministic longest joint monotone subsequence anchored at the finest training level; "
                f"direction={direction:+d}, tolerance={tolerance:g}"
            ),
        )
    else:
        raise ValueError("selection_source must be 'archived' or 'algorithmic'")

    if selected.n_levels > 4:
        shorter_keep = np.arange(selected.n_levels - 2)
    else:
        shorter_keep = np.arange(selected.n_levels - 1)
    shorter = subset_dataset(
        selected,
        shorter_keep,
        name=f"test3_shorter_{selection_source}_{scenario}",
        variant="shorter",
        selection_source=selection_source,
        selection_rule="selected sequence with the two coarsest retained levels removed",
    )

    # Add the first consecutive full-trajectory point coarser than the selected range.
    candidates = full.h_train[full.h_train > np.max(selected.h_train) + 1e-12]
    if candidates.size:
        add_h = float(np.min(candidates))
        add_idx = int(np.flatnonzero(np.isclose(full.h_train, add_h, atol=1e-12))[0])
        h_expanded = np.concatenate([selected.h_train, [full.h_train[add_idx]]])
        y_expanded = np.vstack([selected.y_train, full.y_train[add_idx]])
    else:
        # If no coarser level exists, add the nearest omitted level on either side.
        distances = np.min(np.abs(full.h_train[:, None] - selected.h_train[None, :]), axis=1)
        add_idx = int(np.argmax(distances))
        h_expanded = np.concatenate([selected.h_train, [full.h_train[add_idx]]])
        y_expanded = np.vstack([selected.y_train, full.y_train[add_idx]])
    expanded = TrajectoryDataset(
        name=f"test3_expanded_{selection_source}_{scenario}",
        h_train=h_expanded,
        y_train=y_expanded,
        target_h=selected.target_h,
        y_target=selected.y_target,
        metadata={
            **selected.metadata,
            "variant": "expanded",
            "selection_rule": "selected sequence plus the first excluded coarser consecutive level, when available",
            "added_h": float(full.h_train[add_idx]),
        },
    )

    contiguous_idx, contiguous_direction = finest_anchored_contiguous_window(full, tol=tolerance)
    contiguous = subset_dataset(
        full,
        contiguous_idx,
        name=f"test3_contiguous_diagnostic_{scenario}",
        variant="contiguous_diagnostic",
        selection_source="algorithmic",
        selection_rule=(
            "longest contiguous joint-monotone window anchored at the finest training level; "
            f"direction={contiguous_direction:+d}, tolerance={tolerance:g}"
        ),
    )

    return {
        "full": full,
        "selected": selected,
        "shorter": shorter,
        "expanded": expanded,
        "contiguous_diagnostic": contiguous,
    }

def load_test1_observations(noise_std: float) -> dict[str, np.ndarray]:
    archive = np.load(OBSERVATION_ROOT / "test1_physical.npz")
    available = np.array([0.0, 0.02, 0.05, 0.1], dtype=float)
    noise = _closest(available, noise_std)
    key = f"xi_hat_noise_{noise:g}"
    if key not in archive.files:
        raise ValueError(f"missing normalized Test 1 observation field {key}")
    return {
        "x": archive["x_z"].astype(float),
        "physical": archive[key].astype(float),
        "true_process": archive["true_process"].astype(float),
        "noise_std": np.array(noise),
    }


def load_test2_observations(noise_std: float) -> dict[str, np.ndarray]:
    archive = np.load(OBSERVATION_ROOT / "test2_physical.npz")
    available = np.array([0.0, 0.25, 0.5, 1.0], dtype=float)
    noise = _closest(available, noise_std)
    token = f"{noise:g}"
    points = archive[f"xy_noise_{token}"].astype(float)
    return {
        "points": points.reshape(-1, 2),
        "grid_shape": np.array(points.shape[:2], dtype=int),
        "physical": archive[f"xi_noise_{token}"].astype(float).reshape(-1),
        "true_process": archive[f"true_noise_{token}"].astype(float).reshape(-1),
        "a_true": np.array(1.0),
        "noise_std": np.array(noise),
    }
