from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize

from ..numerics import deterministic_starts, stable_cholesky


@dataclass
class GPState:
    x_train: np.ndarray
    y_mean: np.ndarray
    y_scale: np.ndarray
    y_standardized: np.ndarray
    lengthscale: float
    nugget: float
    mean_coefficients: np.ndarray
    alpha: np.ndarray
    K_inv_F: np.ndarray
    F: np.ndarray
    cholesky: tuple
    jitter: float
    criterion: str
    objective: float


def squared_exponential(x1: np.ndarray, x2: np.ndarray, lengthscale: float) -> np.ndarray:
    x1 = np.atleast_2d(x1).astype(float)
    x2 = np.atleast_2d(x2).astype(float)
    sqdist = np.sum((x1[:, None, :] - x2[None, :, :]) ** 2, axis=2)
    return np.exp(-0.5 * sqdist / max(lengthscale**2, 1e-16))


def _basis(x: np.ndarray, degree: int) -> np.ndarray:
    x = np.atleast_2d(x)
    if degree == 0:
        return np.ones((x.shape[0], 1))
    if x.shape[1] != 1:
        # For GP-SSM, a constant trend is the stable default.
        return np.ones((x.shape[0], 1))
    cols = [np.ones(x.shape[0])]
    for p in range(1, degree + 1):
        cols.append(x[:, 0] ** p)
    return np.column_stack(cols)


def _fit_given_params(x: np.ndarray, y: np.ndarray, lengthscale: float, nugget: float, mean_degree: int):
    R = squared_exponential(x, x, lengthscale)
    K = R + max(nugget, 1e-12) * np.eye(x.shape[0])
    chol, jitter = stable_cholesky(K, initial_jitter=1e-12)
    from scipy.linalg import cho_solve

    F = _basis(x, mean_degree)
    K_inv_y = cho_solve(chol, y, check_finite=False)
    K_inv_F = cho_solve(chol, F, check_finite=False)
    information = F.T @ K_inv_F
    beta = np.linalg.pinv(information, rcond=1e-12) @ (F.T @ K_inv_y)
    residual = y - F @ beta
    alpha = cho_solve(chol, residual, check_finite=False)
    return K, chol, jitter, F, K_inv_F, beta, residual, alpha


def _profile_nll(x: np.ndarray, y: np.ndarray, lengthscale: float, nugget: float, mean_degree: int) -> float:
    try:
        K, chol, _, _, _, _, residual, alpha = _fit_given_params(x, y, lengthscale, nugget, mean_degree)
        logdet = 2.0 * np.sum(np.log(np.diag(chol[0])))
        n = x.shape[0]
        objective = 0.0
        for j in range(y.shape[1]):
            sigma2 = max(float(residual[:, j] @ alpha[:, j]) / n, 1e-14)
            objective += n * np.log(sigma2) + logdet
        return float(objective)
    except Exception:
        return 1e100


def _loo_mse(x: np.ndarray, y: np.ndarray, lengthscale: float, nugget: float, mean_degree: int) -> float:
    n = x.shape[0]
    errors = []
    try:
        for i in range(n):
            keep = np.ones(n, dtype=bool)
            keep[i] = False
            _, chol, _, F, _, beta, _, alpha = _fit_given_params(
                x[keep], y[keep], lengthscale, nugget, mean_degree
            )
            k = squared_exponential(x[keep], x[i : i + 1], lengthscale).reshape(-1)
            f = _basis(x[i : i + 1], mean_degree).reshape(-1)
            pred = f @ beta + k @ alpha
            errors.append(pred - y[i])
        err = np.asarray(errors)
        return float(np.mean(err**2))
    except Exception:
        return 1e100


def fit_gp(
    x: np.ndarray,
    y: np.ndarray,
    criterion: str = "loocv",
    mean_degree: int = 0,
    seed: int = 20260827,
    n_starts: int = 4,
) -> GPState:
    x = np.asarray(x, dtype=float)
    if x.ndim == 1:
        x = x[:, None]
    y = np.asarray(y, dtype=float)
    if y.ndim == 1:
        y = y[:, None]
    y_mean = np.mean(y, axis=0)
    y_scale = np.std(y, axis=0)
    y_scale = np.where(y_scale < 1e-12, 1.0, y_scale)
    yz = (y - y_mean) / y_scale

    if x.shape[1] == 1:
        xmin = np.min(x[:, 0])
        span = max(float(np.max(x[:, 0]) - xmin), 1e-12)
        xn = ((x[:, 0] - xmin) / span)[:, None]
    else:
        xmin = np.min(x, axis=0)
        span = np.max(x, axis=0) - xmin
        span = np.where(span < 1e-12, 1.0, span)
        xn = (x - xmin) / span

    bounds = [(np.log(0.02), np.log(20.0)), (np.log(1e-10), np.log(0.5))]
    objective_function = _loo_mse if criterion.lower() == "loocv" else _profile_nll

    def objective(z: np.ndarray) -> float:
        return objective_function(xn, yz, float(np.exp(z[0])), float(np.exp(z[1])), mean_degree)

    if criterion.lower() == "loocv":
        # The legacy manuscript selected LOOCV hyperparameters from a discrete set.
        # A deterministic log grid is both faithful to that prediction-oriented
        # procedure and, unlike repeated unconstrained line searches, has a hard
        # runtime bound for the 60-level turbine trajectory.
        length_grid = np.geomspace(0.025, 16.0, 10)
        nugget_grid = np.array([1e-10, 1e-8, 1e-6, 1e-4, 1e-3, 1e-2, 0.1, 0.35])
        best_value = float("inf")
        best_x = None
        for lengthscale_value in length_grid:
            for nugget_value in nugget_grid:
                value = objective(np.log([lengthscale_value, nugget_value]))
                if value < best_value:
                    best_value = float(value)
                    best_x = np.log([lengthscale_value, nugget_value])
        assert best_x is not None
        class _GridResult:
            x = best_x
            fun = best_value
            success = True
        best = _GridResult()
    else:
        # Profile MLE is the reviewer-requested continuous sensitivity analysis.
        # It is optimized with deterministic multi-start L-BFGS-B.
        best = None
        for start in deterministic_starts(bounds, n_random=max(1, n_starts - 3), seed=seed):
            candidate = minimize(
                objective,
                start,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 80, "maxfun": 180, "ftol": 1e-9},
            )
            if best is None or candidate.fun < best.fun:
                best = candidate
        assert best is not None
        if not bool(best.success):
            # L-BFGS-B can report an abnormal line-search termination at a stable
            # boundary optimum.  A bounded SLSQP refinement provides an independent
            # convergence check while preserving the continuous profile-MLE objective.
            fallback = minimize(
                objective,
                best.x,
                method="SLSQP",
                bounds=bounds,
                options={"maxiter": 100, "ftol": 1e-9},
            )
            if bool(fallback.success) or fallback.fun <= best.fun + 1e-9:
                best = fallback
    lengthscale, nugget = np.exp(best.x)
    K, chol, jitter, F, K_inv_F, beta, residual, alpha = _fit_given_params(
        xn, yz, float(lengthscale), float(nugget), mean_degree
    )
    state = GPState(
        x_train=xn,
        y_mean=y_mean,
        y_scale=y_scale,
        y_standardized=yz,
        lengthscale=float(lengthscale),
        nugget=float(nugget),
        mean_coefficients=beta,
        alpha=alpha,
        K_inv_F=K_inv_F,
        F=F,
        cholesky=chol,
        jitter=float(jitter),
        criterion=criterion,
        objective=float(best.fun),
    )
    state._input_min = xmin  # type: ignore[attr-defined]
    state._input_span = span  # type: ignore[attr-defined]
    state._mean_degree = mean_degree  # type: ignore[attr-defined]
    state._optimizer_success = bool(best.success)  # type: ignore[attr-defined]
    return state


def predict_gp(state: GPState, x_new: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_new = np.asarray(x_new, dtype=float)
    if x_new.ndim == 1:
        if state.x_train.shape[1] == 1:
            x_new = x_new[:, None]
        else:
            x_new = x_new[None, :]
    xmin = state._input_min  # type: ignore[attr-defined]
    span = state._input_span  # type: ignore[attr-defined]
    xn = (x_new - xmin) / span
    k = squared_exponential(state.x_train, xn, state.lengthscale)
    F_new = _basis(xn, state._mean_degree)  # type: ignore[attr-defined]
    mean_z = F_new @ state.mean_coefficients + k.T @ state.alpha

    from scipy.linalg import cho_solve

    v = cho_solve(state.cholesky, k, check_finite=False)
    base_var = np.maximum(1.0 - np.sum(k * v, axis=0), 0.0)
    # Universal-kriging trend-estimation correction.
    information_inv = np.linalg.pinv(state.F.T @ state.K_inv_F, rcond=1e-12)
    u = F_new.T - state.F.T @ v
    correction = np.einsum("ij,jk,ki->i", u.T, information_inv, u)
    variance_factor = np.maximum(base_var + correction, 0.0)
    mean = mean_z * state.y_scale + state.y_mean
    variance = variance_factor[:, None] * state.y_scale[None, :] ** 2
    return mean, variance
