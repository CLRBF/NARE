from __future__ import annotations

import numpy as np

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset
from .gp_common import fit_gp, predict_gp


class StationaryGP(TrajectoryModel):
    name = "Stationary GP"

    def __init__(self, criterion: str = "loocv", seed: int = 20260827):
        if criterion not in {"loocv", "mle"}:
            raise ValueError("criterion must be 'loocv' or 'mle'")
        self.criterion = criterion
        self.seed = seed
        if criterion == "mle":
            self.name = "Stationary GP (profile MLE)"
        else:
            self.name = "Stationary GP (LOOCV)"

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        state = fit_gp(dataset.h_train, dataset.y_train, criterion=self.criterion, mean_degree=0, seed=self.seed)
        path, path_var = predict_gp(state, dataset.h_train)
        target, target_var = predict_gp(state, np.array([dataset.target_h]))
        return FitResult(
            method=self.name,
            target_prediction=target[0],
            path_prediction=path,
            hyperparameters={
                "lengthscale_scaled": state.lengthscale,
                "nugget_ratio": state.nugget,
                "criterion": self.criterion,
            },
            diagnostics={
                "objective": state.objective,
                "jitter": state.jitter,
                "target_sd": np.sqrt(target_var[0]),
                "optimizer_success": bool(state._optimizer_success),  # type: ignore[attr-defined]
            },
        )


class UniversalGP(TrajectoryModel):
    name = "Nonstationary GP (quadratic mean)"

    def __init__(self, criterion: str = "loocv", seed: int = 20260827):
        self.criterion = criterion
        self.seed = seed

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        degree = 2 if dataset.n_levels >= 5 else 1
        state = fit_gp(dataset.h_train, dataset.y_train, criterion=self.criterion, mean_degree=degree, seed=self.seed)
        path, _ = predict_gp(state, dataset.h_train)
        target, target_var = predict_gp(state, np.array([dataset.target_h]))
        return FitResult(
            method=self.name,
            target_prediction=target[0],
            path_prediction=path,
            hyperparameters={
                "lengthscale_scaled": state.lengthscale,
                "nugget_ratio": state.nugget,
                "mean_degree": degree,
                "criterion": self.criterion,
            },
            diagnostics={
                "objective": state.objective,
                "target_sd": np.sqrt(target_var[0]),
                "optimizer_success": bool(state._optimizer_success),  # type: ignore[attr-defined]
            },
        )


class GPStateSpace(TrajectoryModel):
    name = "GP-SSM"

    def __init__(self, criterion: str = "mle", seed: int = 20260827):
        self.criterion = criterion
        self.seed = seed

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        h_desc, y_desc = self._coarse_to_fine(dataset)
        x_transition = y_desc[:-1]
        y_transition = y_desc[1:]
        if x_transition.shape[0] < 3:
            raise ValueError("GP-SSM requires at least four fidelity levels")
        state = fit_gp(x_transition, y_transition, criterion=self.criterion, mean_degree=0, seed=self.seed)
        one_step, _ = predict_gp(state, x_transition)
        target, target_var = predict_gp(state, y_desc[-1:])
        # Map coarse-to-fine one-step predictions back to the dataset's ascending order.
        path_desc = np.vstack([y_desc[0], one_step])
        order_desc = np.argsort(dataset.h_train)[::-1]
        path = np.empty_like(dataset.y_train)
        path[order_desc] = path_desc
        return FitResult(
            method=self.name,
            target_prediction=target[0],
            path_prediction=path,
            hyperparameters={
                "lengthscale_scaled": state.lengthscale,
                "nugget_ratio": state.nugget,
                "criterion": self.criterion,
            },
            diagnostics={
                "objective": state.objective,
                "target_sd": np.sqrt(target_var[0]),
                "optimizer_success": bool(state._optimizer_success),  # type: ignore[attr-defined]
            },
        )
