from __future__ import annotations

import numpy as np
from scipy.optimize import minimize, minimize_scalar

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset
from ..numerics import deterministic_starts


def _simple_coefficients(h_desc: np.ndarray, y_desc: np.ndarray, beta: float) -> tuple[np.ndarray, float]:
    dy = np.diff(y_desc, axis=0)
    z = np.diff(h_desc**beta)[:, None]
    denom = float(np.sum(z[:, 0] ** 2))
    if denom < 1e-18:
        return np.zeros(y_desc.shape[1]), float("inf")
    alpha = np.sum(z * dy, axis=0) / denom
    residual = dy - z * alpha[None, :]
    return alpha, float(np.sum(residual**2))


class NARESimple(TrajectoryModel):
    """One-term NARE-MF fitted on adjacent increments.

    The fitted curve is anchored at the finest *training* level.  The held-out
    target is never used in parameter estimation or model selection.
    """

    name = "NARE-MF (simple)"

    def __init__(self, beta_bounds: tuple[float, float] = (0.05, 12.0)) -> None:
        self.beta_bounds = beta_bounds

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        h_desc, y_desc = self._coarse_to_fine(dataset)
        objective = lambda beta: _simple_coefficients(h_desc, y_desc, float(beta))[1]
        opt = minimize_scalar(objective, bounds=self.beta_bounds, method="bounded", options={"xatol": 1e-9})
        beta = float(opt.x)
        alpha, sse = _simple_coefficients(h_desc, y_desc, beta)
        fine_idx = int(np.argmin(dataset.h_train))
        h_anchor = float(dataset.h_train[fine_idx])
        y_anchor = dataset.y_train[fine_idx]

        def predict(h: np.ndarray | float) -> np.ndarray:
            hv = np.asarray(h, dtype=float).reshape(-1, 1)
            return y_anchor[None, :] + (hv**beta - h_anchor**beta) * alpha[None, :]

        path = predict(dataset.h_train)
        target = predict(dataset.target_h)[0]
        return FitResult(
            method=self.name,
            target_prediction=target,
            path_prediction=path,
            hyperparameters={"alpha": alpha, "beta": beta, "anchor_h": h_anchor},
            diagnostics={"increment_sse": sse, "optimizer_success": bool(opt.success)},
        )


class NAREComplex(TrajectoryModel):
    """Two-term NARE-MF with shared ordered powers across output components."""

    name = "NARE-MF (complex)"

    def __init__(
        self,
        beta_bounds: tuple[float, float] = (0.05, 10.0),
        delta_bounds: tuple[float, float] = (0.05, 10.0),
        seed: int = 20260827,
    ) -> None:
        self.beta_bounds = beta_bounds
        self.delta_bounds = delta_bounds
        self.seed = seed

    @staticmethod
    def _coefficients(h_desc: np.ndarray, y_desc: np.ndarray, beta: float, delta: float):
        dy = np.diff(y_desc, axis=0)
        z1 = np.diff(h_desc**beta)
        z2 = np.diff(h_desc ** (beta + delta))
        design = np.column_stack([z1, z2])
        coeff, *_ = np.linalg.lstsq(design, dy, rcond=None)
        residual = dy - design @ coeff
        # Mild penalty prevents nearly identical powers from becoming numerically singular.
        condition = float(np.linalg.cond(design)) if design.shape[0] >= 2 else float("inf")
        penalty = 1e-12 * min(condition, 1e12)
        return coeff, float(np.sum(residual**2) + penalty), condition

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        if dataset.n_levels < 5:
            raise ValueError("complex NARE-MF requires at least five training levels")
        h_desc, y_desc = self._coarse_to_fine(dataset)
        bounds = [self.beta_bounds, self.delta_bounds]

        def objective(x: np.ndarray) -> float:
            return self._coefficients(h_desc, y_desc, float(x[0]), float(x[1]))[1]

        best = None
        for start in deterministic_starts(bounds, n_random=5, seed=self.seed):
            candidate = minimize(objective, start, method="L-BFGS-B", bounds=bounds)
            if best is None or candidate.fun < best.fun:
                best = candidate
        assert best is not None
        beta, delta = map(float, best.x)
        coeff, sse, condition = self._coefficients(h_desc, y_desc, beta, delta)
        alpha = coeff[0]
        gamma = coeff[1]
        fine_idx = int(np.argmin(dataset.h_train))
        h_anchor = float(dataset.h_train[fine_idx])
        y_anchor = dataset.y_train[fine_idx]

        def predict(h: np.ndarray | float) -> np.ndarray:
            hv = np.asarray(h, dtype=float).reshape(-1, 1)
            return (
                y_anchor[None, :]
                + (hv**beta - h_anchor**beta) * alpha[None, :]
                + (hv ** (beta + delta) - h_anchor ** (beta + delta)) * gamma[None, :]
            )

        path = predict(dataset.h_train)
        target = predict(dataset.target_h)[0]
        return FitResult(
            method=self.name,
            target_prediction=target,
            path_prediction=path,
            hyperparameters={
                "alpha": alpha,
                "beta": beta,
                "gamma": gamma,
                "delta": delta,
                "second_power": beta + delta,
                "anchor_h": h_anchor,
            },
            diagnostics={
                "increment_sse": sse,
                "design_condition": condition,
                "optimizer_success": bool(best.success),
            },
        )
