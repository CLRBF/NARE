from __future__ import annotations

import numpy as np
from scipy.optimize import minimize
from scipy.linalg import cho_solve

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset
from ..numerics import deterministic_starts, stable_cholesky


def _rq_correlation(x1: np.ndarray, x2: np.ndarray, lengthscale: float) -> np.ndarray:
    x1 = np.asarray(x1, dtype=float).reshape(-1)
    x2 = np.asarray(x2, dtype=float).reshape(-1)
    distance2 = (x1[:, None] - x2[None, :]) ** 2
    return 1.0 / (1.0 + distance2 / max(lengthscale**2, 1e-16))


def _positive_c(R: np.ndarray) -> tuple[np.ndarray, float, float]:
    """Joseph's Eq. (12): smallest gamma giving a positive lower bound."""
    n = R.shape[0]
    eigvals = np.linalg.eigvalsh(R)
    lambda1 = float(np.max(eigvals))
    delta = lambda1 / n
    one = np.ones(n)

    def c_at(gamma: float) -> np.ndarray:
        A = (1.0 - gamma) * R + gamma * np.eye(n)
        return np.linalg.solve(A, one)

    # A deterministic dense search is robust even if componentwise monotonicity
    # in gamma is imperfect because of floating-point error.
    grid = np.linspace(0.0, 1.0, 25)
    feasible_index = None
    for idx, gamma in enumerate(grid):
        c = c_at(float(gamma))
        if np.all(c >= delta - 1e-10):
            feasible_index = idx
            break
    if feasible_index is None:
        gamma = 1.0
        c = one
    elif feasible_index == 0:
        gamma = 0.0
        c = c_at(gamma)
    else:
        lo = float(grid[feasible_index - 1])
        hi = float(grid[feasible_index])
        for _ in range(24):
            mid = 0.5 * (lo + hi)
            c_mid = c_at(mid)
            if np.all(c_mid >= delta - 1e-10):
                hi = mid
            else:
                lo = mid
        gamma = hi
        c = c_at(gamma)
    return np.maximum(c, 1e-14), float(gamma), float(delta)


class RationalKriging(TrajectoryModel):
    """Joseph's rational predictor with continuous profile estimation.

    The implementation follows Eqs. (8), (9), (12)--(14) in Joseph's
    Rational Kriging paper.  A nugget is optimized jointly with the correlation
    length scale to accommodate noisy calibration trajectories.
    """

    name = "Rational Kriging"

    def __init__(self, seed: int = 20260827):
        self.seed = seed

    @staticmethod
    def _state(x: np.ndarray, yz: np.ndarray, lengthscale: float, nugget: float):
        R_base = _rq_correlation(x, x, lengthscale)
        R = R_base + nugget * np.eye(x.size)
        chol, jitter = stable_cholesky(R, initial_jitter=1e-13)
        c, gamma, delta = _positive_c(R)
        q = R @ c
        q = np.maximum(q, 1e-14)
        Dq = q[:, None]
        Rinv_Dq_y = cho_solve(chol, Dq * yz, check_finite=False)
        Rinv_q = cho_solve(chol, q, check_finite=False)
        # GLS mean from Eq. (9), with q proportional to 1/tau.
        numerator = np.sum(q[:, None] * Rinv_Dq_y, axis=0)
        denominator = max(float(q @ Rinv_q), 1e-15)
        mu = numerator / denominator
        residual = yz - mu[None, :]
        weighted = q[:, None] * residual
        Rinv_weighted = cho_solve(chol, weighted, check_finite=False)
        nu2 = np.sum(weighted * Rinv_weighted, axis=0) / max(x.size - 1, 1)
        nu2 = np.maximum(nu2, 1e-15)
        logdet = float(2.0 * np.sum(np.log(np.diag(chol[0]))))
        cRc = max(float(c @ (R @ c)), 1e-15)
        profile = float(
            np.sum((x.size - 1) * np.log(nu2))
            + yz.shape[1] * (logdet - 2.0 * np.sum(np.log(q)) + np.log(cRc))
        )
        return R, chol, jitter, c, q, gamma, delta, mu, residual, nu2, profile

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        h = dataset.h_train
        xmin = float(np.min(h))
        span = max(float(np.max(h) - xmin), 1e-12)
        x = (h - xmin) / span
        target_x = (dataset.target_h - xmin) / span
        y = dataset.y_train
        y_mean = np.mean(y, axis=0)
        y_scale = np.std(y, axis=0)
        y_scale = np.where(y_scale < 1e-12, 1.0, y_scale)
        yz = (y - y_mean) / y_scale
        bounds = [(np.log(0.015), np.log(30.0)), (np.log(1e-12), np.log(0.35))]

        def objective(z: np.ndarray) -> float:
            lengthscale, nugget = np.exp(z)
            try:
                return self._state(x, yz, float(lengthscale), float(nugget))[-1]
            except Exception:
                return 1e100

        # Hard-bounded deterministic optimization. A coarse profile grid prevents
        # pathological line-search behavior on short or nearly collinear trajectories;
        # SLSQP then estimates both positive parameters continuously from the best cell.
        length_grid = np.geomspace(0.02, 20.0, 11)
        nugget_grid = np.array([1e-12, 1e-9, 1e-7, 1e-5, 1e-3, 0.02, 0.15, 0.35])
        best_z = None
        best_value = float("inf")
        for length_value in length_grid:
            for nugget_value in nugget_grid:
                z = np.log([length_value, nugget_value])
                value = objective(z)
                if value < best_value:
                    best_value = float(value)
                    best_z = z
        assert best_z is not None
        refined = minimize(
            objective,
            best_z,
            method="SLSQP",
            bounds=bounds,
            options={"maxiter": 90, "ftol": 1e-8},
        )
        if np.isfinite(refined.fun) and refined.fun <= best_value:
            best = refined
        else:
            class _GridResult:
                x = best_z
                fun = best_value
                success = True
            best = _GridResult()
        lengthscale, nugget = map(float, np.exp(best.x))
        R, chol, jitter, c, q, gamma, delta, mu, residual, nu2, profile = self._state(
            x, yz, lengthscale, nugget
        )
        weighted_residual = q[:, None] * residual
        Rinv_weighted = cho_solve(chol, weighted_residual, check_finite=False)

        def predict(xnew: np.ndarray | float):
            xv = np.asarray(xnew, dtype=float).reshape(-1)
            r = _rq_correlation(x, xv, lengthscale)
            denominator = r.T @ c
            denominator = np.where(np.abs(denominator) < 1e-14, np.sign(denominator) * 1e-14 + 1e-14, denominator)
            correction = (r.T @ Rinv_weighted) / denominator[:, None]
            mean_z = mu[None, :] + correction
            Rinv_r = cho_solve(chol, r, check_finite=False)
            kriging_var = np.maximum(1.0 - np.sum(r * Rinv_r, axis=0), 0.0)
            scale_factor = (1.0 / denominator**2)[:, None]
            variance_z = scale_factor * kriging_var[:, None] * nu2[None, :]
            return mean_z * y_scale + y_mean, variance_z * y_scale[None, :] ** 2

        path, _ = predict(x)
        target, target_var = predict(target_x)
        return FitResult(
            method=self.name,
            target_prediction=target[0],
            path_prediction=path,
            hyperparameters={
                "lengthscale_scaled": lengthscale,
                "nugget_ratio": nugget,
                "gamma": gamma,
                "delta_lower_bound": delta,
            },
            diagnostics={
                "profile_objective": profile,
                "jitter": jitter,
                "target_sd": np.sqrt(target_var[0]),
                "optimizer_success": bool(best.success),
                "min_c": float(np.min(c)),
                "min_Rc": float(np.min(q)),
            },
        )
