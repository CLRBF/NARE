from __future__ import annotations

import numpy as np
from scipy.optimize import minimize
from scipy.linalg import cho_solve

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset
from ..numerics import deterministic_starts, stable_cholesky


def _error_kernel(h1: np.ndarray, h2: np.ndarray, order: float, lengthscale: float) -> np.ndarray:
    h1 = np.asarray(h1, dtype=float).reshape(-1)
    h2 = np.asarray(h2, dtype=float).reshape(-1)
    b1 = np.maximum(h1, 0.0) ** order
    b2 = np.maximum(h2, 0.0) ** order
    distance = h1[:, None] - h2[None, :]
    ke = np.exp(-0.5 * (distance / max(lengthscale, 1e-14)) ** 2)
    return b1[:, None] * b2[None, :] * ke


class GaussRichardson(TrajectoryModel):
    """Probabilistic Richardson / Gauss-Richardson Extrapolation (GRE).

    This implements the objective-prior form in Oates et al. using
        K_b(i,j)=h_i^r h_j^r k_e(h_i,h_j),
    with r and the Gaussian error-kernel length scale estimated by maximum
    quasi-likelihood.  A small estimated nugget is included because the inputs
    here are themselves calibrated estimates rather than exact deterministic
    solver outputs.
    """

    name = "Probabilistic Richardson (GRE)"

    def __init__(self, seed: int = 20260827):
        self.seed = seed

    @staticmethod
    def _fit_given(h: np.ndarray, yz: np.ndarray, order: float, lengthscale: float, nugget: float):
        K = _error_kernel(h, h, order, lengthscale) + nugget * np.eye(h.size)
        chol, jitter = stable_cholesky(K, initial_jitter=1e-13)
        one = np.ones(h.size)
        Kinv_one = cho_solve(chol, one, check_finite=False)
        Kinv_y = cho_solve(chol, yz, check_finite=False)
        denom = max(float(one @ Kinv_one), 1e-15)
        mu = (one @ Kinv_y) / denom
        residual = yz - one[:, None] * mu[None, :]
        alpha = cho_solve(chol, residual, check_finite=False)
        logdet = float(2.0 * np.sum(np.log(np.diag(chol[0]))))
        quasi = float(np.sum(residual * alpha) + yz.shape[1] * logdet)
        return K, chol, jitter, mu, alpha, quasi

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        h = dataset.h_train
        y = dataset.y_train
        y_mean = np.mean(y, axis=0)
        y_scale = np.std(y, axis=0)
        y_scale = np.where(y_scale < 1e-12, 1.0, y_scale)
        yz = (y - y_mean) / y_scale
        span = max(float(np.max(h) - np.min(h)), float(np.max(h)), 1e-6)
        bounds = [
            (np.log(0.05), np.log(12.0)),
            (np.log(span * 0.02), np.log(span * 20.0)),
            (np.log(1e-12), np.log(0.2)),
        ]

        def objective(z: np.ndarray) -> float:
            order, lengthscale, nugget = np.exp(z)
            try:
                return self._fit_given(h, yz, float(order), float(lengthscale), float(nugget))[5]
            except Exception:
                return 1e100

        order_grid = np.array([0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0])
        length_grid = span * np.array([0.03, 0.1, 0.3, 1.0, 3.0, 10.0])
        nugget_grid = np.array([1e-12, 1e-8, 1e-5, 1e-3, 0.02, 0.15])
        best_z = None
        best_value = float("inf")
        for order_value in order_grid:
            for length_value in length_grid:
                for nugget_value in nugget_grid:
                    z = np.log([order_value, length_value, nugget_value])
                    value = objective(z)
                    if value < best_value:
                        best_value = float(value)
                        best_z = z
        assert best_z is not None
        refined = minimize(
            objective,
            best_z,
            method="SLSQP",
            bounds=bounds,
            options={"maxiter": 100, "ftol": 1e-8},
        )
        if np.isfinite(refined.fun) and refined.fun <= best_value:
            best = refined
        else:
            class _GridResult:
                x = best_z
                fun = best_value
                success = True
            best = _GridResult()
        order, lengthscale, nugget = map(float, np.exp(best.x))
        _, chol, jitter, mu, alpha, quasi = self._fit_given(h, yz, order, lengthscale, nugget)

        def predict(h_new: np.ndarray | float):
            hv = np.asarray(h_new, dtype=float).reshape(-1)
            kb = _error_kernel(h, hv, order, lengthscale)
            mean_z = mu[None, :] + kb.T @ alpha
            v = cho_solve(chol, kb, check_finite=False)
            kdiag = np.maximum(hv, 0.0) ** (2 * order)
            variance_factor = np.maximum(kdiag - np.sum(kb * v, axis=0), 0.0)
            mean = mean_z * y_scale + y_mean
            variance = variance_factor[:, None] * y_scale[None, :] ** 2
            return mean, variance

        path, _ = predict(dataset.h_train)
        target, target_var = predict(dataset.target_h)
        return FitResult(
            method=self.name,
            target_prediction=target[0],
            path_prediction=path,
            hyperparameters={
                "convergence_order": order,
                "error_kernel_lengthscale": lengthscale,
                "nugget_ratio": nugget,
            },
            diagnostics={
                "quasi_likelihood_objective": quasi,
                "jitter": jitter,
                "target_sd": np.sqrt(target_var[0]),
                "optimizer_success": bool(best.success),
            },
        )
