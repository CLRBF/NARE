from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset


class GeneralizedRichardson(TrajectoryModel):
    """Global one-term generalized Richardson fit: y(h)=theta_0+a h^beta."""

    name = "Generalized Richardson"

    def __init__(self, beta_bounds: tuple[float, float] = (0.05, 12.0)) -> None:
        self.beta_bounds = beta_bounds

    @staticmethod
    def _profile(h: np.ndarray, y: np.ndarray, beta: float):
        design = np.column_stack([np.ones_like(h), h**beta])
        coeff, *_ = np.linalg.lstsq(design, y, rcond=None)
        residual = y - design @ coeff
        return coeff, float(np.sum(residual**2)), float(np.linalg.cond(design))

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        objective = lambda beta: self._profile(dataset.h_train, dataset.y_train, float(beta))[1]
        opt = minimize_scalar(objective, bounds=self.beta_bounds, method="bounded", options={"xatol": 1e-9})
        beta = float(opt.x)
        coeff, sse, condition = self._profile(dataset.h_train, dataset.y_train, beta)
        theta0, alpha = coeff[0], coeff[1]
        path = theta0[None, :] + dataset.h_train[:, None] ** beta * alpha[None, :]
        target = theta0 + dataset.target_h**beta * alpha
        return FitResult(
            method=self.name,
            target_prediction=target,
            path_prediction=path,
            hyperparameters={"theta0": theta0, "alpha": alpha, "beta": beta},
            diagnostics={
                "sse": sse,
                "design_condition": condition,
                "optimizer_success": bool(opt.success),
            },
        )
