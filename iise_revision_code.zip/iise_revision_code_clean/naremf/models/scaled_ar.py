from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar

from ..base import TrajectoryModel
from ..types import FitResult, TrajectoryDataset


def _geometric_sum(phi: float, k: np.ndarray) -> np.ndarray:
    if abs(phi - 1.0) < 1e-7:
        return k
    return (1.0 - phi**k) / (1.0 - phi)


class ScaledAR(TrajectoryModel):
    name = "Scaled AR"

    def __init__(self, phi_bounds: tuple[float, float] = (1e-4, 1.5)):
        self.phi_bounds = phi_bounds

    def fit_predict(self, dataset: TrajectoryDataset) -> FitResult:
        h_desc, y_desc = self._coarse_to_fine(dataset)
        steps = h_desc[:-1] - h_desc[1:]
        base_step = max(float(np.min(steps[steps > 1e-12])), 1e-12)
        k = steps / base_step
        x = y_desc[:-1]
        target_y = y_desc[1:]

        def profile(phi: float):
            phi_k = phi**k
            g = _geometric_sum(phi, k)
            residual_without_c = target_y - phi_k[:, None] * x
            denom = max(float(np.sum(g**2)), 1e-16)
            c = np.sum(g[:, None] * residual_without_c, axis=0) / denom
            residual = residual_without_c - g[:, None] * c[None, :]
            return c, float(np.sum(residual**2))

        opt = minimize_scalar(lambda phi: profile(float(phi))[1], bounds=self.phi_bounds, method="bounded")
        phi = float(opt.x)
        c, sse = profile(phi)
        one_step = phi**k[:, None] * x + _geometric_sum(phi, k)[:, None] * c[None, :]
        path_desc = np.vstack([y_desc[0], one_step])
        order_desc = np.argsort(dataset.h_train)[::-1]
        path = np.empty_like(dataset.y_train)
        path[order_desc] = path_desc
        k_target = max((float(np.min(dataset.h_train)) - dataset.target_h) / base_step, 0.0)
        target = phi**k_target * y_desc[-1] + _geometric_sum(phi, np.array([k_target]))[0] * c
        return FitResult(
            method=self.name,
            target_prediction=target,
            path_prediction=path,
            hyperparameters={"phi": phi, "c": c, "base_step": base_step},
            diagnostics={"increment_sse": sse, "optimizer_success": bool(opt.success)},
        )
