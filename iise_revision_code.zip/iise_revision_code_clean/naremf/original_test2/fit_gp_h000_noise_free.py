"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def stationary(sigma, l, t1, t2):
    return sigma ** 2 * torch.exp(-(t1 - t2) ** 2 / (2 * l ** 2))

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_next_theta(check, theta_hat, h):
    train_xt = torch.tensor(h)
    KXX_new = np.array([[stationary(sigma, l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def compute_next_theta_v2(check, theta_hat, h):
    train_xt = torch.tensor(theta_hat)
    KXX_new = np.array([[stationary(sigma, l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[1:check + 1]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def process_data(data_dict, index, noise_free_true):
    h_1 = data_dict['h_set'].flatten()[index]
    a_1 = data_dict['a_optimal_set'].flatten()[index]
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flip(X_true)
    h_true = np.flip(h_true)
    X_true = np.append(X_true, noise_free_true)
    X_true = np.flip(X_true)
    h_true = np.append(h_true, 0)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    index_non_AR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    h_true = h_true[1:][index_non_AR]
    X_true = X_true[1:][index_non_AR]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    X_true_index = np.append(X_true, X_true_original[-1])
    h_true_index = np.append(h_true, h_true_original[-1])
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, list(X_true_original), list(h_true_original))

def train_and_predict(t_scaled, x_scaled):
    h = torch.tensor(t_scaled)
    theta_hat = torch.tensor(x_scaled)
    if noise == 0:
        h = torch.cat((h, torch.tensor([0])))
        theta_hat = torch.cat((theta_hat, torch.tensor([noise_free_true])))
    theta_new = []
    if version == 1:
        if noise == 1:
            h = torch.cat((h, torch.tensor([0])))
        for check in range(1, len(h)):
            next_theta = compute_next_theta(check, theta_hat, h)
            theta_new.append(next_theta)
    else:
        if noise == 1:
            h = torch.cat((h, torch.tensor([0])))
        for check in range(1, len(h) - 1):
            next_theta = compute_next_theta_v2(check, theta_hat, h)
            theta_new.append(next_theta)
    return theta_new

def process_and_evaluate(data_noise_free, noise_free_true, index):
    x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, X_true_original, h_true_original = process_data(data_noise_free, index, noise_free_true)
    theta_new = train_and_predict(t_scaled, x_scaled)
    predicted_x = theta_new
    params_init = np.array([sigma, alpha, l])
    t_NEW = np.append(t_scaled[1:], np.array([0]))
    X_true_original_new = np.array(X_true_original)[1:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-1]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_0': predicted_x[-1], 'X_true_original': np.array(X_true_original), 'sigma': sigma, 'seed': seed, 'alpha': alpha, 'params_init': params_init, 'l': l, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = f'data/GP/GP_data_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
    if version == 1:
        pass
    figure_name = f'figures/GP/GP_figure_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
    return LOOCV_MSE_all
