"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def covariance_Brownian(sigma, t1, t2):
    return sigma ** 2 * torch.min(t1, t2)

def stationary(sigma, t1, t2):
    return sigma ** 2 * torch.exp(-(t1 - t2) ** 2)

def covariance_type2(sigma, l, t1, t2):
    return sigma * torch.sqrt(t1 * t2) * torch.exp(-torch.square(t1 - t2) / l)

def compute_next_theta(check, theta_hat, h):
    train_xt = torch.tensor(h)
    KXX_new = np.array([[covariance_Brownian(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_Brownian(sigma, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def compute_next_theta_2(check, theta_hat, h):
    train_xt = torch.tensor(h)
    KXX_new = np.array([[covariance_type2(sigma, l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([covariance_type2(sigma, l, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def compute_next_theta_3(check, theta_hat, h):
    train_xt = torch.tensor(h)
    KXX_new = np.array([[stationary(sigma, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += C * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def covariance(x1, x2, sigma, length_scale):
    return sigma ** 2 * np.exp(-(x1 - x2) ** 2 / (2 * length_scale ** 2))

def process_data(data_dict, index, noise_free_true):
    h_1 = data_dict['h_set'].flatten()[index]
    a_1 = data_dict['a_optimal_set'].flatten()[index]
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flip(X_true)
    h_true = np.flip(h_true)
    X_true = np.append(X_true, noise_free_true)
    X_true = np.flip(X_true)
    h_true = np.append(h_true, 0)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    index_non_AR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    h_true = h_true[1:][index_non_AR]
    X_true = X_true[1:][index_non_AR]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    X_true_index = np.append(X_true, X_true_original[-1])
    h_true_index = np.append(h_true, h_true_original[-1])
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, list(X_true_original), list(h_true_original))

def train_and_predict(t_scaled, x_scaled):
    h = torch.tensor(t_scaled)
    theta_hat = torch.tensor(x_scaled)
    h_all = torch.cat((h, torch.tensor([0])))
    theta_hat_all = torch.cat((theta_hat, torch.tensor([noise_free_true])))
    h_all = np.array(h_all)
    theta_hat_all = np.array(theta_hat_all)
    h = np.array(h)
    theta_hat = np.array(theta_hat)
    if noise == 1:
        theta_new = []
        for check in range(1, len(h)):
            next_theta = compute_next_theta(check, theta_hat, h)
            theta_new.append(next_theta)
        x_train = h
        f_train = theta_hat
        x_all = h_all
        f_all = theta_hat_all
        mu_original = theta_new
        x_train = h[:-1]
        f_train = theta_hat[:-1]
        x_train = x_train[1:]
        f_train = f_train[1:]
        f_train = f_train - np.array(mu_original)[:-1]
        x_all = x_all[1:]
        f_all = f_all[1:]
        f_all = f_all[:-1] - np.array(mu_original)
        F_train = np.vstack([np.ones_like(x_train), x_train]).T
        n_train = len(x_train)
        C = np.zeros((n_train, n_train))
        for i in range(n_train):
            for j in range(n_train):
                C[i, j] = covariance(x_train[i], x_train[j], sigma_kriging, length_scale)
        C = C + K * np.eye(n_train)
        C_inv = np.linalg.inv(C)
        beta_hat = np.linalg.inv(F_train.T @ C_inv @ F_train) @ F_train.T @ C_inv @ f_train

        def predict(x0):
            f0 = np.array([1, x0])
            c0 = np.array([covariance(x0, xi, sigma_kriging, length_scale) for xi in x_train])
            residual = f_train - F_train @ beta_hat
            return f0 @ beta_hat + c0 @ C_inv @ residual
        x_pred = x_all[:-1]
        y_pred = np.array([predict(x) for x in x_pred])
        predicted_x = y_pred + np.array(mu_original)
        true_x = f_all + np.array(mu_original)
        prediction_0 = predict(0) + 0
        predicted_x = np.append(predicted_x, prediction_0)
    return predicted_x

def process_and_evaluate(data_noise_free, noise_free_true, index, current_dir):
    x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, X_true_original, h_true_original = process_data(data_noise_free, index, noise_free_true)
    theta_new = train_and_predict(t_scaled, x_scaled)
    predicted_x = theta_new
    params_init = np.array([sigma_kriging, length_scale, K, sigma, l, C])
    t_NEW = t_scaled[1:]
    X_true_original_new = np.array(X_true_original)[1:-1]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-2]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-2])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_0': np.array(predicted_x[-1]), 'pred_h0': np.array(predicted_x[-1]), 'X_true_original': np.array(X_true_original), 'sigma': sigma, 'seed': seed, 'params_init': params_init, 'l': l, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = os.path.join(current_dir, f'data/nonGP/nonGP_data_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{std}.mat')
    figure_name = os.path.join(current_dir, f'figures/nonGP/nonGP_figure_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{std}.png')
    return {'LOOCV_MSE_all': LOOCV_MSE_all, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'pred_h0': np.array(predicted_x[-2]), 'predicted_x_0': np.array(predicted_x[-2])}
