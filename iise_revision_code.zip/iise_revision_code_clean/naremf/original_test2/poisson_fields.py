"""Original FEniCS 2019.1 Poisson solve used for Figure 5."""
from fenics import *
import numpy as np
import dolfin as df

def getSolutions(a, h,u_a, x_dense,y_dense):
    h = h
    mesh = UnitSquareMesh(int(1 / h), int(1 / h))
    V = FunctionSpace(mesh, 'P', 1)
    def boundary(x, on_boundary):
        return on_boundary
    bc = DirichletBC(V, Constant(0), boundary)
    # Define source term f
    #todo 5。15notes check下面的 degree和a有没有错。。
    f_expr = Expression(
        '(pow(a, 2) - 2*pow(pi, 2))*exp(a*x[0])*sin(pi*x[0])*sin(pi*x[1]) + 2*a*pi*exp(a*x[0])*cos(pi*x[0])*sin(pi*x[1])',
        degree=2, a=a)
    # Define variational problem
    u = TrialFunction(V)
    v = TestFunction(V)
    a_form = dot(grad(u), grad(v)) * df.dx
    L = -f_expr * v * df.dx
    u_h = Function(V)
    #todo check 这个对的吗
    solve(a_form == L, u_h, bc)

    xq_dense = x_dense.flatten()
    yq_dense = y_dense.flatten()

    vectorized_u_h = np.vectorize(u_h)
    u_interp_dense = vectorized_u_h(xq_dense, yq_dense)
    u_interp_2d = u_interp_dense.reshape(x_dense.shape)

    u_a = u_a
    # Compute relative L2 error
    diff = u_interp_2d - u_a
    relative_l2 = np.sqrt(np.sum(diff ** 2) / np.sum(u_a ** 2))
    return u_interp_2d, u_a, relative_l2, x_dense, y_dense
