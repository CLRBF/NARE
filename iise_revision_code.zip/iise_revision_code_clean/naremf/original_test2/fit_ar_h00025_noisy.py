"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def process_data(data_dict, index, noise_free_true):
    h_1 = data_dict['h_set'].flatten()[index]
    a_1 = data_dict['a_optimal_set'].flatten()[index]
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flip(X_true)
    h_true = np.flip(h_true)
    X_true = np.flip(X_true)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    h_true = h_true[1:]
    X_true = X_true[1:]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    X_true_index = np.append(X_true, X_true_original[-1])
    h_true_index = np.append(h_true, h_true_original[-1])
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, list(X_true_original), list(h_true_original))

def train_and_predict(x_i, y_i, k, x_scaled):
    seed_everything(seed=n)

    def objective(params, x_i, y_i, k):
        phi, c = params
        if abs(phi - 1) < 1e-08:
            pred = x_i + c * k
        else:
            pred = phi ** k * x_i + c * (1 - phi ** k) / (1 - phi)
        return y_i - pred

    def predict_objective(phi, c, x0, k_list):
        predictions = [x0]
        x_current = x0
        for k in k_list:
            if abs(phi - 1) < 1e-08:
                x_next = x_current + c * k
            else:
                x_next = phi ** k * x_current + c * (1 - phi ** k) / (1 - phi)
            predictions.append(x_next)
            x_current = x_next
        return np.array(predictions)
    params_init = np.round(np.random.uniform(low=0, high=5, size=2), 1)
    params_init = np.array([0.6, 0.6])
    bounds = ([-100, -100], [100, 100])
    result = least_squares(objective, params_init, args=(x_i, y_i, k), method='trf', bounds=bounds)
    phi_est, c_est = result.x
    x0 = x_scaled[0]
    k = np.append(k, 1)
    k = np.append(k, 2)
    predicted_series = predict_objective(phi_est, c_est, x0, k)
    pred_h0 = predicted_series[-1]
    return (result.x, predicted_series, params_init, pred_h0)

def process_and_evaluate(data_noise_free, noise_free_true, index, current_dir):
    x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, X_true_original, h_true_original = process_data(data_noise_free, index, noise_free_true)
    k = np.diff(t_scaled) / delta_t
    k = np.abs(k)
    optimal_params, predicted_x, params_init, pred_h0 = train_and_predict(x_i, y_i, k, x_scaled)
    predicted_x = predicted_x[1:-1]
    t_NEW = np.append(t_scaled[1:], h_true_original[-1])
    X_true_original_new = np.array(X_true_original)[1:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-1]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_0': predicted_x[-1], 'pred_h0': pred_h0, 'X_true_original': np.array(X_true_original), 'optimal_params': optimal_params, 'seed': seed, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = os.path.join(current_dir, f'data/AR/AR_data_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat')
    figure_name = os.path.join(current_dir, f'figures/AR/AR_figure_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png')
    return {'LOOCV_MSE_all': LOOCV_MSE_all, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'pred_h0': pred_h0, 'predicted_x_0': predicted_x[-1]}
