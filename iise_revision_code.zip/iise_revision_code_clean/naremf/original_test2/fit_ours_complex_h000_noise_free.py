"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def process_data(data_dict, index, noise_free_true):
    h_1 = data_dict['h_set'].flatten()[index]
    a_1 = data_dict['a_optimal_set'].flatten()[index]
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flip(X_true)
    h_true = np.flip(h_true)
    X_true = np.append(X_true, noise_free_true)
    X_true = np.flip(X_true)
    h_true = np.append(h_true, 0)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    index_non_AR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    h_true = h_true[1:][index_non_AR]
    X_true = X_true[1:][index_non_AR]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    X_true_index = np.append(X_true, X_true_original[-1])
    h_true_index = np.append(h_true, h_true_original[-1])
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, list(X_true_original), list(h_true_original))

def train_and_predict(x_i, y_i, h1, h2, n):
    seed_everything(seed=n)

    def objective(params, x_i, y_i, h1, h2):
        alpha, beta, gamma1, gamma2 = params
        gamma2 = np.abs(gamma2)
        pred = x_i + alpha * (h1 ** beta - h2 ** beta) + gamma1 * (h1 ** (beta + gamma2) - h2 ** (beta + gamma2))
        return y_i - pred

    def predict_objective(alpha, beta, gamma1, gamma2, h1, h2, x_i, y_i):
        gamma2 = np.abs(gamma2)
        x_i.append(y_i[-1])
        pred = x_i + alpha * (h1 ** beta - h2 ** beta) + gamma1 * (h1 ** (beta + gamma2) - h2 ** (beta + gamma2))
        return np.array(pred)
    params_init = np.round(np.random.uniform(low=0, high=5, size=4), 1)
    bounds = ([-100, 0, -100, -100], [100, 100, 100, 100])
    result = least_squares(objective, params_init, args=(x_i, y_i, h1, h2), method='trf', bounds=bounds)
    alpha, beta, gamma1, gamma2 = result.x
    h2 = np.append(h2, h1[-1])
    h1 = np.append(h1, 0)
    predicted_series = predict_objective(alpha, beta, gamma1, gamma2, h1, h2, x_i, y_i)
    return (result.x, predicted_series, params_init)

def process_and_evaluate(data_noise_free, noise_free_true, index):
    x_scaled, t_scaled, x_i, y_i, h1, h2, X_true_index, h_true_index, X_true_original, h_true_original = process_data(data_noise_free, index, noise_free_true)
    optimal_params, predicted_x, params_init = train_and_predict(x_i, y_i, h1, h2, n)
    t_NEW = np.append(t_scaled[1:], np.array([0]))
    X_true_original_new = np.array(X_true_original)[1:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-1]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_0': predicted_x[-1], 'X_true_original': np.array(X_true_original), 'optimal_params': optimal_params, 'seed': seed, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = f'data/Ours_complex/Ours_complex_data_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
    figure_name = f'figures/Ours_complex/Ours_complex_figure_parameter_{params_init}_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
    return LOOCV_MSE_all
