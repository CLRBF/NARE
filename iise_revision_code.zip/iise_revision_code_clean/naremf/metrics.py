from __future__ import annotations

import numpy as np


def relative_l2(reference: np.ndarray, estimate: np.ndarray, eps: float = 1e-12) -> float:
    reference = np.asarray(reference, dtype=float)
    estimate = np.asarray(estimate, dtype=float)
    denom = float(np.linalg.norm(reference.ravel()))
    error = float(np.linalg.norm((estimate - reference).ravel()))
    # The manuscript reports absolute error when the reference is exactly zero.
    return error if denom == 0.0 else error / denom


def point_error(reference: np.ndarray, estimate: np.ndarray) -> float:
    return relative_l2(reference, estimate)


def path_error(reference: np.ndarray, estimate: np.ndarray) -> float:
    return relative_l2(reference, estimate)


def rmse(reference: np.ndarray, estimate: np.ndarray) -> float:
    reference = np.asarray(reference, dtype=float)
    estimate = np.asarray(estimate, dtype=float)
    return float(np.sqrt(np.mean((estimate - reference) ** 2)))
