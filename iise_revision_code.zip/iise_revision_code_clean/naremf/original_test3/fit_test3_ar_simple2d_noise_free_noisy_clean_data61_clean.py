"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def process_data(data_dict):
    data_noise_free_1 = data_dict
    h_1 = data_noise_free_1['h'].flatten()
    h_1 = h_1
    temp_var1 = data_noise_free_1['x1'].flatten()
    temp_var1 = temp_var1
    temp_var2 = data_noise_free_1['x2'].flatten()
    temp_var2 = temp_var2
    temp_combined = np.vstack((temp_var1, temp_var2)).T
    a_1 = temp_combined
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    h_true = h_true[1:]
    X_true = X_true[1:]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original)

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def train_and_predict(x_i, y_i, h1, h2, n):
    seed_everything(seed=n)

    def objective(params, x_i, y_i, h1, h2):
        alpha1, alpha2, beta = params
        alpha_new = np.array([alpha1, alpha2])
        h1 = np.array(h1)
        h2 = np.array(h2)
        pred = np.array(x_i) + (alpha_new[:, np.newaxis] * (h1 ** beta - h2 ** beta)).T
        result = y_i - pred
        result = result.flatten()
        return result

    def predict_objective(alpha1, alpha2, beta, h1, h2, x_i, y_i):
        alpha_new = np.array([alpha1, alpha2])
        x_i.append(y_i[-1])
        pred = np.array(x_i) + (alpha_new[:, np.newaxis] * (h1 ** beta - h2 ** beta)).T
        return pred
    a = 0
    b = 5
    initial_guess = [np.random.uniform(a, b), np.random.uniform(a, b), np.random.uniform(a, b)]
    bounds = ([-10000, -10000, 0], [10000, 10000, 10000])
    result = least_squares(objective, initial_guess, args=(x_i, y_i, h1, h2), method='trf', bounds=bounds)
    alpha1, alpha2, beta = result.x
    h2 = np.append(h2, h1[-1])
    h1 = np.append(h1, 0.01)
    predicted_series = predict_objective(alpha1, alpha2, beta, h1, h2, x_i, y_i)
    h1_0 = 0
    h2_0 = h1[-1]
    x_i_new = y_i[-1]
    alpha_new = np.array([alpha1, alpha2])
    pred_h0 = np.array(x_i_new) + (alpha_new[:, np.newaxis] * (h1_0 ** beta - h2_0 ** beta)).T
    return (result.x, predicted_series, initial_guess, pred_h0)

def process_and_evaluate(data_noise_free, noise_free_true):
    t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original = process_data(data_noise_free)
    optimal_params, predicted_x, params_init, pred_h0 = train_and_predict(x_i, y_i, h1, h2, n)
    t_NEW = np.append(t_scaled[1:], np.array([0.01]))
    X_true_original_new = np.array(X_true_original)[1:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-1]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_h001': predicted_x[-1], 'pred_h0': pred_h0, 'X_true_original': np.array(X_true_original), 'optimal_params': optimal_params, 'seed': seed, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = f'data/Ours_simple/Ours_simple_data_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
    figure_name = f'figures/Ours_simple/Ours_simple_figure_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
    return LOOCV_MSE_all
