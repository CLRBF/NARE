"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def process_data(data_dict):
    data_noise_free_1 = data_dict
    h_1 = data_noise_free_1['h'].flatten()
    h_1 = h_1
    temp_var1 = data_noise_free_1['x1'].flatten()
    temp_var1 = temp_var1
    temp_var2 = data_noise_free_1['x2'].flatten()
    temp_var2 = temp_var2
    temp_combined = np.vstack((temp_var1, temp_var2)).T
    a_1 = temp_combined
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    h_true = h_true[1:]
    X_true = X_true[1:]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original)

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def train_and_predict(x_i, y_i, k, h1, h2, x_scaled, t_scaled, k1, k2, n):
    seed_everything(seed=n)

    def objective(params, x_i, y_i, k):
        phi, c1, c2 = params
        c = np.array([c1, c2])
        if abs(phi - 1) < 1e-08:
            pred = x_i + (c.reshape(-1, 1) * k.T).T
        else:
            pred = (phi ** k)[:, np.newaxis] * x_i + (c.reshape(-1, 1) * ((1 - phi ** k) / (1 - phi)).reshape(-1, 1).T).T
        result = y_i - pred
        result = result.flatten()
        return result

    def predict_objective(phi, c1, c2, x0, k_list):
        c = np.array([c1, c2])
        predictions = [x0]
        x_current = x0
        for k in k_list:
            if abs(phi - 1) < 1e-08:
                x_next = x_current + c * k
            else:
                x_next = phi ** k * x_current + c * (1 - phi ** k) / (1 - phi)
            predictions.append(x_next)
            x_current = x_next
        return np.array(predictions)
    a = 0
    b = 5
    initial_guess = [np.random.uniform(a, b), np.random.uniform(a, b), np.random.uniform(a, b)]
    bounds = ([-10000, -10000, -10000], [10000, 10000, 10000])
    result = least_squares(objective, initial_guess, args=(x_i, y_i, k), method='trf', bounds=bounds)
    phi, c1, c2 = result.x
    k_list = k
    x0 = x_scaled[0]
    k_list = np.append(k_list, k1)
    k_list = np.append(k_list, k2)
    predicted_series = predict_objective(phi, c1, c2, x0, k_list)
    pred_h0 = predicted_series[-1]
    return (result.x, predicted_series, initial_guess, pred_h0)

def process_and_evaluate(data_noise_free, noise_free_true):
    t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original = process_data(data_noise_free)
    delta_t = 0.0002500000000000002
    k = np.diff(t_scaled) / delta_t
    k = np.abs(k)
    k1 = np.abs((h_true_original[-1] - h_true_original[-2]) / delta_t)
    k2 = np.abs((0 - h_true_original[-1]) / delta_t)
    optimal_params, predicted_x, params_init, pred_h0 = train_and_predict(x_i, y_i, k, h1, h2, x_scaled, t_scaled, k1, k2, n)
    predicted_x = predicted_x[1:-1]
    t_NEW = np.append(t_scaled[1:], np.array([0.01]))
    X_true_original_new = np.array(X_true_original)[1:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-1]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-1])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_h001': predicted_x[-1], 'pred_h0': pred_h0, 'X_true_original': np.array(X_true_original), 'optimal_params': optimal_params, 'seed': seed, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = f'data/AR/Ours_complex_data_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
    figure_name = f'figures/AR/Ours_complex_figure_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
    return LOOCV_MSE_all
