"""Original fitting equations and preprocessing; file I/O is handled by the driver."""
import random
import numpy as np
import torch
from scipy.optimize import least_squares, minimize, Bounds

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def stationary(sigma, l, t1, t2):
    diff = t1 - t2
    return sigma ** 2 * torch.exp(-torch.sum(diff ** 2) / (2 * l ** 2))

def compute_next_theta(check, theta_hat, h):
    train_xt = torch.tensor(h)
    KXX_new = np.array([[stationary(sigma, l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[0:check]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def compute_next_theta_v2(check, theta_hat, h):
    train_xt = torch.tensor(theta_hat)
    KXX_new = np.array([[stationary(sigma, l, xi, xj) for xj in train_xt[0:check]] for xi in train_xt[0:check]])
    KXX_new += alpha * np.eye(check)
    KXX_new = torch.tensor(KXX_new)
    k00 = np.array([stationary(sigma, l, xi, train_xt[check]) for xi in train_xt[0:check]])
    k00 = torch.tensor(k00)
    y = theta_hat[1:check + 1]
    y = torch.tensor(y)
    mu = torch.matmul(torch.matmul(k00, torch.linalg.inv(KXX_new)), y)
    return mu

def process_data(data_dict):
    data_noise_free_1 = data_dict
    h_1 = data_noise_free_1['h'].flatten()
    h_1 = h_1
    temp_var1 = data_noise_free_1['x1'].flatten()
    temp_var1 = temp_var1
    temp_var2 = data_noise_free_1['x2'].flatten()
    temp_var2 = temp_var2
    temp_combined = np.vstack((temp_var1, temp_var2)).T
    a_1 = temp_combined
    h_true = np.array(h_1)
    X_true = np.array(a_1)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true = np.flipud(X_true)
    h_true = np.flip(h_true)
    X_true_original = X_true
    X_true_original = list(reversed(X_true_original))
    h_true_original = h_true
    h_true_original = list(reversed(h_true_original))
    h_true = h_true[1:]
    X_true = X_true[1:]
    h_true = list(reversed(h_true))
    X_true = list(reversed(X_true))
    t_scaled = h_true
    x_scaled = X_true
    x_i = x_scaled[:-1]
    y_i = x_scaled[1:]
    h1 = h_true[1:]
    h2 = h_true[:-1]
    return (t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original)

def compute_single(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def compute_relative_l2(true, predicted):
    relative_l2 = np.sqrt(np.sum((predicted - true) ** 2)) / np.sqrt(np.sum(true ** 2))
    MSE = np.mean((predicted - true) ** 2)
    return (relative_l2, MSE)

def train_and_predict(t_scaled, x_scaled, h_true_original, X_true_original):
    h = torch.tensor(t_scaled)
    theta_hat = torch.tensor(x_scaled)
    h = torch.cat((h, torch.tensor([h_true_original[-1]])))
    theta_hat = torch.cat((theta_hat, torch.tensor([X_true_original[-1]])))
    theta_new = []
    if version == 1:
        h = torch.cat((h, torch.tensor([0])))
        for check in range(1, len(h)):
            next_theta = compute_next_theta(check, theta_hat, h)
            theta_new.append(next_theta)
    else:
        h = torch.cat((h, torch.tensor([0])))
        for check in range(1, len(h) - 1):
            next_theta = compute_next_theta_v2(check, theta_hat, h)
            theta_new.append(next_theta)
    theta_new = torch.stack(theta_new)
    theta_new = theta_new.numpy()
    return theta_new

def process_and_evaluate(data_noise_free, noise_free_true):
    t_scaled, x_scaled, x_i, y_i, h1, h2, X_true_original, h_true_original = process_data(data_noise_free)
    theta_new = train_and_predict(t_scaled, x_scaled, h_true_original, X_true_original)
    predicted_x = theta_new
    pred_h0 = theta_new[-1]
    t_NEW = np.append(t_scaled[1:], np.array([0.01]))[1:]
    X_true_original_new = np.array(X_true_original)[2:]
    single_point_error_relative, single_point_error_mse = compute_single(X_true_original_new[-1], np.array(predicted_x[-2]))
    relative_l2, LOOCV_MSE = compute_relative_l2(X_true_original_new[:-1], predicted_x[:-2])
    LOOCV_MSE_all = LOOCV_MSE + single_point_error_mse
    params_init = np.array([alpha, sigma, l])
    data = {'t_NEW': t_NEW, 'predicted_x': predicted_x, 'predicted_x_h001': predicted_x[-2], 'pred_h0': pred_h0, 'X_true_original': np.array(X_true_original), 'seed': seed, 'params_init': params_init, 'single_point_error_relative': single_point_error_relative, 'single_point_error_mse': single_point_error_mse, 'relative_l2': relative_l2, 'LOOCV_MSE': LOOCV_MSE, 'LOOCV_MSE_all': LOOCV_MSE_all}
    _capture(data)
    data_name = f'data/GPSSM/GPSSM_data_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.mat'
    figure_name = f'figures/GPSSM/GPSSM_figure_parameter_ground_truth{noise_free_true}_seed={seed}_noise{noise}.png'
    return LOOCV_MSE_all
