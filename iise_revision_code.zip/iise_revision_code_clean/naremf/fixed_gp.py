"""Sequential stationary GP with the original Test 1 parameter settings."""
from pathlib import Path
import json
import numpy as np
from scipy.io import loadmat

INPUT = Path(__file__).resolve().parents[1] / 'data/test1_original'


def fit_original_stationary_gp(noise: float) -> dict:
    settings = json.loads((INPUT / 'selected_parameters.json').read_text())
    matches = [r for r in settings if r['method'] == 'Stationary GP'
               and np.isclose(r['noise_std'], noise)]
    if len(matches) != 1:
        raise ValueError(f'Expected one stationary-GP setting for noise={noise}')
    params = matches[0]['parameters']
    data = loadmat(INPUT / f'noise_{noise:g}.mat')
    h = data['h_set'].ravel()[::-1].copy()
    y = data['a_optimal_set'].ravel()[::-1].copy()
    sigma, length, nugget = (params[k] for k in ['sigma', 'l', 'alpha'])
    predictions = []
    for k in range(1, len(h)):
        x = h[:k]
        covariance = sigma**2 * np.exp(-(x[:, None] - x[None, :])**2 / (2 * length**2))
        covariance += nugget * np.eye(k)
        cross = sigma**2 * np.exp(-(x - h[k])**2 / (2 * length**2))
        predictions.append(float(cross @ np.linalg.inv(covariance) @ y[:k]))
    prediction = np.asarray(predictions)
    truth = y[1:]
    # Retain the original GP's prediction-denominator reporting convention.
    return {
        'noise_std': noise,
        'method': 'Original GP (fixed candidate)',
        'point_error': abs(prediction[-1] - truth[-1]) / abs(prediction[-1]),
        'path_error': np.linalg.norm(prediction[:-1] - truth[:-1]) / np.linalg.norm(prediction[:-1]),
        'target_prediction': float(prediction[-1]),
        'canonical_point_error': abs(prediction[-1] - truth[-1]) / abs(truth[-1]),
        'canonical_path_error': np.linalg.norm(prediction[:-1] - truth[:-1]) / np.linalg.norm(truth[:-1]),
        'source': 'fresh prediction from fixed parameters',
        'status': 'ok',
    }
