from __future__ import annotations

import argparse
import json
from itertools import product

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from naremf.data import load_test2, subset_dataset
from naremf.metrics import point_error
from naremf.models import GaussRichardson, GeneralizedRichardson, NAREComplex, NARESimple, RationalKriging, StationaryGP
from naremf.runner import ROOT, run_models
from ._common import add_common_arguments, write_combined


def design_indices(h: np.ndarray, L: int, design: str) -> np.ndarray:
    h = np.asarray(h, dtype=float)
    n = h.size
    if L > n:
        raise ValueError("L exceeds available levels")
    u = np.linspace(0.0, 1.0, L)
    if design == "broad_uniform":
        positions = u
    elif design == "fine_biased":
        positions = u**1.8
    elif design == "coarse_biased":
        positions = 1.0 - (1.0 - u) ** 1.8
    elif design == "narrow_fine":
        max_position = min(0.48, max((L - 1) / max(n - 1, 1), 0.2))
        positions = np.linspace(0.0, max_position, L)
    else:
        raise ValueError(f"unknown design {design}")
    raw = np.rint(positions * (n - 1)).astype(int)
    raw[0], raw[-1] = 0, raw[-1]
    # Fill accidental duplicates with nearest unused indices.
    chosen: list[int] = []
    for candidate in raw:
        if candidate not in chosen:
            chosen.append(int(candidate))
        else:
            for radius in range(1, n):
                options = [candidate - radius, candidate + radius]
                valid = [v for v in options if 0 <= v < n and v not in chosen]
                if valid:
                    chosen.append(int(valid[0]))
                    break
    if len(chosen) < L:
        for i in range(n):
            if i not in chosen:
                chosen.append(i)
            if len(chosen) == L:
                break
    return np.asarray(sorted(chosen[:L]), dtype=int)


def model_set(L: int, seed: int, quick: bool):
    methods = [NARESimple(), GeneralizedRichardson(), GaussRichardson(seed=seed), StationaryGP("loocv", seed=seed)]
    if L >= 5:
        methods.insert(1, NAREComplex(seed=seed))
    if not quick:
        methods.append(RationalKriging(seed=seed))
    return methods


def main() -> None:
    parser = add_common_arguments(argparse.ArgumentParser(description="Test 2 fidelity-count and mesh-design sensitivity."))
    args = parser.parse_args()
    base = load_test2(1.0, 0.0)
    levels = [3, 4, 5, 6, 8] if not args.quick else [3, 5, 8]
    designs = ["broad_uniform", "fine_biased", "coarse_biased", "narrow_fine"] if not args.quick else ["broad_uniform", "narrow_fine"]
    out = ROOT / "results" / "design_sensitivity"
    fig_dir = ROOT / "figures" / "design_sensitivity"
    out.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)
    summaries: list[pd.DataFrame] = []
    predictions: list[pd.DataFrame] = []
    stability_rows: list[dict] = []
    for L, design in product(levels, designs):
        idx = design_indices(base.h_train, L, design)
        dataset = subset_dataset(
            base,
            idx,
            name=f"test2_design_{design}_L_{L}",
            design=design,
            L=L,
            selected_h=base.h_train[idx].tolist(),
        )
        models = model_set(L, args.seed, args.quick)
        summary, pred, _ = run_models(
            dataset,
            models,
            scenario={"experiment": "test2_design_sensitivity", "L": L, "design": design},
            fail_fast=args.fail_fast,
        )
        summaries.append(summary)
        predictions.append(pred)
        # Leave-one-training-level-out stability of the target prediction.
        # Stability is intentionally restricted to the power-law family. Re-optimizing
        # GP LOOCV inside every leave-one-level fold is computationally wasteful and is
        # not needed to answer the reviewer's identifiability/design question.
        stability_models = [NARESimple(), GeneralizedRichardson()]
        if L >= 6:  # removing one level must still leave >=5 for the two-term model
            stability_models.insert(1, NAREComplex(seed=args.seed))
        for model in stability_models:
            values = []
            if L >= 4:
                for omitted in range(L):
                    keep = np.delete(np.arange(L), omitted)
                    try:
                        sub = subset_dataset(dataset, keep, name=f"{dataset.name}_loo_{omitted}")
                        values.append(float(model.fit_predict(sub).target_prediction[0]))
                    except Exception:
                        continue
            stability_rows.append(
                {
                    "L": L,
                    "design": design,
                    "method": model.name,
                    "n_successful_loo": len(values),
                    "target_prediction_sd": float(np.std(values, ddof=1)) if len(values) >= 2 else np.nan,
                    "target_prediction_range": float(np.ptp(values)) if values else np.nan,
                }
            )
    summary = write_combined(summaries, out / "design_sensitivity.csv")
    write_combined(predictions, out / "design_sensitivity_predictions.csv")
    pd.DataFrame(stability_rows).to_csv(out / "leave_one_level_stability.csv", index=False)
    summary_ok = summary[summary["status"] == "ok"].copy()
    fig, ax = plt.subplots(figsize=(8.2, 5.2))
    for (method, design), group in summary_ok.groupby(["method", "design"]):
        group = group.sort_values("L")
        ax.plot(group["L"], group["point_error"], marker="o", label=f"{method} / {design}")
    ax.set_yscale("log")
    ax.set_xlabel("Number of training levels L")
    ax.set_ylabel("Held-out point error")
    ax.set_title("Test 2 fidelity-design sensitivity under the original endpoint definition")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=6, ncol=2)
    fig.tight_layout()
    fig.savefig(fig_dir / "point_error_vs_L_and_design.png", dpi=220)
    plt.close(fig)
    (out / "run_metadata.json").write_text(
        json.dumps(
            {
                "base_case": "Test 2, a_true=1, noise-free",
                "levels": levels,
                "designs": designs,
                "endpoint_used_for_final_sensitivity_evaluation": True,
                "notes": "All designs are deterministic subsamples of the exact original Test 2 finite-level set; this sensitivity does not replace the submitted main table.",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(summary[["L", "design", "method", "status", "point_error", "path_error"]].to_string(index=False))


if __name__ == "__main__":
    main()
