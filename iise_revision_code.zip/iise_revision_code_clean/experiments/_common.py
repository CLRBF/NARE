from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from naremf.runner import ROOT

SEED = 20260827


def add_common_arguments(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    parser.add_argument("--seed", type=int, default=SEED, help="Deterministic optimization seed.")
    parser.add_argument("--quick", action="store_true", help="Run a small smoke configuration.")
    parser.add_argument("--fail-fast", action="store_true", help="Stop immediately if one method fails.")
    return parser


def write_combined(frames: list[pd.DataFrame], path: Path) -> pd.DataFrame:
    path.parent.mkdir(parents=True, exist_ok=True)
    combined = pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()
    combined.to_csv(path, index=False)
    return combined


def repo_path(*parts: str) -> Path:
    return ROOT.joinpath(*parts)
