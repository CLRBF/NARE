"""Compare profile-MLE stationary GP with the original fixed-candidate GP."""
from __future__ import annotations
import argparse
import pandas as pd
from naremf.data import load_test1
from naremf.fixed_gp import fit_original_stationary_gp
from naremf.models import StationaryGP
from naremf.runner import ROOT, run_models
from ._common import add_common_arguments, write_combined


def main():
    args = add_common_arguments(argparse.ArgumentParser(description=__doc__)).parse_args()
    rows, predictions = [], []
    for noise in ([0.0, 0.02] if args.quick else [0.0, 0.02, 0.05, 0.1]):
        rows.append(fit_original_stationary_gp(noise))
        summary, pred, _ = run_models(
            load_test1(noise), [StationaryGP('mle', seed=args.seed)],
            {'noise_std': noise}, fail_fast=args.fail_fast)
        row = summary.iloc[0].to_dict()
        row.update(method='GP (profile MLE)', source='fresh profile-MLE fit')
        rows.append(row)
        predictions.append(pred)
    out = ROOT / 'results/gp_mle_sensitivity'
    out.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(out / 'legacy_cv_vs_profile_mle.csv', index=False)
    write_combined(predictions, out / 'profile_mle_predictions.csv')
    print(frame[['noise_std', 'method', 'point_error', 'path_error']].to_string(index=False))


if __name__ == '__main__':
    main()
