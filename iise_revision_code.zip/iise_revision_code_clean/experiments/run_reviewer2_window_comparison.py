"""Reviewer-2 full-vs-reduced Test 3 comparison including noise-capable models.

This script does not alter any submitted result.  It fits every method to the same
version of the archived Test 3 trajectory and writes a reviewer-facing sensitivity
analysis under results/reviewer2_final/.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from naremf.data import make_test3_sensitivity_variants
from naremf.models import (
    GPStateSpace,
    GeneralizedRichardson,
    NAREComplex,
    NARESimple,
    RationalKriging,
    ScaledAR,
    StationaryGP,
    UniversalGP,
)
from naremf.runner import ROOT, run_models
from experiments._common import add_common_arguments, write_combined


def reviewer2_models(seed: int, n_levels: int):
    models = [NARESimple()]
    if n_levels >= 5:
        models.append(NAREComplex(seed=seed))
    models.extend(
        [
            GeneralizedRichardson(),
            StationaryGP(criterion="loocv", seed=seed),
            GPStateSpace(criterion="mle", seed=seed),
            UniversalGP(criterion="loocv", seed=seed),
            ScaledAR(),
            RationalKriging(seed=seed),
        ]
    )
    return models


def main() -> None:
    parser = add_common_arguments(
        argparse.ArgumentParser(
            description=(
                "Reviewer-2 Test 3 sensitivity with NARE, kriging, state-space, "
                "nonstationary, autoregressive, and Richardson comparators."
            )
        )
    )
    parser.add_argument(
        "--selection-source", choices=["archived", "algorithmic"], default="archived"
    )
    args = parser.parse_args()

    scenarios = ["noise_free"] if args.quick else ["noise_free", "noisy"]
    variants = ["selected"] if args.quick else ["full", "selected", "shorter", "expanded"]
    out_dir = ROOT / "results" / "reviewer2_final"
    out_dir.mkdir(parents=True, exist_ok=True)

    summaries = []
    predictions = []
    variant_rows = []
    for scenario in scenarios:
        data_versions = make_test3_sensitivity_variants(
            scenario=scenario, selection_source=args.selection_source
        )
        for variant in variants:
            dataset = data_versions[variant]
            summary, prediction, _ = run_models(
                dataset,
                reviewer2_models(args.seed, dataset.n_levels),
                {
                    "experiment": "reviewer2_test3_window_comparison",
                    "selection_source": args.selection_source,
                    "scenario": scenario,
                    "variant": variant,
                    "submitted_table_replaced": False,
                },
                args.fail_fast,
            )
            summaries.append(summary)
            predictions.append(prediction)
            variant_rows.append(
                {
                    "selection_source": args.selection_source,
                    "scenario": scenario,
                    "variant": variant,
                    "n_levels": dataset.n_levels,
                    "h_min": float(dataset.h_train.min()),
                    "h_max": float(dataset.h_train.max()),
                    "training_h": json.dumps(dataset.h_train.tolist()),
                    "target_h": float(dataset.target_h),
                    "selection_rule": dataset.metadata.get("selection_rule", variant),
                }
            )

    summary = write_combined(summaries, out_dir / "test3_window_all_methods.csv")
    write_combined(predictions, out_dir / "test3_window_all_methods_predictions.csv")
    pd.DataFrame(variant_rows).to_csv(out_dir / "test3_window_variants.csv", index=False)
    metadata = {
        "submitted_main_table_replaced": False,
        "purpose": (
            "answer Reviewer 2 on subsequence selection bias and whether noise-capable "
            "or nonstationary methods remain competitive on the full trajectory"
        ),
        "selection_source": args.selection_source,
        "shorter_window_rule": (
            "remove the two coarsest retained levels from the archived selected sequence; "
            "the rule is fixed before fitting and does not use target errors"
        ),
        "same_data_within_variant": True,
        "seed": args.seed,
    }
    (out_dir / "test3_window_all_methods_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(
        summary[
            [
                "scenario",
                "variant",
                "n_levels",
                "method",
                "status",
                "point_error",
                "path_error",
            ]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
