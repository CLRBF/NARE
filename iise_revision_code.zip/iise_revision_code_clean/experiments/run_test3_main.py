"""Refit all nine models on the ten archived turbine calibration trajectories.

This fills the missing producer for test3_sensitivity/main_results.csv in the
archived revision workflow. The reference at h=0.01 is not supplied to fitting.
"""
from __future__ import annotations
import argparse
from naremf.data import load_test3_selected
from naremf.runner import ROOT, default_models, run_models
from ._common import add_common_arguments, write_combined

def main():
    args = add_common_arguments(argparse.ArgumentParser(description=__doc__)).parse_args()
    summaries, predictions = [], []
    for variable in ([1] if args.quick else range(1, 6)):
        for scenario in (['noise_free'] if args.quick else ['noise_free', 'noisy']):
            dataset = load_test3_selected(variable, scenario)
            summary, prediction, _ = run_models(dataset, default_models(args.seed),
                {'experiment': 'test3_main', 'variable': variable,
                 'scenario': scenario, 'variant': 'legacy_selected'}, args.fail_fast)
            summaries.append(summary)
            predictions.append(prediction)
    out = ROOT / 'results/test3_sensitivity'
    summary = write_combined(summaries, out / 'main_results.csv')
    write_combined(predictions, out / 'main_predictions.csv')
    print(summary[['variable', 'scenario', 'method', 'status', 'point_error']].to_string(index=False))
    if not (summary.status == 'ok').all():
        raise RuntimeError('A turbine model failed; inspect main_results.csv.')

if __name__ == '__main__':
    main()
