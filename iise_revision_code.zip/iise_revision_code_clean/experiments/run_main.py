"""Run the calibration-trajectory models for Tests 1, 2 and 3."""
from __future__ import annotations
import argparse
from naremf.data import load_test1, load_test2, load_test3_selected
from naremf.models import NARESimple, NAREComplex, StationaryGP, GPStateSpace, UniversalGP, ScaledAR
from naremf.runner import ROOT, default_models, run_models, plot_trajectory_comparison
from ._common import add_common_arguments, write_combined


def main_models(seed):
    return [NARESimple(), NAREComplex(seed=seed), StationaryGP('loocv', seed=seed),
            GPStateSpace('mle', seed=seed), UniversalGP('loocv', seed=seed), ScaledAR()]


def main():
    parser = add_common_arguments(argparse.ArgumentParser(description=__doc__))
    parser.add_argument('--tests', choices=['all', 'test1', 'test2', 'test3'], default='all')
    args = parser.parse_args()
    cases = []
    if args.tests in {'all', 'test1'}:
        for noise in ([0.0, 0.02] if args.quick else [0.0, 0.02, 0.05, 0.1]):
            cases.append((load_test1(noise), {'experiment': 'test1', 'noise_std': noise}))
    if args.tests in {'all', 'test2'}:
        for a in ([1.0] if args.quick else [1.0, 2.0, -1.0, -2.0, 0.0]):
            for noise in ([0.0, 0.5] if args.quick else [0.0, 0.25, 0.5, 1.0]):
                cases.append((load_test2(a, noise), {'experiment': 'test2', 'a_true': a, 'noise_std': noise}))
    if args.tests in {'all', 'test3'}:
        for variable in ([1] if args.quick else range(1, 6)):
            for scenario in (['noise_free'] if args.quick else ['noise_free', 'noisy']):
                cases.append((load_test3_selected(variable, scenario),
                              {'experiment': 'test3', 'variable': variable, 'scenario': scenario}))
    summaries, predictions = [], []
    for dataset, metadata in cases:
        models = default_models(args.seed) if metadata['experiment'] == 'test3' else main_models(args.seed)
        summary, pred, fits = run_models(dataset, models, metadata, fail_fast=args.fail_fast)
        summaries.append(summary)
        predictions.append(pred)
        if metadata.get('a_true', 1) == 1 and metadata.get('variable', 1) == 1:
            plot_trajectory_comparison(dataset, fits, ROOT / 'figures/main' / (dataset.name + '.png'))
    out = ROOT / 'results/main'
    summary = write_combined(summaries, out / 'main_results.csv')
    write_combined(predictions, out / 'main_predictions.csv')
    print(summary[['dataset', 'method', 'status', 'point_error']].to_string(index=False))
    if not (summary.status == 'ok').all():
        raise RuntimeError('A model failed; see main_results.csv')


if __name__ == '__main__':
    main()
