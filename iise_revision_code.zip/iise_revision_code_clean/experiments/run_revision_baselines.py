from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import numpy as np

from naremf.data import load_test1, load_test2, load_test3_selected
from naremf.legacy_protocol import legacy_setting_score
from naremf.models import GeneralizedRichardson, GaussRichardson, RationalKriging
from naremf.runner import ROOT, plot_trajectory_comparison, run_models
from ._common import add_common_arguments, write_combined


def models(seed:int, quick:bool):
    out=[GeneralizedRichardson(), RationalKriging(seed=seed)]
    if not quick:
        out.insert(1,GaussRichardson(seed=seed))
    return out


def add_legacy_scores(summary:pd.DataFrame,preds:pd.DataFrame)->pd.DataFrame:
    rows=[]
    for _,row in summary.iterrows():
        if row.get("status")!="ok":
            rows.append(row.to_dict()); continue
        sub=preds[(preds["dataset"]==row["dataset"]) & (preds["method"]==row["method"])]
        path=sub[sub["kind"]=="training_path"].sort_values(["h","component"])
        target=sub[sub["kind"]=="held_out_target"].sort_values("component")
        score=legacy_setting_score(path["reference"].to_numpy(),path["prediction"].to_numpy(),target["reference"].to_numpy(),target["prediction"].to_numpy())
        d=row.to_dict(); d.update({
            "legacy_path_mse":score.path_mse,
            "legacy_endpoint_mse":score.endpoint_mse,
            "legacy_candidate_score":score.aggregate_score,
            "endpoint_absolute_error":score.endpoint_absolute_error,
            "metric_note":"relative point error is undefined at zero reference; use endpoint_absolute_error for a_true=0",
        }); rows.append(d)
    return pd.DataFrame(rows)


def main()->None:
    p=add_common_arguments(argparse.ArgumentParser(description="Run reviewer-requested direct baselines on the original Test 1/2/3 trajectory definitions."))
    p.add_argument("--tests",choices=["test1","test2","test3","all"],default="all")
    args=p.parse_args()
    out=ROOT/"results"/"revision_baselines"; fig=ROOT/"figures"/"revision_baselines"
    out.mkdir(parents=True,exist_ok=True); fig.mkdir(parents=True,exist_ok=True)
    sums=[]; pres=[]
    if args.tests in {"test1","all"}:
        noises=[0.0,0.02] if args.quick else [0.0,0.02,0.05,0.1]
        for n in noises:
            ds=load_test1(n)
            s,pr,res=run_models(ds,models(args.seed,args.quick),{"experiment":"test1","noise_std":n,"protocol":"original endpoint evaluation"},args.fail_fast)
            sums.append(s); pres.append(pr)
            plot_trajectory_comparison(ds,res,fig/f"test1_noise_{n:g}.png",title=f"Test 1 added direct baselines, noise={n:g}")
    if args.tests in {"test2","all"}:
        avals=[1.0] if args.quick else [1.0,2.0,-1.0,-2.0,0.0]
        noises=[0.0,0.5] if args.quick else [0.0,0.25,0.5,1.0]
        for a in avals:
            for n in noises:
                ds=load_test2(a,n)
                s,pr,res=run_models(ds,models(args.seed,args.quick),{"experiment":"test2","a_true":a,"noise_std":n,"protocol":"original mesh indices and endpoint definition"},args.fail_fast)
                sums.append(s); pres.append(pr)
                if a==1.0:
                    plot_trajectory_comparison(ds,res,fig/f"test2_a1_noise_{n:g}.png",title=f"Test 2 added direct baselines, a=1, noise={n:g}")
    if args.tests in {"test3","all"}:
        variables=[1] if args.quick else [1,2,3,4,5]
        scenarios=["noise_free"] if args.quick else ["noise_free","noisy"]
        for v in variables:
            for scen in scenarios:
                ds=load_test3_selected(v,scen)
                s,pr,res=run_models(ds,models(args.seed,args.quick),{"experiment":"test3","variable":v,"scenario":scen,"protocol":"archived sparse selected subsequence"},args.fail_fast)
                sums.append(s); pres.append(pr)
                if v==1:
                    plot_trajectory_comparison(ds,res,fig/f"test3_variable1_{scen}.png",title=f"Test 3 added direct baselines, variable 1, {scen}")
    summary=write_combined(sums,out/"direct_baselines_raw.csv")
    predictions=write_combined(pres,out/"direct_baselines_predictions.csv")
    scored=add_legacy_scores(summary,predictions)
    scored.to_csv(out/"direct_baselines.csv",index=False)
    # The original Test 2/3 candidate protocol aggregates setting-wise scores.
    agg=[]
    if not scored.empty:
        t2=scored[(scored["experiment"]=="test2") & (scored["status"]=="ok")]
        for (noise,method),g in (t2.groupby(["noise_std","method"]) if not t2.empty else []):
            agg.append({"experiment":"test2","scenario":f"noise={noise:g}","method":method,"n_settings":len(g),"mean_legacy_candidate_score":g["legacy_candidate_score"].mean(),"aggregation":"mean across a={1,2,-1,-2,0}"})
        t3=scored[(scored["experiment"]=="test3") & (scored["status"]=="ok")]
        for (scen,method),g in (t3.groupby(["scenario","method"]) if not t3.empty else []):
            agg.append({"experiment":"test3","scenario":scen,"method":method,"n_settings":len(g),"mean_legacy_candidate_score":g["legacy_candidate_score"].mean(),"aggregation":"mean across variables 1-5"})
    pd.DataFrame(agg).to_csv(out/"cross_setting_average_scores.csv",index=False)
    meta={
      "primary_data_protocol":"original Test 1/2/3 finite trajectories and endpoint definitions",
      "new_methods":["Generalized Richardson","Gauss-Richardson / GRE","Rational Kriging"],
      "legacy_results_overwritten":False,
      "test2_mesh_selection":"original indices [0,...,14,16,18]",
      "test3_selection":"archived sparse selected sequence",
      "seed":args.seed,
    }
    (out/"run_metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
    print(scored[[c for c in ["experiment","a_true","noise_std","variable","scenario","method","point_error","path_error","legacy_candidate_score","endpoint_absolute_error"] if c in scored.columns]].to_string(index=False))

if __name__=="__main__":
    main()
