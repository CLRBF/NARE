from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from naremf.data import (
    load_test1,
    load_test1_observations,
    load_test2,
    load_test2_observations,
)
from naremf.metrics import point_error
from naremf.runner import ROOT
from naremf.two_stage import (
    SharedOutputGP,
    StructuredPoissonFEM,
    calibrate_grid,
    generate_poisson_outputs,
    poisson_exact,
    test1_simulator,
)
from ._common import add_common_arguments


def test1_two_stage(noises: list[float], seed: int, quick: bool) -> tuple[pd.DataFrame, dict]:
    reference_ds = load_test1(0.0)
    h_train = reference_ds.h_train
    theta_grid = np.linspace(-np.pi, np.pi, 601 if quick else 1601)
    x = load_test1_observations(0.0)["x"]

    # Hyperparameters are estimated once from a representative, target-free sample.
    theta_sample = np.linspace(-np.pi, np.pi, 25)
    sample_outputs = test1_simulator(h_train, theta_sample, x)
    sample_matrix = sample_outputs.reshape(h_train.size, -1)
    emulator = SharedOutputGP.fit(h_train, sample_matrix, seed=seed)

    all_training_outputs = test1_simulator(h_train, theta_grid, x)
    target_prediction = emulator.predict(all_training_outputs.reshape(h_train.size, -1), 0.0)
    target_surfaces = target_prediction.reshape(theta_grid.size, x.size)

    rows = []
    for noise in noises:
        obs = load_test1_observations(noise)
        estimate, objective = calibrate_grid(theta_grid, target_surfaces, obs["physical"])
        manuscript_reference = float(load_test1(noise).y_target[0])
        rows.append(
            {
                "experiment": "test1",
                "noise_std": noise,
                "method": "Output-level MF GP -> L2 calibration",
                "target_h": 0.0,
                "estimate": estimate,
                "reference_manuscript": manuscript_reference,
                "point_error_manuscript": abs(estimate - manuscript_reference) / max(abs(manuscript_reference), 1e-12),
                "calibration_mse": objective,
                "emulator_lengthscale_scaled": emulator.lengthscale,
                "emulator_nugget_ratio": emulator.nugget,
                "emulator_optimizer_success": emulator.optimizer_success,
                "target_used_in_emulator_fit": False,
            }
        )
    meta = {
        "training_h": h_train.tolist(),
        "theta_grid_size": int(theta_grid.size),
        "spatial_points": int(x.size),
        "emulator_lengthscale_scaled": emulator.lengthscale,
        "emulator_nugget_ratio": emulator.nugget,
        "emulator_profile_objective": emulator.objective,
    }
    return pd.DataFrame(rows), meta


def _poisson_training_cache_path(quick: bool) -> Path:
    suffix = "quick" if quick else "full"
    return ROOT / "results" / "two_stage_mf" / f"poisson_training_outputs_{suffix}.npz"


def build_or_load_poisson_training(
    h_train: np.ndarray,
    a_grid: np.ndarray,
    points: np.ndarray,
    quick: bool,
) -> np.ndarray:
    cache = _poisson_training_cache_path(quick)
    if cache.exists():
        archive = np.load(cache)
        if (
            archive["h_train"].shape == h_train.shape
            and archive["a_grid"].shape == a_grid.shape
            and archive["points"].shape == points.shape
            and np.allclose(archive["h_train"], h_train)
            and np.allclose(archive["a_grid"], a_grid)
            and np.allclose(archive["points"], points)
        ):
            print(f"Loading cached Poisson simulator outputs from {cache}")
            return archive["outputs"]
    outputs = generate_poisson_outputs(h_train, a_grid, points, progress=print)
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache, h_train=h_train, a_grid=a_grid, points=points, outputs=outputs)
    return outputs


def test2_two_stage(noises: list[float], seed: int, quick: bool) -> tuple[pd.DataFrame, dict]:
    # Use the union of finite training levels needed by all noise scenarios. In practice
    # this is 0.01,...,0.10; each noisy run removes h=0.01 before fitting.
    base = load_test2(1.0, 0.0)
    h_all = base.h_train
    obs0 = load_test2_observations(0.0)
    points = obs0["points"]
    a_grid = np.linspace(0.9, 1.1, 81 if quick else 201)
    outputs_all = build_or_load_poisson_training(h_all, a_grid, points, quick=quick)

    rows = []
    emulators = {}
    for noise in noises:
        ds = load_test2(1.0, noise)
        # Align this scenario's training levels to the cached union.
        indices = [int(np.flatnonzero(np.isclose(h_all, h, atol=1e-12))[0]) for h in ds.h_train]
        outputs = outputs_all[indices]
        # Representative columns for hyperparameter estimation: 9 a-values x <=120 spatial points.
        a_idx = np.linspace(0, a_grid.size - 1, 9, dtype=int)
        p_idx = np.linspace(0, points.shape[0] - 1, min(120, points.shape[0]), dtype=int)
        sample = outputs[:, a_idx][:, :, p_idx].reshape(ds.n_levels, -1)
        emulator = SharedOutputGP.fit(ds.h_train, sample, seed=seed)
        predicted = emulator.predict(outputs.reshape(ds.n_levels, -1), ds.target_h).reshape(a_grid.size, points.shape[0])
        obs = load_test2_observations(noise)
        estimate, objective = calibrate_grid(a_grid, predicted, obs["physical"])

        # A same-solver target reference is useful for checking that the portable SciPy
        # FEM and the legacy FEniCS trajectory are consistent.
        if np.isclose(ds.target_h, 0.0):
            same_solver_surfaces = poisson_exact(a_grid, points)
        else:
            same_solver_surfaces = StructuredPoissonFEM(ds.target_h).solve_many(a_grid, points)
        same_solver_ref, same_solver_obj = calibrate_grid(a_grid, same_solver_surfaces, obs["physical"])
        manuscript_ref = float(ds.y_target[0])
        rows.append(
            {
                "experiment": "test2",
                "noise_std": noise,
                "method": "Output-level MF GP -> L2 calibration",
                "target_h": ds.target_h,
                "estimate": estimate,
                "reference_manuscript": manuscript_ref,
                "reference_same_solver": same_solver_ref,
                "point_error_manuscript": abs(estimate - manuscript_ref) / max(abs(manuscript_ref), 1e-12),
                "point_error_same_solver": abs(estimate - same_solver_ref) / max(abs(same_solver_ref), 1e-12),
                "portable_vs_legacy_reference_gap": abs(same_solver_ref - manuscript_ref),
                "calibration_mse": objective,
                "same_solver_reference_mse": same_solver_obj,
                "emulator_lengthscale_scaled": emulator.lengthscale,
                "emulator_nugget_ratio": emulator.nugget,
                "emulator_optimizer_success": emulator.optimizer_success,
                "n_training_levels": ds.n_levels,
                "target_used_in_emulator_fit": False,
            }
        )
        emulators[str(noise)] = {
            "lengthscale_scaled": emulator.lengthscale,
            "nugget_ratio": emulator.nugget,
            "objective": emulator.objective,
            "optimizer_success": emulator.optimizer_success,
            "training_h": ds.h_train.tolist(),
        }
    meta = {
        "a_grid_size": int(a_grid.size),
        "spatial_points": int(points.shape[0]),
        "portable_solver": "structured P1 finite element method implemented with SciPy sparse linear algebra",
        "legacy_mesh_rule_reproduced": "n=int(1/h)",
        "emulators": emulators,
    }
    return pd.DataFrame(rows), meta


def plot_results(frame: pd.DataFrame, output: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.0, 4.8))
    x = np.arange(len(frame))
    ax.bar(x - 0.18, frame["estimate"], width=0.36, label="Two-stage estimate")
    ax.bar(x + 0.18, frame["reference_manuscript"], width=0.36, label="Manuscript reference")
    labels = [f"{e}\nnoise={n:g}" for e, n in zip(frame["experiment"], frame["noise_std"])]
    ax.set_xticks(x, labels)
    ax.set_ylabel("Calibration parameter")
    ax.set_title("Output-level multi-fidelity surrogate followed by calibration")
    ax.legend()
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=220)
    plt.close(fig)


def main() -> None:
    parser = add_common_arguments(argparse.ArgumentParser(description="AE-requested two-stage MF-output then calibration benchmark."))
    parser.add_argument("--tests", choices=["test1", "test2", "both"], default="both")
    args = parser.parse_args()
    selected_tests = args.tests
    # The Test 2 output-level benchmark intentionally solves many FEM systems.  The
    # project-wide --quick command therefore smoke-tests Test 1 only.  Test 2 still
    # has its own explicit quick mode via:
    #   python -m experiments.run_two_stage_mf --tests test2 --quick
    if args.quick and args.tests == "both":
        selected_tests = "test1"
    out = ROOT / "results" / "two_stage_mf"
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    metadata = {
        "protocol": "Simulator-output GP is fitted only on finite training fidelities. The target output and target calibration parameter are held out.",
        "seed": args.seed,
    }
    started = time.perf_counter()
    if selected_tests in {"test1", "both"}:
        f1, m1 = test1_two_stage([0.0, 0.02] if args.quick else [0.0, 0.02, 0.05, 0.1], args.seed, args.quick)
        frames.append(f1)
        metadata["test1"] = m1
    if selected_tests in {"test2", "both"}:
        f2, m2 = test2_two_stage([0.0, 0.5] if args.quick else [0.0, 0.25, 0.5, 1.0], args.seed, args.quick)
        frames.append(f2)
        metadata["test2"] = m2
    result = pd.concat(frames, ignore_index=True)
    result.to_csv(out / "two_stage_mf_calibration.csv", index=False)
    metadata["runtime_seconds"] = time.perf_counter() - started
    (out / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    plot_results(result, ROOT / "figures" / "two_stage_mf" / "two_stage_estimates.png")
    print(result.to_string(index=False))
    print(f"\nWrote {out / 'two_stage_mf_calibration.csv'}")


if __name__ == "__main__":
    main()
