from __future__ import annotations

import argparse, json
import pandas as pd

from naremf.data import make_test3_sensitivity_variants
from naremf.models import NARESimple, NAREComplex, GeneralizedRichardson, RationalKriging
from naremf.runner import ROOT, plot_trajectory_comparison, run_models
from ._common import add_common_arguments, write_combined


def sensitivity_models(seed:int, n_levels:int, quick:bool):
    ms=[NARESimple()]
    if n_levels>=5: ms.append(NAREComplex(seed=seed))
    ms.append(GeneralizedRichardson())
    if not quick: ms.append(RationalKriging(seed=seed))
    return ms


def main()->None:
    p=add_common_arguments(argparse.ArgumentParser(description='Reviewer-requested Test 3 full/selected/shorter/expanded sensitivity; submitted Table 3 remains unchanged.'))
    p.add_argument('--selection-source',choices=['archived','algorithmic','both'],default='archived')
    p.add_argument('--include-contiguous',action='store_true')
    args=p.parse_args()
    sources=['archived','algorithmic'] if args.selection_source=='both' else [args.selection_source]
    scenarios=['noise_free'] if args.quick else ['noise_free','noisy']
    names=['selected'] if args.quick else ['full','selected','shorter','expanded']
    if args.include_contiguous and not args.quick: names.append('contiguous_diagnostic')
    out=ROOT/'results'/'test3_sensitivity'; fig=ROOT/'figures'/'test3_sensitivity'; out.mkdir(parents=True,exist_ok=True); fig.mkdir(parents=True,exist_ok=True)
    sums=[]; pres=[]; variants=[]
    for source in sources:
        for scen in scenarios:
            data=make_test3_sensitivity_variants(scen,source)
            for name in names:
                ds=data[name]
                s,pr,res=run_models(ds,sensitivity_models(args.seed,ds.n_levels,args.quick),{
                    'experiment':'test3_subsequence_sensitivity','selection_source':source,'scenario':scen,'variant':name,
                    'submitted_table_replaced':False,
                },args.fail_fast)
                sums.append(s); pres.append(pr)
                variants.append({'selection_source':source,'scenario':scen,'variant':name,'n_levels':ds.n_levels,'h_min':ds.h_train.min(),'h_max':ds.h_train.max(),'selection_rule':ds.metadata.get('selection_rule','full')})
                if name in {'full','selected'}:
                    plot_trajectory_comparison(ds,res,fig/f'{source}_{scen}_{name}.png',title=f'Test 3 sensitivity: {source}, {scen}, {name}')
    summary=write_combined(sums,out/'subsequence_sensitivity.csv')
    write_combined(pres,out/'subsequence_sensitivity_predictions.csv')
    pd.DataFrame(variants).to_csv(out/'subsequence_variants.csv',index=False)
    meta={
      'submitted_table_replaced':False,
      'primary_selected_sequence':'archived sparse selected sequence',
      'endpoint_used_in_original_candidate_score':True,
      'important_provenance_warning':'The archived selected h values are sparse and are not a contiguous subset of the 61-level raw grid.',
      'purpose':'answer Reviewer 1 non-monotonicity and Reviewer 2 subsequence-selection sensitivity',
      'seed':args.seed,
    }
    (out/'run_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(summary[['selection_source','scenario','variant','n_levels','method','status','point_error','path_error']].to_string(index=False))

if __name__=='__main__': main()
