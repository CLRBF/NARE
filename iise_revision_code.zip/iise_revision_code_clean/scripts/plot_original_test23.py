"""Draw historical comparison panels from newly fitted predictions."""
from pathlib import Path
import argparse,os
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter

METHODS=['NARE-MF (Simple)','NARE-MF (Complex)','Stationary GP','GP-SSM','Nonstationary GP','Scaled AR']

def format_mesh_axis(ax,test):
    if test=='test3':
        ax.xaxis.set_major_locator(MultipleLocator(.005))
        ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--tests',choices=['test2','test3','all'],default='all');ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    root=Path(os.environ['IISE_OUTPUT_DIR']);data=pd.read_csv(root/'results/original_test23/predictions.csv');out=root/'figures/original_test23';out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'serif','font.size':12})
    for test,noises,figure_names in [('test2',[0,.5],['figure7','figure8']),('test3',[0,1],['figureF1','figureF2'])]:
        if args.tests not in ['all',test]:continue
        for noise,figure in zip(noises,figure_names):
            if args.quick and noise:continue
            frames=[]
            for method in METHODS:
                kind='plot' if test=='test2' else 'main'
                f=data[(data.experiment==test)&(data.panel_noise_std==noise)&(data.method==method)&(data.kind==kind)]
                if f.empty:raise ValueError('Missing new predictions for '+str((test,noise,method)))
                frames.append(f)
            fig,axes=plt.subplots(2,3,figsize=(12,7))
            for ax,method,f in zip(axes.ravel(),METHODS,frames):
                for j,comp in f.groupby('component'):
                    trained=comp[comp.row_role!='continuum_extrapolation'].sort_values('h')
                    ax.plot(trained.h,trained.reference,'o-',ms=4,mfc='none',color='#203b71',lw=1,label='Reference' if j==1 else None)
                    ax.plot(trained.h,trained.prediction,'o-',ms=2,color='#a02020',lw=1,label='Predicted' if j==1 else None)
                ax.set_title(method);ax.set_xlabel('$h$');ax.set_ylabel('Calibration parameter');format_mesh_axis(ax,test);ax.legend(fontsize=9);ax.grid(alpha=.15)
            fig.tight_layout();fig.savefig(out/(figure+'.pdf'));plt.close(fig)
            for method,f in zip(METHODS,frames):
                fig,ax=plt.subplots(figsize=(5,3.8))
                for j,comp in f.groupby('component'):
                    trained=comp[comp.row_role!='continuum_extrapolation'].sort_values('h')
                    ax.plot(trained.h,trained.reference,'o-',ms=4,mfc='none',color='#203b71',lw=1,label='Reference' if j==1 else None)
                    ax.plot(trained.h,trained.prediction,'o-',ms=2,color='#a02020',lw=1,label='Predicted' if j==1 else None)
                ax.set_xlabel('$h$');ax.set_ylabel('Calibration parameter');format_mesh_axis(ax,test);ax.legend(fontsize=10);fig.tight_layout()
                fig.savefig(out/(figure+'_'+method.replace(' ','_').replace('/','_')+'.pdf'));plt.close(fig)
    print('Figures written to',out)
if __name__=='__main__':main()
