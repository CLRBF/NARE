"""Refit the selected Test 1 candidates with the original Python 3.8 stack.

The selected configurations reproduce the original Table 1 fitting protocol.
A separate set of 60 full-precision configurations rebuilds the Appendix A.1
candidate comparison. --candidate-settings manuscript instead uses the
parameters printed in that table, including rounding and labeling differences. Both reference- and prediction-denominator errors are
reported so the historical GP convention remains explicit.
"""
from pathlib import Path
import ast, csv, json, time, os, argparse
from functools import lru_cache
import numpy as np
import torch
from scipy.io import loadmat
from scipy.optimize import least_squares

BASE=Path(__file__).resolve().parents[1]
ROOT=Path(os.environ.get('IISE_OUTPUT_DIR',BASE/'outputs')).resolve()
SOURCE=BASE/'naremf/original_test1'
INPUT=BASE/'data/test1_original'

@lru_cache(maxsize=1)
def gp_functions():
    names={'stationary','compute_next_theta','compute_next_theta_v2'}
    module=ast.parse((SOURCE/'gp_functions.py').read_text())
    module.body=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in names]
    scope={'np':np,'torch':torch}
    exec(compile(module,'archived_GP_definitions','exec'),scope)
    return scope

def non_gp(h,y,length,sigma_kriging=1.0,nugget=0.0,brownian_nugget=1e-4):
    # Execute the unchanged Brownian mean/covariance functions; preserve scalar
    # evaluation order because the archived zero-nugget covariance is ill-conditioned.
    names={'covariance_Brownian','compute_next_theta','covariance'}
    module=ast.parse((SOURCE/'non_gp_functions.py').read_text())
    module.body=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in names]
    scope={'np':np,'torch':torch,'sigma':1,'C':brownian_nugget}
    exec(compile(module,'archived_nonGP_definitions','exec'),scope)
    ht=torch.tensor(h);yt=torch.tensor(y)
    mu=np.array([scope['compute_next_theta'](k,yt,ht) for k in range(1,len(h))])
    x=h[1:-1];z=y[1:-1]-mu[:-1];F=np.vstack([np.ones_like(x),x]).T
    covariance=scope['covariance'];C=np.zeros((len(x),len(x)))
    for i in range(len(x)):
        for j in range(len(x)):C[i,j]=covariance(x[i],x[j],sigma_kriging,length)
    C += nugget*np.eye(len(x))
    inv=np.linalg.inv(C)
    beta=np.linalg.inv(F.T @ inv @ F) @ F.T @ inv @ z
    def predict(x0):
        f0=np.array([1,x0]);c0=np.array([covariance(x0,xi,sigma_kriging,length) for xi in x])
        residual=z-F @ beta
        return f0 @ beta+c0 @ inv @ residual
    return np.array([predict(x0) for x0 in h[1:]])+mu

def fit_configuration(config, h, y):
    noise=float(config['noise_std']);method=config['method']
    params=config['parameters']
    initial=np.asarray(params.get('initial',[]))
    archive={k:np.asarray([v]) for k,v in params.items() if k!='initial'}
    if 'length' in archive:archive['length_scale']=archive['length']
    settings={}; convention='reference_denominator'
    if method.startswith('NARE'):
        complex_model='Complex' in method
        def increment(p,hi,hj):
            value=p[0]*(hi**p[1]-hj**p[1])
            if complex_model:value+=p[2]*(hi**(p[1]+abs(p[3]))-hj**(p[1]+abs(p[3])))
            return value
        if not len(initial):raise RuntimeError('Missing selected NARE initial values')
        fit=least_squares(lambda p:y[1:-1]-y[:-2]-increment(p,h[1:-1],h[:-2]),initial,method='trf')
        prediction=y[:-1]+increment(fit.x,h[1:],h[:-1]);truth=y[1:];hh=h[1:]
        settings={'initial':initial.tolist(),'fitted':fit.x.tolist(),'success':bool(fit.success)}
    elif method=='Scaled AR':
        def one(p,x,k):
            phi,c=p
            return x+c*k if abs(phi-1)<1e-8 else phi**k*x+c*(1-phi**k)/(1-phi)
        k=np.abs(np.diff(h[:-1]))/.05
        fit=least_squares(lambda p:y[1:-1]-one(p,y[:-2],k),initial,method='trf')
        prediction=[];current=y[0]
        for step in np.append(k,1):
            current=one(fit.x,current,step);prediction.append(current)
        prediction=np.asarray(prediction);truth=y[1:];hh=h[1:]
        settings={'initial':initial.tolist(),'fitted':fit.x.tolist(),'success':bool(fit.success)}
    elif method in {'Stationary GP','GP-SSM'}:
        scope=gp_functions()
        for key in ['sigma','l','alpha']:scope[key]=float(archive[key].ravel()[0])
        ht=torch.tensor(h);yt=torch.tensor(y)
        if method=='Stationary GP':
            prediction=np.array([float(scope['compute_next_theta'](k,yt,ht)) for k in range(1,len(h))]);truth=y[1:];hh=h[1:]
        else:
            prediction=np.array([float(scope['compute_next_theta_v2'](k,yt[:-1],ht)) for k in range(1,len(h)-1)]);truth=y[2:];hh=h[2:]
        settings={key:scope[key] for key in ['sigma','l','alpha']};convention='prediction_denominator'
    else:
        length=float(np.asarray(archive['length_scale']).ravel()[0]) if 'length_scale' in archive else (.18 if noise==0 else .17)
        prediction=non_gp(h,y,length,float(params.get("sigma_kriging",1)),float(params.get("nugget",0)),float(params.get("Brownian_nugget",1e-4)));truth=y[1:];hh=h[1:]
        settings={'sigma_kriging':float(params.get('sigma_kriging',1)),'length':length,'nugget':float(params.get('nugget',0)),'Brownian_nugget':float(params.get('Brownian_nugget',1e-4))}
    if not np.isfinite(prediction).all():
        raise FloatingPointError('Non-finite original Test 1 prediction: '+method)
    point_mse=float(np.mean((prediction[-1]-truth[-1])**2))
    path_mse=float(np.mean((prediction[:-1]-truth[:-1])**2))
    pe=float(np.linalg.norm(prediction[-1]-truth[-1])/np.linalg.norm(truth[-1]))
    pa=float(np.linalg.norm(prediction[:-1]-truth[:-1])/np.linalg.norm(truth[:-1]))
    oldpe=float(np.linalg.norm(prediction[-1]-truth[-1])/np.linalg.norm(prediction[-1])) if convention=='prediction_denominator' else pe
    oldpa=float(np.linalg.norm(prediction[:-1]-truth[:-1])/np.linalg.norm(prediction[:-1])) if convention=='prediction_denominator' else pa
    row={'experiment':'test1','noise_std':noise,'method':method,
         'target_h':float(hh[-1]),'target_prediction':float(prediction[-1]),
         'path_mesh_levels':json.dumps(hh[:-1].tolist()),'n_path_points':len(hh)-1,
         'canonical_point_error':pe,'canonical_path_error':pa,
         'historical_point_error':oldpe,'historical_path_error':oldpa,
         'path_mse':path_mse,'endpoint_mse':point_mse,'candidate_score':path_mse+point_mse,
         'settings':json.dumps(settings),'historical_metric_convention':convention}
    if method=='Nonstationary GP':
        x=h[1:-1];sg=settings['sigma_kriging'];ll=settings['length'];ng=settings['nugget']
        cov=sg**2*np.exp(-(x[:,None]-x[None,:])**2/(2*ll**2))+ng*np.eye(len(x))
        row['covariance_condition_number']=float(np.linalg.cond(cov))
    predictions=[{'experiment':'test1','noise_std':noise,'method':method,
                  'h':float(a),'reference':float(b),'prediction':float(c),
                  'is_target':i==len(hh)-1} for i,(a,b,c) in enumerate(zip(hh,truth,prediction))]
    return row,predictions


def write_rows(path, rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selected-only',action='store_true',help='Only the 24 settings used for Table 1 and Figures 3-4.')
    parser.add_argument('--candidate-settings',choices=['archive','manuscript'],default='archive',
                        help='Use full-precision archived candidate inputs or the rounded parameters printed in Appendix A.1.')
    args=parser.parse_args()
    out=ROOT/'results/legacy_refit_test1';out.mkdir(parents=True,exist_ok=True)
    configurations=json.loads((INPUT/'selected_parameters.json').read_text())
    datasets={}
    for noise in [0.0,.02,.05,.1]:
        original_input=loadmat(INPUT/f'noise_{noise:g}.mat')
        datasets[noise]=(original_input['h_set'].ravel()[::-1].copy(),original_input['a_optimal_set'].ravel()[::-1].copy())
    rows=[];predictions=[]
    for config in configurations:
        start=time.perf_counter();row,pred=fit_configuration(config,*datasets[float(config['noise_std'])])
        row.update(seconds=time.perf_counter()-start,settings_source='data/test1_original/selected_parameters.json')
        rows.append(row);predictions.extend(pred)
        print('Selected',row['noise_std'],row['method'],row['historical_point_error'],row['historical_path_error'],flush=True)
    write_rows(out/'selected_candidate_refits.csv',rows);write_rows(out/'predictions.csv',predictions)
    if not args.selected_only:
        candidates=json.loads((INPUT/'candidate_parameters.json').read_text());scores=[]
        for original_config in candidates:
            config=dict(original_config)
            if args.candidate_settings=='manuscript':config['parameters']=config['manuscript_parameters']
            row,_=fit_configuration(config,*datasets[float(config['noise_std'])])
            row['candidate']=config['candidate'];row['parameters']=json.dumps(config['parameters'])
            row['settings_source']='data/test1_original/candidate_parameters.json'
            row['candidate_setting_source']=args.candidate_settings
            row['printed_parameters']=json.dumps(config['manuscript_parameters'])
            scores.append(row)
        for row in scores:
            group=[x for x in scores if x['noise_std']==row['noise_std'] and x['method']==row['method']]
            row['selected_by_score']=row['candidate']==min(group,key=lambda x:x['candidate_score'])['candidate']
        write_rows(out/'candidate_scores.csv',scores)
        print('Computed 60 Appendix A.1 candidate scores.',flush=True)


if __name__=='__main__':main()
