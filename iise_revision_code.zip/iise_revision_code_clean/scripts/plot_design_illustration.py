"""Draw the five-level simulator design in manuscript Figure 1."""
from pathlib import Path
import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('IISE_OUTPUT_DIR', BASE / 'outputs')).resolve()


def main():
    # The shared design locations in the manuscript's illustrative example.
    levels = [list(range(12)), [0, 2, 4, 6, 8, 10], [0, 4, 8, 10],
              [0, 4, 10], [0, 10]]
    fig, ax = plt.subplots(figsize=(9.2, 4.5))
    for level, indices in enumerate(levels):
        y = 4 - level
        ax.plot([0, 11], [y, y], color='0.8', linewidth=.8, zorder=0)
        ax.scatter(indices, np.full(len(indices), y), s=45, color='black', zorder=2)
        ax.text(-.45, y, rf'$h_{level+1}$', ha='right', va='center', fontsize=13)
        ax.text(12, y, rf'$N_{level+1}={len(indices)}$', va='center', fontsize=13)
        ax.text(14, y, rf'$C_{level+1}$', va='center', fontsize=13)
    ax.annotate('', xy=(-1.8, -.25), xytext=(-1.8, 4.25),
                arrowprops={'arrowstyle': '->', 'color': 'black'})
    ax.text(-2.2, 2, 'Higher fidelity (h decreases)', rotation=90,
            ha='center', va='center', fontsize=12)
    ax.annotate('', xy=(15.5, -.25), xytext=(15.5, 4.25),
                arrowprops={'arrowstyle': '->', 'color': 'black'})
    ax.text(15.9, 2, 'Increasing cost per run', rotation=90,
            ha='center', va='center', fontsize=12)
    ax.text(-.45, 4.5, 'coarse', ha='right', fontsize=11)
    ax.text(-.45, -.5, 'fine', ha='right', fontsize=11)
    ax.text(5.5, -.65, 'Simulator design space', ha='center', fontsize=13)
    ax.set_xlim(-2.7, 16.5)
    ax.set_ylim(-.85, 4.8)
    ax.axis('off')
    fig.tight_layout()
    out = ROOT / 'figures/design'
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / 'figure_1.pdf', bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    main()
