"""Re-solve the original FEniCS Poisson model for the Figure 5 field panels.

Run with Python 3.8 / FEniCS 2019.1; the revision-only environment has no FEniCS.
The PDE function is loaded unchanged from the preserved source snapshot.
"""
from pathlib import Path
import importlib.util, json, os, time, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get("IISE_OUTPUT_DIR",BASE/"outputs")).resolve()
def main():
    out = ROOT/'figures/test2_fields'; out.mkdir(parents=True, exist_ok=True)
    dataout = ROOT/'results/test2_fields'; dataout.mkdir(parents=True, exist_ok=True)
    cache = ROOT/'_runtime/dijitso'; cache.mkdir(parents=True, exist_ok=True)
    os.environ['DIJITSO_CACHE_DIR'] = str(cache)
    # Use pkg-config from the selected original environment, including when
    # the launcher invokes its Python directly without conda activation.
    prefix = Path(sys.prefix)
    os.environ['PATH'] = str(prefix/'bin') + os.pathsep + os.environ.get('PATH', '')
    os.environ['PKG_CONFIG_PATH'] = str(prefix/'lib/pkgconfig') + os.pathsep + os.environ.get('PKG_CONFIG_PATH', '')
    source = BASE/'naremf/original_test2/poisson_fields.py'
    spec = importlib.util.spec_from_file_location('original_poisson_fields', source)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    grid = np.linspace(0, 1, 40); x,y = np.meshgrid(grid, grid)
    reference = np.exp(x)*np.sin(np.pi*x)*np.sin(np.pi*y)
    fields = {'analytical_solution': reference}; rows = []
    for h in [0.01, 0.05, 0.1, 0.2]:
        start = time.perf_counter()
        values,_,error,_,_ = module.getSolutions(1.0,h,reference,x,y)
        fields['solution_h_'+str(h)] = values
        rows.append({'h':h,'relative_field_error':float(error),'seconds':time.perf_counter()-start})
    np.savez(dataout/'fields.npz', x=x,y=y,**fields)
    for name,values in fields.items():
        fig,ax = plt.subplots(figsize=(5,4))
        plot = ax.pcolormesh(x,y,values,shading='gouraud',cmap='jet')
        fig.colorbar(plot,ax=ax); ax.set_aspect('equal'); ax.set_xlabel('x'); ax.set_ylabel('y')
        ax.set_title('Reference' if name=='analytical_solution' else 'h='+name.split('_')[-1])
        fig.tight_layout();fig.savefig(out/(name+'.pdf'));plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    for ax, name, title in zip(axes,
            ['analytical_solution', 'solution_h_0.01', 'solution_h_0.2'],
            ['(a) Analytical solution', '(b) h = 0.01', '(c) h = 0.2']):
        plot = ax.pcolormesh(x, y, fields[name], shading='gouraud', cmap='jet')
        fig.colorbar(plot, ax=ax, fraction=.046, pad=.04)
        ax.set_aspect('equal'); ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_title(title)
    fig.tight_layout(); fig.savefig(out/'figure_5.pdf'); plt.close(fig)
    (dataout/'run_metadata.json').write_text(json.dumps({'source':str(source.relative_to(BASE)),
        'grid':'40 x 40 display grid; no calibration refit', 'runs':rows},indent=2))
    print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
