"""Summarize newly fitted rows in the order used by the revised manuscript."""
from pathlib import Path
import argparse
import json
import os

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('IISE_OUTPUT_DIR', BASE / 'outputs')).resolve()


def test3_aggregate(main):
    ranked = main.copy()
    ranked['rank'] = ranked.groupby(['variable', 'scenario'])['point_error'].rank(method='min')
    return (ranked.groupby('method').agg(
        mean_point_error=('point_error', 'mean'),
        median_point_error=('point_error', 'median'),
        mean_rank=('rank', 'mean'),
        wins=('rank', lambda x: int((x == 1).sum())),
        top2=('rank', lambda x: int((x <= 2).sum())),
        top3=('rank', lambda x: int((x <= 3).sum())),
        n=('rank', 'size'),
    ).reset_index().sort_values(['mean_rank', 'mean_point_error']))


def read(relative):
    frame = pd.read_csv(ROOT / 'results' / relative)
    if 'status' in frame and not frame.status.dropna().eq('ok').all():
        raise ValueError('Cannot summarize failed fits: ' + relative)
    return frame


def write_latex(path, frame):
    """Write a standalone tabular from computed values, without frozen results."""
    def escape(value):
        if isinstance(value, (float, np.floating)):
            if not np.isfinite(value):
                return 'N/A'
            return f'{value:.4g}'
        text = str(value)
        for old, new in [('&', r'\&'), ('%', r'\%'), ('_', r'\_'), ('#', r'\#')]:
            text = text.replace(old, new)
        return text
    lines = [r'\begin{tabular}{' + 'l' * len(frame.columns) + '}', r'\hline',
             ' & '.join(escape(c) for c in frame.columns) + r' \\', r'\hline']
    lines.extend(' & '.join(escape(v) for v in row) + r' \\'
                 for row in frame.itertuples(index=False, name=None))
    lines.extend([r'\hline', r'\end{tabular}'])
    path.write_text('\n'.join(lines) + '\n')


def main_comparison(frame, test):
    methods = ['NARE-MF (Simple)', 'NARE-MF (Complex)', 'Stationary GP',
               'GP-SSM', 'Nonstationary GP', 'Scaled AR']
    metric_columns = [('Target prediction', 'target_prediction'),
                      ('Point error', 'canonical_point_error' if test == 'test1' else 'point_error'),
                      ('Path error', 'canonical_path_error' if test == 'test1' else 'path_error')]
    rows = []
    for noise, group in frame.groupby('noise_std', sort=True):
        for label, column in metric_columns:
            row = {'Noise': noise, 'Metric': label}
            for method in methods:
                fit = group[group.method.eq(method)]
                if len(fit) != 1:
                    raise ValueError(f'Expected one {test}/{noise}/{method} fit')
                value = fit.iloc[0][column]
                if isinstance(value, str) and value.startswith('['):
                    value = json.loads(value)[0]
                row[method] = float(value)
            rows.append(row)
    return pd.DataFrame(rows)


def candidate_display(frame):
    shown = frame[['noise_std', 'method', 'candidate', 'candidate_score']].copy()
    parameters = []
    for _, row in frame.iterrows():
        settings = json.loads(row.fitting_settings)
        if row.method == 'Nonstationary GP':
            keys = [('sigma_kriging', 'sigma'), ('length_scale', 'length'), ('K', 'K')]
        else:
            keys = [('sigma', 'sigma'), ('l', 'length'), ('alpha', 'alpha')]
        parameters.append(', '.join(f'{label}={settings[key]:.8g}' for key, label in keys))
    shown.insert(3, 'Fitted parameters', parameters)
    return shown


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tests', choices=['all', 'test1', 'test2', 'test3'], default='all')
    parser.add_argument('--quick', action='store_true')
    parser.add_argument('--revision-only', action='store_true')
    args = parser.parse_args()
    out = ROOT / 'tables' / 'manuscript'
    out.mkdir(parents=True, exist_ok=True)
    exported = []

    def save(name, frame, source, display=None):
        if frame.empty:
            raise ValueError('Empty manuscript summary: ' + name)
        filename = name + ('_quick_subset' if args.quick else '') + '.csv'
        frame.to_csv(out / filename, index=False)
        shown = frame if display is None else display
        write_latex(out / filename.replace('.csv', '.tex'), shown)
        exported.append({'file': filename, 'source': source, 'rows': len(frame)})

    original_test2 = None
    if not args.revision_only:
        if args.tests in {'all', 'test1'}:
            fits = read('legacy_refit_test1/selected_candidate_refits.csv')
            save('table_1', main_comparison(fits, 'test1'),
                 'legacy_refit_test1/selected_candidate_refits.csv; reference-denominator errors')
            if not args.quick:
                candidates = read('legacy_refit_test1/candidate_scores.csv')
                cols = ['noise_std', 'method', 'candidate', 'parameters', 'candidate_score']
                save('table_A1', candidates[cols], 'legacy_refit_test1/candidate_scores.csv')
        if args.tests in {'all', 'test2', 'test3'}:
            fits = read('original_test23/main_results.csv')
            if args.tests in {'all', 'test2'}:
                original_test2 = fits[fits.experiment.eq('test2')].copy()
                save('table_2', main_comparison(original_test2, 'test2'),
                     'original_test23/main_results.csv; reference-denominator errors')
            if not args.quick:
                candidates = read('original_test23/candidate_scores.csv')
                for test, table in [('test2', 'A2'), ('test3', 'A3')]:
                    if args.tests in {'all', test}:
                        subset = candidates[candidates.experiment.eq(test)].copy()
                        save('table_' + table, subset,
                             'original_test23/candidate_scores.csv', candidate_display(subset))

    baselines = read('revision_baselines/direct_baselines.csv')
    # Appendix C.2 uses absolute endpoint error for every a=0 setting.
    baselines['reported_point_error'] = baselines['point_error']
    zero = (baselines.experiment.eq('test2') &
            np.isclose(baselines.get('a_true', pd.Series(np.nan, index=baselines.index)), 0))
    baselines.loc[zero, 'reported_point_error'] = baselines.loc[zero, 'endpoint_absolute_error']
    baselines['reported_error_type'] = np.where(zero, 'absolute', 'relative')
    for test, table in [('test1', 'C1'), ('test2', 'C2'), ('test3', 'C3')]:
        if args.tests in {'all', test}:
            frame = baselines[baselines.experiment.eq(test)].copy()
            cols = ([c for c in ['a_true', 'variable', 'scenario', 'noise_std']
                     if c in frame and frame[c].notna().any()] +
                    ['method', 'reported_point_error'] + (['path_error'] if test == 'test1' else []))
            save('table_' + table, frame, 'revision_baselines/direct_baselines.csv', frame[cols])
    core = baselines[baselines.experiment.eq('test1') |
                     (baselines.experiment.eq('test2') &
                      np.isclose(baselines.get('a_true', pd.Series(np.nan, index=baselines.index)), 1))]
    if not core.empty:
        save('table_3', core, 'revision_baselines/direct_baselines.csv',
             core[['experiment', 'noise_std', 'method', 'reported_point_error']])

    if args.tests in {'all', 'test1'}:
        gp = read('gp_mle_sensitivity/legacy_cv_vs_profile_mle.csv')
        rows = []
        for noise, group in gp.groupby('noise_std', sort=True):
            mle = group[group.method.eq('GP (profile MLE)')].iloc[0]
            old = group[~group.method.eq('GP (profile MLE)')].iloc[0]
            original_error = old.canonical_point_error
            rows.append({'noise_std': noise, 'original_GP_point_error': original_error,
                         'original_GP_point_error_historical': old.point_error,
                         'profile_MLE_point_error': mle.point_error,
                         'reduction_factor': original_error / mle.point_error,
                         'profile_MLE_path_error': mle.path_error,
                         'length_scale_scaled': mle.hp_lengthscale_scaled,
                         'nugget_ratio': mle.hp_nugget_ratio})
        save('table_4', pd.DataFrame(rows), 'gp_mle_sensitivity/legacy_cv_vs_profile_mle.csv')
    if args.tests in {'all', 'test2'}:
        two = read('two_stage_mf/two_stage_mf_calibration.csv')
        save('table_5_output_GP', two[two.experiment.eq('test2')],
             'two_stage_mf/two_stage_mf_calibration.csv',
             two.loc[two.experiment.eq('test2'), ['noise_std', 'point_error_manuscript']])
        if original_test2 is not None:
            rows = []
            for _, gp in two[two.experiment.eq('test2')].iterrows():
                if args.quick and not np.isclose(original_test2.noise_std, gp.noise_std).any():
                    continue
                row = {'noise_std': gp.noise_std, 'output_GP': gp.point_error_manuscript}
                for method in ['NARE-MF (Simple)', 'NARE-MF (Complex)']:
                    fit = original_test2[original_test2.method.eq(method) &
                                         np.isclose(original_test2.noise_std, gp.noise_std)]
                    row[method] = float(fit.iloc[0].point_error)
                rows.append(row)
            save('table_5', pd.DataFrame(rows), 'two_stage_mf and original_test23 freshly computed fits')
        design = read('design_sensitivity/design_sensitivity.csv')
        save('table_D2', design, 'design_sensitivity/design_sensitivity.csv',
             design[['L', 'design', 'method', 'point_error']])
        stability = read('design_sensitivity/leave_one_level_stability.csv')
        rows = []
        for level, group in design[design.method.eq('NARE-MF (simple)')].groupby('L'):
            loo = stability[(stability.L == level) & stability.method.eq('NARE-MF (simple)')]
            target_sd = loo.target_prediction_sd.dropna()
            rows.append({'L': level, 'minimum_point_error': group.point_error.min(),
                         'median_point_error': group.point_error.median(),
                         'maximum_point_error': group.point_error.max(),
                         'n_successful_loo': int(loo.n_successful_loo.min()),
                         'median_target_prediction_sd': target_sd.median() if len(target_sd) else np.nan})
        save('table_D1', pd.DataFrame(rows), 'design_sensitivity/*.csv')

    if args.tests in {'all', 'test3'}:
        windows = read('reviewer2_final/test3_window_all_methods.csv')
        if not args.quick:
            if len(windows) != 64 or windows.duplicated(['scenario', 'variant', 'method']).any():
                raise ValueError('Expected 64 distinct method/window/noise combinations')
            save('table_6', windows[windows.variant.eq('shorter')],
                 'reviewer2_final/test3_window_all_methods.csv',
                 windows.loc[windows.variant.eq('shorter'), ['scenario', 'method', 'point_error', 'path_error']])
        save('table_E1', windows, 'reviewer2_final/test3_window_all_methods.csv',
             windows[['scenario', 'variant', 'method', 'point_error']])
        turbine = read('main/main_results.csv')
        turbine = turbine[turbine.experiment.eq('test3')].copy()
        if not args.quick:
            counts = turbine.groupby(['variable', 'scenario']).size()
            if len(counts) != 10 or not counts.eq(9).all() or turbine.duplicated(['variable', 'scenario', 'method']).any():
                raise ValueError('Expected nine methods on each of ten turbine tasks')
        save('table_E2', test3_aggregate(turbine), 'main/main_results.csv (Test 3 rows)')
    (out / 'sources.json').write_text(json.dumps({'quick_subset': args.quick, 'tables': exported}, indent=2))
    print('Saved', len(exported), 'summaries under', out)


if __name__ == '__main__':
    main()
