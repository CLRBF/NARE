"""Plot the two turbine window-comparison panels from newly generated results."""

from __future__ import annotations

import csv
import os
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter

ROOT = Path(os.environ.get("IISE_OUTPUT_DIR", Path(__file__).resolve().parents[1] / "outputs")).resolve()
SOURCE = ROOT / "results/reviewer2_final/test3_window_all_methods.csv"
OUTPUT = ROOT / "figures/reviewer2_final"
WINDOWS = ("full", "selected", "shorter", "expanded")
LEVELS = (60, 12, 10, 13)
Y_LIMITS = {"noise_free": (5e-5, 7e-2), "noisy": (2e-3, 7e-2)}
METHODS = (
    ("NARE-MF (simple)", "NARE-S", "#0072B2", "o", "-"),
    ("Stationary GP (LOOCV)", "Stationary GP", "#56B4E9", "P", "--"),
    ("GP-SSM", "GP-SSM", "#000000", "h", ":"),
    ("Nonstationary GP (quadratic mean)", "Nonstationary GP", "#777777", "<", "-."),
    ("Scaled AR", "Scaled AR", "#B3B3B3", ">", "--"),
    ("Rational Kriging", "Rational Kriging", "#E69F00", "v", "-."),
)


def load_values():
    with SOURCE.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    values = {}
    for scenario in ("noise_free", "noisy"):
        for method, *_ in METHODS:
            series = []
            for window, levels in zip(WINDOWS, LEVELS):
                matches = [r for r in rows if (r["scenario"], r["method"], r["variant"])
                           == (scenario, method, window)]
                if len(matches) != 1:
                    raise ValueError(f"Expected one frozen row: {scenario}, {method}, {window}")
                row = matches[0]
                error = float(row["point_error"])
                if (row["status"] != "ok" or int(row["n_levels"]) != levels
                        or not math.isfinite(error) or error <= 0):
                    raise ValueError(f"Invalid frozen row: {scenario}, {method}, {window}")
                series.append(error)
            values[scenario, method] = series
    return values


def draw_panel(scenario, title, values):
    # Fixed canvas and margins give both exported PDFs identical geometry.
    fig, ax = plt.subplots(figsize=(4.9, 3.65))
    fig.subplots_adjust(left=0.19, right=0.98, bottom=0.26, top=0.85)
    for method, label, color, marker, linestyle in METHODS:
        line, = ax.plot(range(4), values[scenario, method], label=label,
                        color=color, marker=marker, linestyle=linestyle,
                        linewidth=1.45, markersize=5.1, markeredgewidth=0.65)
        # Check the actual plotted values against the frozen input.
        assert list(line.get_ydata()) == values[scenario, method]
    ax.set_yscale("log")
    # Panel (a) reserves space for the shared legend; panel (b) fits its data.
    ax.set_ylim(*Y_LIMITS[scenario])
    assert all(Y_LIMITS[scenario][0] < y < Y_LIMITS[scenario][1]
               for method, *_ in METHODS for y in values[scenario, method])
    if scenario == "noisy":
        ax.yaxis.set_major_locator(LogLocator(base=10, subs=(1, 2, 5)))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
        ax.yaxis.set_minor_formatter(NullFormatter())
    ax.set_xlim(-0.16, 3.28)
    ax.set_xticks(range(4), ["Full", "Selected", "Fine\nfocused", "Expanded"])
    ax.set_xlabel("Refinement window", labelpad=7)
    ax.set_ylabel("Point error", labelpad=6)
    # Place scenario text above the axes, so it cannot overlap the trajectories.
    ax.set_title(title, loc="left", pad=11, fontsize=15.5)
    ax.grid(axis="y", which="major", color="#DDDDDD", linewidth=0.55)
    ax.set_axisbelow(True)
    ax.tick_params(direction="out", length=3.5, width=0.7, pad=4)
    ax.tick_params(which="minor", length=2, width=0.5)
    if scenario == "noise_free":
        # Pair the two long GP labels in one column so larger type still fits.
        # Matplotlib fills columns first; the legend remains three by two.
        handles, labels = ax.get_legend_handles_labels()
        order = (0, 4, 1, 3, 2, 5)
        legend = ax.legend([handles[i] for i in order], [labels[i] for i in order],
                           loc="lower left", ncols=3, fontsize=11,
                           bbox_to_anchor=(0.015, 0.025), borderaxespad=0,
                           handlelength=1.0, handletextpad=0.25,
                           columnspacing=0.4, labelspacing=0.45,
                           borderpad=0.25, frameon=True, facecolor="white",
                           edgecolor="none", framealpha=1)
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()
        bounds = legend.get_window_extent(renderer)
        axes_bounds = ax.get_window_extent(renderer)
        lowest_point = min(min(values[scenario, method]) for method, *_ in METHODS)
        # The legend fits inside the axes and below every plotted trajectory.
        assert bounds.x0 >= axes_bounds.x0 and bounds.x1 <= axes_bounds.x1
        assert bounds.y1 + 5 < ax.transData.transform((0, lowest_point))[1]
    stem = OUTPUT / f"fig_r2_test3_window_{scenario}"
    fig.canvas.draw()
    bounds = ax.get_tightbbox(fig.canvas.get_renderer())
    assert bounds.x0 >= 0 and bounds.y0 >= 0
    assert bounds.x1 <= fig.bbox.width and bounds.y1 <= fig.bbox.height
    fig.savefig(stem.with_suffix(".pdf"), metadata={"CreationDate": None, "ModDate": None})
    fig.savefig(stem.with_suffix(".png"), dpi=300)
    plt.close(fig)
    return stem.with_suffix(".pdf")


def main():
    source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    values = load_values()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "font.size": 13.5, "axes.labelsize": 14, "xtick.labelsize": 13, "ytick.labelsize": 13,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.8,
        "pdf.fonttype": 42, "ps.fonttype": 42, "mathtext.fontset": "dejavusans",
        "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    })
    outputs = [draw_panel("noise_free", "(a) Noise-free", values),
               draw_panel("noisy", "(b) Noisy", values)]
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash
    print(json.dumps({"source": str(SOURCE.relative_to(ROOT)), "source_sha256": source_hash,
                      "plotted_values_verified": 48,
                      "y_limits": Y_LIMITS,
                      "pdfs": [str(p.relative_to(ROOT)) for p in outputs]}, indent=2))


if __name__ == "__main__":
    main()
