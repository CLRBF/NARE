"""Plot the selected-candidate Test 1 fits produced by refit_original_test1.py."""
from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('IISE_OUTPUT_DIR', BASE / 'outputs')).resolve()


def main():
    data = pd.read_csv(ROOT / 'results/legacy_refit_test1/predictions.csv')
    out = ROOT / 'figures/original_test1'
    out.mkdir(parents=True, exist_ok=True)
    for noise, figure_number in [(0, 3), (0.02, 4)]:
        selected = data[np.isclose(data.noise_std, noise)]
        methods = selected.method.drop_duplicates().tolist()
        if len(methods) != 6:
            raise ValueError('Expected six original Test 1 methods')
        fig, axes = plt.subplots(2, 3, figsize=(12, 6.8))
        for ax, method in zip(axes.ravel(), methods):
            rows = selected[selected.method.eq(method)].sort_values('h')
            ax.plot(rows.h, rows.reference, 'o-', markersize=3, label='Reference')
            ax.plot(rows.h, rows.prediction, '--', label='Prediction')
            ax.set(title=method, xlabel='h', ylabel='Calibrated parameter')
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.tight_layout()
        fig.savefig(out / f'figure_{figure_number}_selected_candidate_refits.pdf')
        fig.savefig(out / f'figure_{figure_number}_selected_candidate_refits.png', dpi=180)
        plt.close(fig)


if __name__ == '__main__':
    main()
