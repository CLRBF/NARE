"""Refit the original Poisson and turbine candidates from calibration inputs.

Use the Python 3.8 environment in requirements-original-test1.txt. Outputs
are recomputed and written below IISE_OUTPUT_DIR; no fitted outputs are inputs.
"""
from pathlib import Path
import argparse,csv,importlib,inspect,json,os,sys,warnings
import numpy as np
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
INDEX=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,16,18]

def scalar(x): return float(np.asarray(x).reshape(-1)[0])
def array(x):
    a=np.asarray(x,dtype=float)
    return a.reshape(-1,1) if a.ndim<2 or a.shape[0]==1 else a

def fit_case(c,setting,inputs):
    test=c['experiment'];noise=c['noise_std'];module=importlib.import_module(c['module'])
    records=[];module.__dict__.update(c['settings']);module.os=os;module._capture=records.append
    module.noise=int(bool(noise));module.std=noise;module.index=INDEX;module.delta_t=.005
    module.noise_free_true=setting if test=='test2' else ([.523,.601,.536,.334,.342] if noise==0 else [.543,.675,.562,.348,.363])[setting-1]
    module.seed_everything(c['settings']['seed'])
    key='%s_%g_%g'%(test,noise,setting);data={k:np.asarray(v,dtype=float) for k,v in inputs[key].items()}
    args=[data,module.noise_free_true]
    if test=='test2':args.append(INDEX)
    if 'current_dir' in inspect.signature(module.process_and_evaluate).parameters:args.append(str(BASE))
    module.process_and_evaluate(*args)
    if len(records)!=1:raise RuntimeError('Expected one fitted output from '+c['module'])
    d=records[0];h=np.asarray(d['t_NEW']).ravel();pred=array(d['predicted_x']);ref=array(d['X_true_original'])
    # GP-SSM stores an extra continuum prediction; the last evaluation mesh is h=.01.
    if len(pred)==len(h)+1:pred=pred[:-1]
    if len(pred)!=len(h):raise ValueError('Prediction and mesh lengths differ')
    ref=ref[-len(pred):]
    # A noisy Poisson run may also evaluate h=0. That extra extrapolation is not
    # the h=.01 reference used in Table 2 or the candidate score.
    if test=='test2' and noise and h[-1]==0:
        h=h[:-1];pred=pred[:-1];ref=ref[:-1]
    display_h=h.copy()
    if test=='test3':
        # Mesh labels come from the calibration input. Some old plotting
        # scripts labelled the stored h=.01 target as h=0.
        h=np.sort(np.asarray(data['h']).ravel())[::-1][-len(pred):]
    if test=='test2':
        raw_h=np.asarray(data['h_set']).ravel();raw_y=np.asarray(data['a_optimal_set']).ravel()
        ref=np.asarray([setting if hh==0 else raw_y[np.argmin(abs(raw_h-hh))] for hh in h])[:,None]
    reference_norm=np.linalg.norm(ref[-1]);point=np.linalg.norm(pred[-1]-ref[-1])
    if reference_norm:point/=reference_norm
    path=np.linalg.norm(pred[:-1]-ref[:-1])/max(np.linalg.norm(ref[:-1]),1e-300)
    meta={'experiment':test,'noise_std':noise,'scenario':'noise_free' if noise==0 else 'noisy','setting':setting,'method':c['method'],'candidate':c.get('candidate',0),'kind':c['kind'],'panel_noise_std':c.get('panel_noise_std',noise)}
    row=dict(meta,status='ok',target_h=float(h[-1]),target_prediction=json.dumps(pred[-1].tolist()),target_reference=json.dumps(ref[-1].tolist()),point_error=float(point),path_error=float(path),historical_point_error=scalar(d['single_point_error_relative']),historical_path_error=scalar(d['relative_l2']),candidate_score=scalar(d['LOOCV_MSE_all']),initial_parameters=json.dumps(c['initial_parameters']),fitting_settings=json.dumps(c['settings'],sort_keys=True))
    if not np.isfinite(row['historical_point_error']):
        row['historical_point_error']=''
        row['historical_point_status']='undefined_relative_error_at_zero_reference'
    else:row['historical_point_status']='finite'
    for key in ['point_error','path_error','historical_path_error','candidate_score']:
        if not np.isfinite(row[key]):raise ValueError('Nonfinite '+key)
    if not np.all(np.isfinite(pred)):raise ValueError('Nonfinite predictions')
    rows=[dict(meta,h=float(hh),display_h=float(dh),row_role='target' if k==len(h)-1 else 'training',component=j+1,reference=float(yy),prediction=float(pp)) for j in range(pred.shape[1]) for k,(hh,dh,yy,pp) in enumerate(zip(h,display_h,ref[:,j],pred[:,j]))]
    extra=np.asarray(d.get('pred_h0',[]),dtype=float).ravel()
    if len(extra) and not np.array_equal(extra,pred[-1]):
        rows.extend(dict(meta,h=0.,display_h=0.,row_role='continuum_extrapolation',component=j+1,reference='',prediction=float(v)) for j,v in enumerate(extra))
    return row,rows

def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--tests',choices=['test2','test3','all'],default='all');ap.add_argument('--quick',action='store_true');ap.add_argument('--selected-only',action='store_true');args=ap.parse_args()
    if 'IISE_OUTPUT_DIR' not in os.environ:ap.error('Set IISE_OUTPUT_DIR to a new output directory.')
    out=Path(os.environ['IISE_OUTPUT_DIR'])/'results/original_test23';out.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((BASE/'data/original_test23/settings.json').read_text());inputs=json.loads((BASE/'data/original_test23/inputs.json').read_text())
    configs=cfg['selected']+cfg.get('plot_selected',[])+([] if args.selected_only else cfg['candidates'])
    all_rows=[];all_predictions=[];errors=[]
    warnings.filterwarnings('ignore',category=RuntimeWarning)
    for c in configs:
        if args.tests!='all' and c['experiment']!=args.tests:continue
        if args.quick and (c['noise_std']!=0 or c.get('candidate',1)!=1):continue
        settings=([1,2,-1,-2,0] if c['experiment']=='test2' else list(range(1,6))) if c['kind']=='candidate' else [1]
        for setting in settings:
            try:
                row,preds=fit_case(c,setting,inputs);all_rows.append(row)
                if c['kind'] in ['main','plot']:all_predictions.extend(preds)
            except Exception as exc:
                errors.append(dict(case=c,setting=setting,error=repr(exc)));print('FAILED',c['experiment'],c['noise_std'],c['method'],setting,repr(exc),flush=True)
        print('Fitted',c['experiment'],c['noise_std'],c['method'],c['kind'],c.get('candidate',0),flush=True)
        write_csv(out/'main_results.csv',[r for r in all_rows if r['kind']=='main']);write_csv(out/'plot_results.csv',[r for r in all_rows if r['kind']=='plot']);write_csv(out/'predictions.csv',all_predictions);write_csv(out/'candidate_setting_scores.csv',[r for r in all_rows if r['kind']=='candidate'])
        (out/'fit_errors.json').write_text(json.dumps(errors,indent=2))
    aggregate=[]
    for c in configs:
        if c['kind']!='candidate':continue
        selected=[r for r in all_rows if r['kind']=='candidate' and r['experiment']==c['experiment'] and r['noise_std']==c['noise_std'] and r['method']==c['method'] and r['candidate']==c['candidate']]
        if selected:aggregate.append({'experiment':c['experiment'],'noise_std':c['noise_std'],'method':c['method'],'candidate':c['candidate'],'n_settings':len(selected),'candidate_score':float(np.mean([r['candidate_score'] for r in selected])),'parameters':json.dumps(c['initial_parameters']),'fitting_settings':json.dumps(c['settings'],sort_keys=True)})
    write_csv(out/'candidate_scores.csv',aggregate)
    if errors:raise RuntimeError('%d historical fits failed; inspect fit_errors.json'%len(errors))
    print('Completed',len(all_rows),'fits.',flush=True)
if __name__=='__main__':main()
