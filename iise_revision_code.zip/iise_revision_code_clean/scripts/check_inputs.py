"""Check that the distributed inputs are present; no numerical packages needed."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parents[1]


def check_inputs(verify_hashes=False):
    manifest = json.loads((BASE / 'input_manifest.json').read_text())
    errors = []
    for entry in manifest['files']:
        relative = entry['path']
        path = BASE / relative
        if not path.is_file():
            errors.append('Missing input: ' + relative)
            continue
        try:
            if path.stat().st_size == 0:
                raise ValueError('empty file')
            if path.suffix == '.json':
                json.loads(path.read_text())
            elif path.suffix == '.csv':
                with path.open(newline='') as stream:
                    rows = csv.reader(stream)
                    next(rows)
                    next(rows)
            elif path.suffix == '.npz':
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise ValueError('damaged array archive')
            if verify_hashes and hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError('differs from the distributed input')
        except (OSError, ValueError, StopIteration, zipfile.BadZipFile) as exc:
            errors.append(relative + ': ' + str(exc))
    if errors:
        raise ValueError('\n'.join(errors))
    return len(manifest['files'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-hashes', action='store_true',
                        help='Also check that inputs match the distributed files exactly.')
    args = parser.parse_args()
    try:
        count = check_inputs(args.verify_hashes)
    except (OSError, ValueError) as exc:
        parser.exit(1, str(exc) + '\n')
    print(f'Input check passed: {count} files under {BASE / "data"}.')
