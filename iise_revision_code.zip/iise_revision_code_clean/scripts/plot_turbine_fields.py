"""Redraw Figure 9 from the supplied turbine mesh and stress data."""
from pathlib import Path
import os

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, Normalize
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('IISE_OUTPUT_DIR', BASE / 'outputs')).resolve()


def panel(fig, ax, data):
    vertices, faces = data['vertices'], data['faces']
    norm = Normalize(*data['color_limits'])
    cmap = ListedColormap(data['colormap'])
    colors = cmap(norm(data['stress'][faces].mean(axis=1)))
    surface = Poly3DCollection(vertices[faces], facecolors=colors,
                               edgecolors='0.25', linewidths=.08,
                               rasterized=True)
    ax.add_collection3d(surface)
    # These coordinates include the original display deformation, scale 100.
    lower, upper = vertices.min(axis=0), vertices.max(axis=0)
    span = upper - lower
    ax.set_xlim(lower[0], upper[0]); ax.set_ylim(lower[1], upper[1])
    ax.set_zlim(lower[2], upper[2]); ax.set_box_aspect(span)
    azimuth, elevation = data['view']
    ax.view_init(elev=float(elevation), azim=float(azimuth))
    ax.set_axis_off()
    ax.set_title(rf'$h={float(data["h"]):g}$', fontsize=13)
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax,
                       fraction=.035, pad=.01, shrink=.65)
    bar.set_label('Stress', fontsize=10)
    bar.ax.tick_params(labelsize=9)


def main():
    out = ROOT / 'figures/test3_fields'
    out.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(12, 4.6))
    for index, h in enumerate([.01, .025, .051]):
        with np.load(BASE / 'data/turbine_fields' / f'field_h_{h:g}.npz') as data:
            panel(fig, fig.add_subplot(1, 3, index+1, projection='3d'), data)
            single = plt.figure(figsize=(5.4, 5.0))
            panel(single, single.add_subplot(projection='3d'), data)
            single.savefig(out / f'field_h_{h:g}.pdf', bbox_inches='tight', dpi=200)
            plt.close(single)
    fig.savefig(out / 'figure_9.pdf', bbox_inches='tight', dpi=200)
    plt.close(fig)


if __name__ == '__main__':
    main()
