"""Plot simulator curves and archived calibrated trajectories (Figures 2, 6, 10)."""
from pathlib import Path
import json, os, argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parents[1]
ROOT=Path(os.environ.get("IISE_OUTPUT_DIR",BASE/"outputs")).resolve()
DISPLAY_INDEX = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,16,18]


def simulator_panel(ax):
    x=np.linspace(0,np.pi/2,50);reference=np.exp(.1*x)*np.sin(x)
    ax.plot(x,reference,label='Reference')
    for h in [0,.2,.4,.6,.8]:
        output=reference-.1*np.sqrt((2*h)**2+1)*(np.sin(2*x)+np.cos(2*x))
        ax.plot(x,output,label=f'h={h:g}')
    ax.set_xlabel('x');ax.set_ylabel('Simulator output');ax.legend(fontsize=9)


def calibration_panel(ax, test):
    ycol='theta' if test=='test1' else 'a_calibrated'
    frame=pd.read_csv(BASE/f'data/trajectories/{test}.csv')
    if test=='test2':frame=frame[np.isclose(frame.a_true,1)]
    for noise,group in frame.groupby('noise_std'):
        group=group.sort_values('h').iloc[DISPLAY_INDEX]
        line,=ax.plot(group.h,group[ycol],'o-',markersize=3,label=fr'$\sigma={noise:g}$')
        for index in [0,3,6,9,12,15]:
            row=group.iloc[index]
            ax.annotate(f'{row[ycol]:.3f}',(row.h,row[ycol]),xytext=(0,4),
                        textcoords='offset points',fontsize=7,color=line.get_color(),rotation=-35)
    if test=='test2':ax.scatter([0],[1],color='C0',s=18,zorder=5)
    ax.set_xlabel('h');ax.set_ylabel('Calibrated parameter');ax.legend(fontsize=9);ax.grid(alpha=.2)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tests',choices=['all','test1','test2','test3'],default='all')
    args=parser.parse_args()
    out=ROOT/'figures/data_overview';out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':12,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    if args.tests in {'all','test1'}:
        fig,ax=plt.subplots(figsize=(6,4));simulator_panel(ax)
        fig.tight_layout();fig.savefig(out/'test1_simulator.pdf');plt.close(fig)
        fig,axes=plt.subplots(1,2,figsize=(11,4.2));simulator_panel(axes[0]);calibration_panel(axes[1],'test1')
        fig.tight_layout();fig.savefig(out/'figure_2.pdf');plt.close(fig)
    for test,ycol in [('test1','theta'),('test2','a_calibrated')]:
        if args.tests not in {'all',test}:continue
        fig,ax=plt.subplots(figsize=(6,4))
        calibration_panel(ax,test)
        fig.tight_layout();fig.savefig(out/f'{test}_calibration_trajectories.pdf');plt.close(fig)
    if args.tests in {'all','test3'}:
        raw=pd.read_csv(BASE/'data/trajectories/test3_full.csv');selected=pd.read_csv(BASE/'data/trajectories/test3_selected.csv')
        fig,axes=plt.subplots(1,3,figsize=(12,3.7))
        for ax,frame,scenario,title in [(axes[0],raw,'noise_free','Original'),(axes[1],selected,'noise_free','Noise-free'),(axes[2],selected,'noisy','Noisy')]:
            group=frame[(frame.variable==1)&(frame.scenario==scenario)].sort_values('h')
            for c in [1,2]:ax.plot(group.h,group[f'theta{c}'],'o-',markersize=3,label=f'$\\theta_{c}$')
            ax.set_title(title);ax.set_xlabel('h');ax.set_ylabel('Calibrated parameter');ax.legend();ax.grid(alpha=.15)
        fig.tight_layout();fig.savefig(out/'test3_raw_and_selected.pdf');plt.close(fig)
    print('Plotted the requested simulator curves and stored calibration trajectories.')
if __name__=='__main__':main()
