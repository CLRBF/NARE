# IISE experiments

Run the commands below from this folder. The complete workflow uses Python 3.12
for the revision experiments and a separate Python 3.8 environment for the
original fits and Poisson field plots.

## Install

Main environment:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Original environment (Conda; the main environment stays separate):

```bash
conda create -n iise-original -c conda-forge python=3.8 fenics=2019.1.0
conda run -n iise-original python -m pip install -r requirements-original-test1.txt
conda run -n iise-original python -c "import sys; print(sys.executable)"
```

Use the printed interpreter path in place of `/path/to/original/python` below.
The original requirements file applies to all three tests. The field plots use
legacy FEniCS/DOLFIN 2019.1, not FEniCSx; installation alternatives are listed in
the [FEniCS installation guide](https://fenicsproject.org/download/archive/).

## Run

Check the supplied data before starting:

```bash
python run.py --check-inputs
```

All inputs are in `data/` and are located relative to the code files, so you can
move this folder or invoke `run.py` from another working directory. No original
author directory is needed. To check that the inputs are unchanged after
copying or downloading, run `python scripts/check_inputs.py --verify-hashes`.

```bash
python run.py --original-python /path/to/original/python
python run.py --test test1 --original-python /path/to/original/python
python run.py --test test2 --original-python /path/to/original/python
python run.py --test test3 --original-python /path/to/original/python
```

The full run fits the main comparisons and Appendix A candidate settings,
runs the additional benchmarks and sensitivity studies, and generates the
table summaries and figures. Test 3 uses the supplied calibration trajectories
and stress-field data; MATLAB is not required. The output-level GP followed by
calibration benchmark runs on Test 2.

Useful options:

```bash
# Small set of cases to check the installation
python run.py --quick --original-python /path/to/original/python

# Additional revision experiments only, using the main environment
python run.py --revision-only

# Refit Test 1 candidates using the parameter values printed in Appendix A.1
python run.py --test test1 --candidate-settings manuscript --original-python /path/to/original/python
```

The default candidate settings are the full-precision inputs recovered from
the original experiments. Each output records the parameters actually used.
Tables use the manuscript's reference-denominator error definition; the raw
original-fit CSV files also retain the historical error calculation.

Each run creates a new folder under `outputs/`. Use `--output /path/to/new_folder`
to choose its location. The folder contains `results/`, `tables/manuscript/`
(CSV and LaTeX), `figures/`, and `logs/`. Figure 11 includes separate a/b panels.
Use a full run, without `--quick`, for all experiment settings.

## Files

- `data/`: observations, calibration trajectories, mesh/stress fields and fitting inputs.
- `naremf/`: fitting methods, metrics and simulator implementations.
- `experiments/`: revision experiment drivers.
- `scripts/`: original experiment drivers, plotting and table export.
